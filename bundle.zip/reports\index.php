<?php
/**
 * QR Attendance System Using MS SQL and Apache
 * Reports & Analytics Hub
 */

require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/includes/functions.php';
require_once dirname(__DIR__) . '/includes/auth_guard.php';

$user = require_role(['Admin', 'Lecturer']);
$pdo = Database::getConnection();

// Department-level statistics
$deptStats = $pdo->query("
    SELECT d.DepartmentID, d.DepartmentCode, d.DepartmentName,
           (SELECT COUNT(*) FROM Students s WHERE s.DepartmentID = d.DepartmentID) AS StudentsCount,
           (SELECT COUNT(*) FROM Courses c WHERE c.DepartmentID = d.DepartmentID) AS CoursesCount,
           (SELECT COUNT(*) FROM AttendanceRecords r JOIN Courses c ON r.CourseID = c.CourseID WHERE c.DepartmentID = d.DepartmentID) AS TotalScans
    FROM Departments d
    ORDER BY d.DepartmentCode ASC
")->fetchAll();

// Course list for report downloads
$courses = $pdo->query("
    SELECT c.CourseID, c.CourseCode, c.CourseTitle, d.DepartmentCode,
           (SELECT COUNT(*) FROM CourseRegistrations cr WHERE cr.CourseID = c.CourseID) AS EnrolledCount,
           (SELECT COUNT(*) FROM AttendanceSessions s WHERE s.CourseID = c.CourseID) AS SessionsCount
    FROM Courses c
    JOIN Departments d ON c.DepartmentID = d.DepartmentID
    ORDER BY c.CourseCode ASC
")->fetchAll();

$pageTitle = 'Institutional Reports & Analytics';
require_once dirname(__DIR__) . '/includes/header.php';
?>

<div class="page-header">
    <div>
        <h1 class="page-title"><i class="fas fa-file-invoice text-primary"></i> Institutional Reports &amp; Analytics</h1>
        <div class="page-subtitle">Central attendance evaluations, eligibility tracking &amp; official document exports</div>
    </div>
    <div>
        <?php if ($user['role'] === 'Admin'): ?>
            <a href="<?= BASE_URL ?>/reports/export_csv.php?type=all" class="btn btn-primary">
                <i class="fas fa-file-csv"></i> Export Entire Master Ledger (CSV)
            </a>
        <?php endif; ?>
    </div>
</div>

<!-- Department Overview Cards -->
<div class="card mb-4">
    <div class="card-header">
        <h3 class="card-title"><i class="fas fa-chart-pie text-primary"></i> Departmental Attendance Performance</h3>
    </div>
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>Department Code</th>
                    <th>Department Name</th>
                    <th>Enrolled Students</th>
                    <th>Courses Offered</th>
                    <th>Total Attendance Check-ins</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($deptStats as $ds): ?>
                    <tr>
                        <td><strong><?= htmlspecialchars($ds['DepartmentCode']) ?></strong></td>
                        <td><?= htmlspecialchars($ds['DepartmentName']) ?></td>
                        <td><span class="badge badge-neutral"><?= $ds['StudentsCount'] ?> Students</span></td>
                        <td><?= $ds['CoursesCount'] ?> Courses</td>
                        <td><strong class="text-primary"><?= $ds['TotalScans'] ?></strong> records</td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Course Reports Download Hub -->
<div class="card">
    <div class="card-header">
        <h3 class="card-title"><i class="fas fa-file-excel text-primary"></i> Course Exam Eligibility Reports</h3>
        <input type="text" class="form-control" placeholder="Search course..." style="max-width: 250px;" data-table-filter="#reports-table">
    </div>
    <div class="table-responsive">
        <table class="table" id="reports-table">
            <thead>
                <tr>
                    <th>Course Code</th>
                    <th>Course Title</th>
                    <th>Department</th>
                    <th>Enrolled Students</th>
                    <th>Sessions Held</th>
                    <th class="text-right">Export Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($courses as $c): ?>
                    <tr>
                        <td><strong style="color: #1e3a8a;"><?= htmlspecialchars($c['CourseCode']) ?></strong></td>
                        <td><?= htmlspecialchars($c['CourseTitle']) ?></td>
                        <td><?= htmlspecialchars($c['DepartmentCode']) ?></td>
                        <td><strong><?= $c['EnrolledCount'] ?></strong> students</td>
                        <td><?= $c['SessionsCount'] ?> lectures</td>
                        <td class="text-right">
                            <a href="<?= BASE_URL ?>/reports/export_csv.php?course_id=<?= $c['CourseID'] ?>" class="btn btn-outline btn-sm">
                                <i class="fas fa-download text-success"></i> Download Eligibility CSV
                            </a>
                            <?php if ($user['role'] === 'Lecturer'): ?>
                                <a href="<?= BASE_URL ?>/lecturer/reports.php?course_id=<?= $c['CourseID'] ?>" class="btn btn-primary btn-sm">
                                    <i class="fas fa-eye"></i> View Online
                                </a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once dirname(__DIR__) . '/includes/footer.php'; ?>
