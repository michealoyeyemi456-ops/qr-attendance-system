<?php
/**
 * QR Attendance System Using MS SQL and Apache
 * Student Portal: Main Overview Dashboard
 */

require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/includes/functions.php';
require_once dirname(__DIR__) . '/includes/auth_guard.php';

$user = require_role('Student');
$pdo = Database::getConnection();

// Fetch student full profile
$stStudent = $pdo->prepare("
    SELECT s.StudentID, s.MatricNo, s.FirstName, s.LastName, s.Phone, s.AcademicSession,
           d.DepartmentName, d.DepartmentCode, p.ProgrammeName, l.LevelCode, l.LevelName
    FROM Students s
    JOIN Departments d ON s.DepartmentID = d.DepartmentID
    JOIN Programmes p ON s.ProgrammeID = p.ProgrammeID
    JOIN Levels l ON s.LevelID = l.LevelID
    WHERE s.UserID = ?
");
$stStudent->execute([$user['user_id']]);
$student = $stStudent->fetch();

$studentId = (int)$student['StudentID'];

// Check for currently active attendance sessions for student's registered courses
$stActiveSessions = $pdo->prepare("
    SELECT s.SessionID, s.SessionDate, s.StartTime, s.EndTime, s.DurationMinutes, s.SessionToken,
           c.CourseCode, c.CourseTitle, cl.RoomCode, cl.Building,
           l.Title AS LecTitle, l.LastName AS LecLast,
           (SELECT COUNT(*) FROM AttendanceRecords ar WHERE ar.SessionID = s.SessionID AND ar.StudentID = ?) AS AlreadyMarked
    FROM AttendanceSessions s
    JOIN Courses c ON s.CourseID = c.CourseID
    JOIN CourseRegistrations cr ON c.CourseID = cr.CourseID AND cr.StudentID = ?
    JOIN Classrooms cl ON s.ClassroomID = cl.ClassroomID
    JOIN Lecturers l ON s.LecturerID = l.LecturerID
    WHERE s.Status = 'Active' AND s.SessionDate = CURRENT_DATE
");
$stActiveSessions->execute([$studentId, $studentId]);
$activeSessions = $stActiveSessions->fetchAll();

// Fetch registered courses with attendance calculations
$stCourses = $pdo->prepare("
    SELECT c.CourseID, c.CourseCode, c.CourseTitle, c.CreditUnits, c.Semester,
           l.Title AS LecTitle, l.FirstName AS LecFirst, l.LastName AS LecLast
    FROM CourseRegistrations cr
    JOIN Courses c ON cr.CourseID = c.CourseID
    LEFT JOIN CourseLecturers cl ON c.CourseID = cl.CourseID
    LEFT JOIN Lecturers l ON cl.LecturerID = l.LecturerID
    WHERE cr.StudentID = ?
    ORDER BY c.CourseCode ASC
");
$stCourses->execute([$studentId]);
$registeredCourses = $stCourses->fetchAll();

// Calculate aggregated stats
$totalAttendedAll = 0;
$totalLecturesAll = 0;
$courseAttendanceData = [];

foreach ($registeredCourses as $c) {
    $att = calculateAttendancePercent($studentId, (int)$c['CourseID']);
    $courseAttendanceData[$c['CourseID']] = $att;
    $totalAttendedAll += $att['attended'];
    $totalLecturesAll += $att['total'];
}

$overallPercentage = ($totalLecturesAll > 0) ? round(($totalAttendedAll / $totalLecturesAll) * 100, 1) : 100.0;

$pageTitle = 'Student Portal';
require_once dirname(__DIR__) . '/includes/header.php';
?>

<!-- Student Profile Greeting Banner -->
<div class="card mb-4" style="background: linear-gradient(135deg, #1e3a8a 0%, #1e40af 100%); color: #ffffff; border: none;">
    <div class="card-body" style="padding: 1.75rem 2rem;">
        <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 1rem;">
            <div>
                <span class="badge" style="background: rgba(255,255,255,0.2); color: #ffffff; margin-bottom: 0.5rem;">
                    <i class="fas fa-graduation-cap"></i> <?= htmlspecialchars($student['LevelCode']) ?> &bull; <?= htmlspecialchars($student['DepartmentCode']) ?>
                </span>
                <h2 style="color: #ffffff; font-size: 1.75rem; margin-bottom: 0.25rem;">
                    Welcome, <?= htmlspecialchars($student['FirstName'] . ' ' . $student['LastName']) ?>
                </h2>
                <div style="opacity: 0.85; font-size: 0.9rem;">
                    Matriculation No: <strong><?= htmlspecialchars($student['MatricNo']) ?></strong> &bull; <?= htmlspecialchars($student['ProgrammeName']) ?>
                </div>
            </div>
            <div>
                <a href="<?= BASE_URL ?>/student/scan.php" class="btn btn-accent btn-lg">
                    <i class="fas fa-camera"></i> Scan Classroom QR
                </a>
            </div>
        </div>
    </div>
</div>

<!-- Active Live Class Sessions Alert Banner -->
<?php if (!empty($activeSessions)): ?>
    <div class="card mb-4" style="border: 2px solid #3b82f6; background-color: #eff6ff;">
        <div class="card-body" style="padding: 1.25rem 1.75rem;">
            <div class="d-flex align-items-center justify-between flex-wrap gap-2 mb-3">
                <div class="d-flex align-items-center gap-2">
                    <div class="pulse-indicator"></div>
                    <h3 style="font-size: 1.15rem; color: #1e3a8a; margin: 0;">Live Lecture In Progress</h3>
                </div>
                <span class="badge badge-primary">Active Now</span>
            </div>

            <?php foreach ($activeSessions as $ses): ?>
                <div style="background: #ffffff; border-radius: var(--radius-md); padding: 1.1rem; border: 1px solid #bfdbfe; margin-bottom: 0.75rem; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 1rem;">
                    <div>
                        <div style="font-size: 1.1rem; font-weight: 800; color: #0f2b48;">
                            <?= htmlspecialchars($ses['CourseCode']) ?> &mdash; <?= htmlspecialchars($ses['CourseTitle']) ?>
                        </div>
                        <div class="text-muted" style="font-size: 0.85rem; margin-top: 0.2rem;">
                            <i class="fas fa-chalkboard-teacher"></i> <?= htmlspecialchars($ses['LecTitle'] . ' ' . $ses['LecLast']) ?> &bull; 
                            <i class="fas fa-map-marker-alt"></i> <?= htmlspecialchars($ses['RoomCode'] . ' (' . $ses['Building'] . ')') ?> &bull;
                            <i class="fas fa-clock"></i> Closes at <?= date('h:i A', strtotime($ses['EndTime'])) ?>
                        </div>
                    </div>

                    <div>
                        <?php if ($ses['AlreadyMarked'] > 0): ?>
                            <span class="badge badge-success" style="padding: 0.6rem 1rem; font-size: 0.9rem;">
                                <i class="fas fa-check-circle"></i> Already Checked In
                            </span>
                        <?php else: ?>
                            <a href="<?= BASE_URL ?>/student/scan.php?token=<?= urlencode($ses['SessionToken']) ?>" class="btn btn-primary">
                                <i class="fas fa-qrcode"></i> Scan to Mark Attendance
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
<?php endif; ?>

<!-- Summary KPI Grid -->
<div class="stat-grid">
    <div class="stat-card stat-primary">
        <div class="stat-icon-wrapper">
            <i class="fas fa-book-open"></i>
        </div>
        <div class="stat-content">
            <div class="stat-value"><?= count($registeredCourses) ?></div>
            <div class="stat-label">Enrolled Courses</div>
        </div>
    </div>

    <div class="stat-card stat-success">
        <div class="stat-icon-wrapper">
            <i class="fas fa-calendar-check"></i>
        </div>
        <div class="stat-content">
            <div class="stat-value"><?= $totalAttendedAll ?> / <?= $totalLecturesAll ?></div>
            <div class="stat-label">Lectures Attended</div>
        </div>
    </div>

    <div class="stat-card stat-<?= ($overallPercentage >= ATTENDANCE_THRESHOLD_PERCENT) ? 'success' : 'warning' ?>">
        <div class="stat-icon-wrapper">
            <i class="fas fa-chart-line"></i>
        </div>
        <div class="stat-content">
            <div class="stat-value"><?= $overallPercentage ?>%</div>
            <div class="stat-label">Overall Attendance</div>
        </div>
    </div>

    <div class="stat-card stat-info">
        <div class="stat-icon-wrapper">
            <i class="fas fa-shield-alt"></i>
        </div>
        <div class="stat-content">
            <div class="stat-value" style="font-size: 1.1rem; line-height: 1.4;">
                <?= ($overallPercentage >= ATTENDANCE_THRESHOLD_PERCENT) ? '<span class="text-success">EXAM ELIGIBLE</span>' : '<span class="text-danger">WARNING</span>' ?>
            </div>
            <div class="stat-label">Required: &ge; <?= ATTENDANCE_THRESHOLD_PERCENT ?>%</div>
        </div>
    </div>
</div>

<!-- Registered Courses & Attendance Progress Breakdown -->
<div class="card">
    <div class="card-header">
        <h3 class="card-title"><i class="fas fa-tasks text-primary"></i> Course Attendance Status</h3>
        <a href="<?= BASE_URL ?>/student/courses.php" class="btn btn-outline btn-sm">View Full Breakdown</a>
    </div>
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>Course Code</th>
                    <th>Course Title</th>
                    <th>Lecturer</th>
                    <th>Attended / Total</th>
                    <th>Percentage</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($registeredCourses)): ?>
                    <tr>
                        <td colspan="6" class="text-center text-muted">No courses registered for this semester.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($registeredCourses as $c): 
                        $att = $courseAttendanceData[$c['CourseID']];
                        $barClass = ($att['percentage'] >= ATTENDANCE_THRESHOLD_PERCENT) ? 'progress-success' : (($att['percentage'] >= 60) ? 'progress-warning' : 'progress-danger');
                    ?>
                        <tr>
                            <td><strong><?= htmlspecialchars($c['CourseCode']) ?></strong></td>
                            <td><?= htmlspecialchars($c['CourseTitle']) ?></td>
                            <td><?= htmlspecialchars(($c['LecTitle'] ?? '') . ' ' . ($c['LecLast'] ?? 'Staff')) ?></td>
                            <td><strong><?= $att['attended'] ?></strong> / <?= $att['total'] ?></td>
                            <td style="min-width: 140px;">
                                <div class="d-flex align-items-center gap-2">
                                    <span style="font-weight: 700; width: 45px;"><?= $att['percentage'] ?>%</span>
                                    <div class="progress-bar-container" style="flex:1;">
                                        <div class="progress-bar-fill <?= $barClass ?>" style="width: <?= min(100, $att['percentage']) ?>%;"></div>
                                    </div>
                                </div>
                            </td>
                            <td><?= getEligibilityBadge($att['percentage']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once dirname(__DIR__) . '/includes/footer.php'; ?>
