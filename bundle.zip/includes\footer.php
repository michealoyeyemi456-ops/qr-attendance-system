<?php
/**
 * QR Attendance System Using MS SQL and Apache
 * Dashboard Footer Component
 */
?>
        </main>
        <!-- Footer Info -->
        <footer style="padding: 1.5rem 2rem; border-top: 1px solid var(--border); background-color: var(--surface); color: var(--text-muted); font-size: 0.8rem; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 0.5rem;">
            <div>
                &copy; <?= date('Y') ?> <?= htmlspecialchars(INSTITUTION_NAME) ?> &bull; <?= APP_NAME ?>
            </div>
            <div>
                Built for <strong>Microsoft SQL Server</strong> &amp; <strong>Apache</strong> | Ver <?= APP_VERSION ?>
            </div>
        </footer>
    </div>
</div>

<!-- Global Application Scripts -->
<script src="<?= BASE_URL ?>/assets/js/app.js"></script>
</body>
</html>
