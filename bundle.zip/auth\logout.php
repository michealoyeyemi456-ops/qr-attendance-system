<?php
/**
 * QR Attendance System Using MS SQL and Apache
 * Logout Handler
 */

require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/includes/functions.php';

if (!empty($_SESSION['user_id'])) {
    logAudit($_SESSION['user_id'], 'USER_LOGOUT', 'AUTH', "User {$_SESSION['username']} signed out");
}

session_unset();
session_destroy();
session_start();

flash('auth_error', 'You have been signed out successfully.', 'info');
header('Location: ' . BASE_URL . '/auth/login.php');
exit;
