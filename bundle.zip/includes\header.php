<?php
/**
 * QR Attendance System Using MS SQL and Apache
 * Reusable Dashboard Header Component
 */

if (!defined('APP_INIT')) {
    require_once dirname(__DIR__) . '/config/config.php';
    require_once dirname(__DIR__) . '/config/database.php';
    require_once dirname(__DIR__) . '/includes/functions.php';
    require_once dirname(__DIR__) . '/includes/auth_guard.php';
}

$pageTitle = $pageTitle ?? APP_NAME;
$userRole = $_SESSION['user_role'] ?? 'Guest';
$userFullName = $_SESSION['user_fullname'] ?? ($_SESSION['username'] ?? 'User');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($pageTitle) ?> | <?= APP_NAME ?></title>
    
    <!-- Google Fonts & Font Awesome 6 -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    
    <!-- Application Stylesheets -->
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/dashboard.css">
    
    <!-- In-Browser HTML5 QR Scanner Library -->
    <script src="https://unpkg.com/html5-qrcode@2.3.8/html5-qrcode.min.js"></script>
</head>
<body>
<div class="dashboard-wrapper">
    <!-- Include Sidebar -->
    <?php require_once __DIR__ . '/sidebar.php'; ?>

    <!-- Main Content Wrapper -->
    <div class="dashboard-main">
        <!-- Top Navigation Bar -->
        <header class="dashboard-topbar">
            <div class="topbar-left">
                <button class="menu-toggle-btn" aria-label="Toggle navigation">
                    <i class="fas fa-bars"></i>
                </button>
                <div class="topbar-institution">
                    <span class="inst-name"><?= htmlspecialchars(INSTITUTION_NAME) ?></span>
                    <span class="inst-term">
                        <i class="fas fa-calendar-alt"></i> <?= CURRENT_ACADEMIC_SESSION ?> &bull; <?= CURRENT_SEMESTER ?>
                    </span>
                </div>
            </div>

            <div class="topbar-right">
                <div class="d-flex align-items-center gap-2">
                    <span class="badge badge-neutral">
                        <i class="fas fa-database text-primary"></i> <?= htmlspecialchars(Database::getDriverUsed()) ?>
                    </span>
                    <a href="<?= BASE_URL ?>/auth/logout.php" class="btn btn-outline btn-sm" title="Sign Out">
                        <i class="fas fa-sign-out-alt"></i> <span class="d-none d-md-inline">Logout</span>
                    </a>
                </div>
            </div>
        </header>

        <!-- Main Content Area -->
        <main class="dashboard-content">
            <?php
            // Render Flash Messages if any
            $flashSuccess = get_flash('success');
            $flashError = get_flash('danger');
            $flashWarning = get_flash('warning');
            $flashInfo = get_flash('info');
            ?>
            <?php if ($flashSuccess): ?>
                <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?= htmlspecialchars($flashSuccess['message']) ?></div>
            <?php endif; ?>
            <?php if ($flashError): ?>
                <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($flashError['message']) ?></div>
            <?php endif; ?>
            <?php if ($flashWarning): ?>
                <div class="alert alert-warning"><i class="fas fa-exclamation-triangle"></i> <?= htmlspecialchars($flashWarning['message']) ?></div>
            <?php endif; ?>
            <?php if ($flashInfo): ?>
                <div class="alert alert-info"><i class="fas fa-info-circle"></i> <?= htmlspecialchars($flashInfo['message']) ?></div>
            <?php endif; ?>
