<?php
/**
 * QR Attendance System Using MS SQL and Apache
 * Student Portal: Attendance History & Class Scan Audit
 */

require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/includes/functions.php';
require_once dirname(__DIR__) . '/includes/auth_guard.php';

$user = require_role('Student');
$pdo = Database::getConnection();

// Fetch Student ID
$stStu = $pdo->prepare("SELECT StudentID FROM Students WHERE UserID = ?");
$stStu->execute([$user['user_id']]);
$studentId = (int)$stStu->fetchColumn();

// Filter parameters
$courseFilter = isset($_GET['course_id']) ? (int)$_GET['course_id'] : 0;
$statusFilter = trim($_GET['status'] ?? '');

$sql = "
    SELECT r.RecordID, r.MarkedAt, r.ScanMethod, r.Status, r.IPAddress,
           c.CourseID, c.CourseCode, c.CourseTitle,
           s.SessionDate, s.StartTime, s.EndTime,
           cl.RoomCode, cl.Building,
           l.Title AS LecTitle, l.LastName AS LecLast
    FROM AttendanceRecords r
    JOIN AttendanceSessions s ON r.SessionID = s.SessionID
    JOIN Courses c ON r.CourseID = c.CourseID
    JOIN Classrooms cl ON s.ClassroomID = cl.ClassroomID
    JOIN Lecturers l ON s.LecturerID = l.LecturerID
    WHERE r.StudentID = ?
";
$params = [$studentId];

if ($courseFilter > 0) {
    $sql .= " AND r.CourseID = ?";
    $params[] = $courseFilter;
}

if (!empty($statusFilter)) {
    $sql .= " AND r.Status = ?";
    $params[] = $statusFilter;
}

$sql .= " ORDER BY r.MarkedAt DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$records = $stmt->fetchAll();

// Fetch courses for dropdown filter
$stCourses = $pdo->prepare("
    SELECT c.CourseID, c.CourseCode, c.CourseTitle 
    FROM CourseRegistrations cr
    JOIN Courses c ON cr.CourseID = c.CourseID
    WHERE cr.StudentID = ?
    ORDER BY c.CourseCode ASC
");
$stCourses->execute([$studentId]);
$enrolledCourses = $stCourses->fetchAll();

$pageTitle = 'My Attendance History';
require_once dirname(__DIR__) . '/includes/header.php';
?>

<div class="page-header">
    <div>
        <h1 class="page-title"><i class="fas fa-history text-primary"></i> Attendance History</h1>
        <div class="page-subtitle">Verified record of all class attendance entries recorded under your matriculation number</div>
    </div>
    <div>
        <a href="<?= BASE_URL ?>/student/scan.php" class="btn btn-primary">
            <i class="fas fa-camera"></i> Scan New Class
        </a>
    </div>
</div>

<!-- Filters Bar -->
<div class="card mb-4">
    <div class="card-body" style="padding: 1.25rem;">
        <form method="GET" action="<?= BASE_URL ?>/student/history.php" class="d-flex align-items-center gap-3 flex-wrap">
            <div style="flex: 1; min-width: 200px;">
                <label class="form-label" style="font-size: 0.8rem;">Filter by Course</label>
                <select name="course_id" class="form-select">
                    <option value="0">-- All Registered Courses --</option>
                    <?php foreach ($enrolledCourses as $c): ?>
                        <option value="<?= $c['CourseID'] ?>" <?= ($courseFilter === (int)$c['CourseID']) ? 'selected' : '' ?>>
                            <?= htmlspecialchars($c['CourseCode'] . ' - ' . $c['CourseTitle']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div style="width: 170px;">
                <label class="form-label" style="font-size: 0.8rem;">Filter by Status</label>
                <select name="status" class="form-select">
                    <option value="">-- All Statuses --</option>
                    <option value="Present" <?= ($statusFilter === 'Present') ? 'selected' : '' ?>>Present</option>
                    <option value="Late" <?= ($statusFilter === 'Late') ? 'selected' : '' ?>>Late</option>
                    <option value="Excused" <?= ($statusFilter === 'Excused') ? 'selected' : '' ?>>Excused</option>
                </select>
            </div>

            <div style="align-self: flex-end; display: flex; gap: 0.5rem;">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-filter"></i> Filter
                </button>
                <a href="<?= BASE_URL ?>/student/history.php" class="btn btn-outline" title="Reset Filters">
                    <i class="fas fa-undo"></i>
                </a>
            </div>
        </form>
    </div>
</div>

<!-- Records Table -->
<div class="card">
    <div class="card-header">
        <h3 class="card-title"><i class="fas fa-clipboard-check text-primary"></i> Attendance Logs (<?= count($records) ?> records found)</h3>
        <input type="text" class="form-control" placeholder="Search entries..." style="max-width: 250px;" data-table-filter="#history-table">
    </div>
    <div class="table-responsive">
        <table class="table" id="history-table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Course</th>
                    <th>Lecture Date &amp; Time</th>
                    <th>Classroom</th>
                    <th>Lecturer</th>
                    <th>Status</th>
                    <th>Method</th>
                    <th>Recorded Timestamp</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($records)): ?>
                    <tr>
                        <td colspan="8" class="text-center text-muted" style="padding: 2.5rem;">
                            <i class="fas fa-calendar-times fa-2x mb-2" style="display:block; opacity:0.4;"></i>
                            No attendance records found matching your filter criteria.
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($records as $idx => $r): ?>
                        <tr>
                            <td><strong><?= $idx + 1 ?></strong></td>
                            <td>
                                <strong><?= htmlspecialchars($r['CourseCode']) ?></strong>
                                <div class="text-muted" style="font-size: 0.8rem;"><?= htmlspecialchars($r['CourseTitle']) ?></div>
                            </td>
                            <td>
                                <div><?= formatDate($r['SessionDate']) ?></div>
                                <div class="text-muted" style="font-size: 0.775rem;"><?= formatTime($r['StartTime']) ?> - <?= formatTime($r['EndTime']) ?></div>
                            </td>
                            <td>
                                <strong><?= htmlspecialchars($r['RoomCode']) ?></strong>
                                <div class="text-muted" style="font-size: 0.75rem;"><?= htmlspecialchars($r['Building']) ?></div>
                            </td>
                            <td><?= htmlspecialchars($r['LecTitle'] . ' ' . $r['LecLast']) ?></td>
                            <td>
                                <span class="badge <?= ($r['Status'] === 'Present') ? 'badge-success' : (($r['Status'] === 'Late') ? 'badge-warning' : 'badge-info') ?>">
                                    <?= htmlspecialchars($r['Status']) ?>
                                </span>
                            </td>
                            <td>
                                <span class="badge badge-neutral">
                                    <i class="<?= ($r['ScanMethod'] === 'QR_CAMERA') ? 'fas fa-camera' : 'fas fa-keyboard' ?>"></i>
                                    <?= htmlspecialchars($r['ScanMethod']) ?>
                                </span>
                            </td>
                            <td style="font-size: 0.85rem;">
                                <?= formatDateTime($r['MarkedAt']) ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once dirname(__DIR__) . '/includes/footer.php'; ?>
