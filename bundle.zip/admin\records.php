<?php
/**
 * QR Attendance System Using MS SQL and Apache
 * Administrator Portal: Master Attendance Records & Manual Adjustments
 */

require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/includes/functions.php';
require_once dirname(__DIR__) . '/includes/auth_guard.php';

$user = require_role('Admin');
$pdo = Database::getConnection();

$error = null;

// Handle Delete Record
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    if (verify_csrf($_GET['csrf'] ?? '')) {
        $recId = (int)$_GET['id'];
        $pdo->prepare("DELETE FROM AttendanceRecords WHERE RecordID = ?")->execute([$recId]);
        logAudit($user['user_id'], 'ATTENDANCE_RECORD_DELETED', 'ADMIN', "Deleted attendance record #{$recId}");
        flash('success', "Attendance record #{$recId} removed successfully.", 'info');
    }
    header('Location: ' . BASE_URL . '/admin/records.php');
    exit;
}

// Handle Manual Attendance Override (Admin manual mark)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'manual_mark') {
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        $error = 'Session expired. Please try again.';
    } else {
        $sessionId = (int)($_POST['session_id'] ?? 0);
        $studentId = (int)($_POST['student_id'] ?? 0);
        $status = in_array($_POST['status'] ?? '', ['Present', 'Late', 'Excused']) ? $_POST['status'] : 'Present';

        if ($sessionId > 0 && $studentId > 0) {
            try {
                // Get course ID of session
                $stSes = $pdo->prepare("SELECT CourseID FROM AttendanceSessions WHERE SessionID = ?");
                $stSes->execute([$sessionId]);
                $courseId = (int)$stSes->fetchColumn();

                if ($courseId > 0) {
                    $stCheck = $pdo->prepare("SELECT RecordID FROM AttendanceRecords WHERE SessionID = ? AND StudentID = ?");
                    $stCheck->execute([$sessionId, $studentId]);
                    if ($stCheck->fetch()) {
                        $error = 'This student already has an attendance record for this session.';
                    } else {
                        $stIns = $pdo->prepare("
                            INSERT INTO AttendanceRecords (SessionID, StudentID, CourseID, MarkedAt, ScanMethod, Status, IPAddress, UserAgent)
                            VALUES (?, ?, ?, CURRENT_TIMESTAMP, 'ADMIN_OVERRIDE', ?, '127.0.0.1', 'Administrator Manual Adjustment')
                        ");
                        $stIns->execute([$sessionId, $studentId, $courseId, $status]);

                        logAudit($user['user_id'], 'MANUAL_ATTENDANCE_RECORDED', 'ADMIN', "Admin manually marked Student #{$studentId} as {$status} for Session #{$sessionId}");
                        flash('success', 'Manual attendance entry recorded successfully.', 'success');
                        header('Location: ' . BASE_URL . '/admin/records.php');
                        exit;
                    }
                }
            } catch (Exception $e) {
                $error = 'Error recording manual attendance: ' . $e->getMessage();
            }
        }
    }
}

// Filters
$courseFilter = isset($_GET['course_id']) ? (int)$_GET['course_id'] : 0;
$statusFilter = trim($_GET['status'] ?? '');
$methodFilter = trim($_GET['method'] ?? '');

$sql = "
    SELECT r.RecordID, r.MarkedAt, r.ScanMethod, r.Status, r.IPAddress,
           s.SessionDate, s.StartTime,
           c.CourseCode, c.CourseTitle,
           stu.MatricNo, stu.FirstName, stu.LastName,
           cl.RoomCode
    FROM AttendanceRecords r
    JOIN AttendanceSessions s ON r.SessionID = s.SessionID
    JOIN Courses c ON r.CourseID = c.CourseID
    JOIN Students stu ON r.StudentID = stu.StudentID
    JOIN Classrooms cl ON s.ClassroomID = cl.ClassroomID
    WHERE 1=1
";
$params = [];

if ($courseFilter > 0) {
    $sql .= " AND r.CourseID = ?";
    $params[] = $courseFilter;
}
if (!empty($statusFilter)) {
    $sql .= " AND r.Status = ?";
    $params[] = $statusFilter;
}
if (!empty($methodFilter)) {
    $sql .= " AND r.ScanMethod = ?";
    $params[] = $methodFilter;
}

$sql .= " ORDER BY r.RecordID DESC LIMIT 100";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$records = $stmt->fetchAll();

// Dropdown sources
$courses = $pdo->query("SELECT CourseID, CourseCode, CourseTitle FROM Courses ORDER BY CourseCode ASC")->fetchAll();
$activeSessions = $pdo->query("SELECT s.SessionID, s.SessionDate, c.CourseCode, cl.RoomCode FROM AttendanceSessions s JOIN Courses c ON s.CourseID = c.CourseID JOIN Classrooms cl ON s.ClassroomID = cl.ClassroomID ORDER BY s.SessionID DESC LIMIT 20")->fetchAll();
$students = $pdo->query("SELECT StudentID, MatricNo, FirstName, LastName FROM Students ORDER BY MatricNo ASC")->fetchAll();

$pageTitle = 'Master Attendance Records';
require_once dirname(__DIR__) . '/includes/header.php';
?>

<div class="page-header">
    <div>
        <h1 class="page-title"><i class="fas fa-clipboard-list text-primary"></i> Master Attendance Records</h1>
        <div class="page-subtitle">Complete institutional scan ledger &amp; administrator manual adjustments</div>
    </div>
    <div class="d-flex gap-2">
        <a href="<?= BASE_URL ?>/reports/export_csv.php?type=all" class="btn btn-outline">
            <i class="fas fa-download"></i> Export All Records (CSV)
        </a>
    </div>
</div>

<?php if ($error): ?>
    <div class="alert alert-danger"><i class="fas fa-times-circle"></i> <?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<!-- Manual Override Form Card -->
<div class="card mb-4" style="background: #f8fafc; border: 1px solid #cbd5e1;">
    <div class="card-header" style="background: #ffffff;">
        <h3 class="card-title"><i class="fas fa-user-edit text-primary"></i> Manual Attendance Override / Check-in</h3>
    </div>
    <div class="card-body">
        <p class="text-muted" style="font-size: 0.85rem; margin-bottom: 1rem;">
            Use this administrative action to mark a student who had device difficulties or camera failure during a live lecture.
        </p>
        <form action="<?= BASE_URL ?>/admin/records.php" method="POST" class="d-flex align-items-center gap-3 flex-wrap">
            <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
            <input type="hidden" name="action" value="manual_mark">

            <div style="flex: 1; min-width: 250px;">
                <label class="form-label" style="font-size: 0.8rem;">Select Session *</label>
                <select name="session_id" class="form-select" required>
                    <option value="">-- Choose Session --</option>
                    <?php foreach ($activeSessions as $ses): ?>
                        <option value="<?= $ses['SessionID'] ?>">
                            #<?= $ses['SessionID'] ?> &bull; <?= htmlspecialchars($ses['CourseCode']) ?> &bull; <?= $ses['SessionDate'] ?> (<?= $ses['RoomCode'] ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div style="flex: 1; min-width: 250px;">
                <label class="form-label" style="font-size: 0.8rem;">Select Student *</label>
                <select name="student_id" class="form-select" required>
                    <option value="">-- Choose Student --</option>
                    <?php foreach ($students as $s): ?>
                        <option value="<?= $s['StudentID'] ?>">
                            <?= htmlspecialchars($s['MatricNo'] . ' - ' . $s['FirstName'] . ' ' . $s['LastName']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div style="width: 140px;">
                <label class="form-label" style="font-size: 0.8rem;">Status</label>
                <select name="status" class="form-select">
                    <option value="Present">Present</option>
                    <option value="Late">Late</option>
                    <option value="Excused">Excused</option>
                </select>
            </div>

            <div style="align-self: flex-end;">
                <button type="submit" class="btn btn-primary"><i class="fas fa-check-circle"></i> Commit Entry</button>
            </div>
        </form>
    </div>
</div>

<!-- Filters Bar -->
<div class="card mb-4">
    <div class="card-body" style="padding: 1.25rem;">
        <form method="GET" action="<?= BASE_URL ?>/admin/records.php" class="d-flex align-items-center gap-3 flex-wrap">
            <div style="flex: 1; min-width: 200px;">
                <label class="form-label" style="font-size: 0.8rem;">Filter by Course</label>
                <select name="course_id" class="form-select">
                    <option value="0">-- All Courses --</option>
                    <?php foreach ($courses as $c): ?>
                        <option value="<?= $c['CourseID'] ?>" <?= ($courseFilter === (int)$c['CourseID']) ? 'selected' : '' ?>>
                            <?= htmlspecialchars($c['CourseCode'] . ' - ' . $c['CourseTitle']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div style="width: 150px;">
                <label class="form-label" style="font-size: 0.8rem;">Status</label>
                <select name="status" class="form-select">
                    <option value="">-- All --</option>
                    <option value="Present" <?= ($statusFilter === 'Present') ? 'selected' : '' ?>>Present</option>
                    <option value="Late" <?= ($statusFilter === 'Late') ? 'selected' : '' ?>>Late</option>
                    <option value="Excused" <?= ($statusFilter === 'Excused') ? 'selected' : '' ?>>Excused</option>
                </select>
            </div>

            <div style="width: 170px;">
                <label class="form-label" style="font-size: 0.8rem;">Scan Method</label>
                <select name="method" class="form-select">
                    <option value="">-- All Methods --</option>
                    <option value="QR_CAMERA" <?= ($methodFilter === 'QR_CAMERA') ? 'selected' : '' ?>>QR Camera</option>
                    <option value="MANUAL_TOKEN" <?= ($methodFilter === 'MANUAL_TOKEN') ? 'selected' : '' ?>>Manual Token</option>
                    <option value="ADMIN_OVERRIDE" <?= ($methodFilter === 'ADMIN_OVERRIDE') ? 'selected' : '' ?>>Admin Override</option>
                </select>
            </div>

            <div style="align-self: flex-end; display: flex; gap: 0.5rem;">
                <button type="submit" class="btn btn-primary"><i class="fas fa-filter"></i> Filter</button>
                <a href="<?= BASE_URL ?>/admin/records.php" class="btn btn-outline"><i class="fas fa-undo"></i></a>
            </div>
        </form>
    </div>
</div>

<!-- Master Records Table -->
<div class="card">
    <div class="card-header">
        <h3 class="card-title"><i class="fas fa-list-ol text-primary"></i> Attendance Scan Ledger (<?= count($records) ?> records)</h3>
        <input type="text" class="form-control" placeholder="Search student or course..." style="max-width: 250px;" data-table-filter="#records-table">
    </div>
    <div class="table-responsive">
        <table class="table" id="records-table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Matriculation No</th>
                    <th>Student Name</th>
                    <th>Course Code</th>
                    <th>Room</th>
                    <th>Status</th>
                    <th>Scan Method</th>
                    <th>Timestamp</th>
                    <th class="text-right">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($records)): ?>
                    <tr><td colspan="9" class="text-center text-muted" style="padding: 2.5rem;">No attendance records found.</td></tr>
                <?php else: ?>
                    <?php foreach ($records as $r): ?>
                        <tr>
                            <td><strong><?= $r['RecordID'] ?></strong></td>
                            <td><strong><?= htmlspecialchars($r['MatricNo']) ?></strong></td>
                            <td><?= htmlspecialchars($r['FirstName'] . ' ' . $r['LastName']) ?></td>
                            <td><strong style="color: #1e3a8a;"><?= htmlspecialchars($r['CourseCode']) ?></strong></td>
                            <td><span class="badge badge-neutral"><?= htmlspecialchars($r['RoomCode']) ?></span></td>
                            <td>
                                <span class="badge <?= ($r['Status'] === 'Present') ? 'badge-success' : (($r['Status'] === 'Late') ? 'badge-warning' : 'badge-info') ?>">
                                    <?= htmlspecialchars($r['Status']) ?>
                                </span>
                            </td>
                            <td>
                                <span class="badge badge-neutral">
                                    <i class="<?= ($r['ScanMethod'] === 'QR_CAMERA') ? 'fas fa-camera' : 'fas fa-cog' ?>"></i>
                                    <?= htmlspecialchars($r['ScanMethod']) ?>
                                </span>
                            </td>
                            <td style="font-size: 0.85rem;"><?= formatDateTime($r['MarkedAt']) ?></td>
                            <td class="text-right">
                                <a href="<?= BASE_URL ?>/admin/records.php?action=delete&id=<?= $r['RecordID'] ?>&csrf=<?= csrf_token() ?>" 
                                   class="btn btn-danger btn-sm" data-confirm="Remove this attendance entry for <?= htmlspecialchars($r['MatricNo']) ?>?" title="Delete Record">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once dirname(__DIR__) . '/includes/footer.php'; ?>
