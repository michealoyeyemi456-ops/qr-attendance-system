<?php
/**
 * QR Attendance System Using MS SQL and Apache
 * API Endpoint: Session Status & Auth Info
 */

require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/includes/functions.php';

header('Content-Type: application/json; charset=utf-8');

if (empty($_SESSION['user_id'])) {
    jsonResponse([
        'authenticated' => false,
        'user' => null
    ]);
}

jsonResponse([
    'authenticated' => true,
    'user' => [
        'id' => $_SESSION['user_id'],
        'username' => $_SESSION['username'],
        'role' => $_SESSION['user_role'],
        'fullname' => $_SESSION['user_fullname'] ?? $_SESSION['username'],
        'status' => $_SESSION['user_status'] ?? 'Active'
    ]
]);
