<?php
/**
 * QR Attendance System Using MS SQL and Apache
 * Administrator Portal: Manage Students (Full CRUD)
 */

require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/includes/functions.php';
require_once dirname(__DIR__) . '/includes/auth_guard.php';

$user = require_role('Admin');
$pdo = Database::getConnection();

$action = $_GET['action'] ?? 'list';
$studentId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$error = null;

// Handle DELETE
if ($action === 'delete' && $studentId > 0) {
    if (verify_csrf($_GET['csrf'] ?? '')) {
        try {
            // Find user ID
            $stU = $pdo->prepare("SELECT UserID, MatricNo FROM Students WHERE StudentID = ?");
            $stU->execute([$studentId]);
            $stu = $stU->fetch();
            if ($stu) {
                // Delete user account (foreign key cascade deletes student & registrations)
                $pdo->prepare("DELETE FROM Users WHERE UserID = ?")->execute([$stu['UserID']]);
                logAudit($user['user_id'], 'STUDENT_DELETED', 'ADMIN', "Deleted student {$stu['MatricNo']}");
                flash('success', "Student record {$stu['MatricNo']} deleted successfully.", 'info');
            }
        } catch (Exception $e) {
            flash('danger', 'Error deleting student: ' . $e->getMessage(), 'danger');
        }
    }
    header('Location: ' . BASE_URL . '/admin/students.php');
    exit;
}

// Handle CREATE / UPDATE Form Post
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        $error = 'Session expired. Please try again.';
    } else {
        $matricNo = strtoupper(trim($_POST['matric_no'] ?? ''));
        $firstName = trim($_POST['first_name'] ?? '');
        $lastName = trim($_POST['last_name'] ?? '');
        $email = strtolower(trim($_POST['email'] ?? ''));
        $phone = trim($_POST['phone'] ?? '');
        $deptId = (int)($_POST['department_id'] ?? 0);
        $progId = (int)($_POST['programme_id'] ?? 0);
        $levelId = (int)($_POST['level_id'] ?? 0);
        $status = in_array($_POST['status'] ?? '', ['Active', 'Inactive', 'Suspended']) ? $_POST['status'] : 'Active';
        $password = trim($_POST['password'] ?? '');

        if (empty($matricNo) || empty($firstName) || empty($lastName) || empty($email) || $deptId <= 0 || $progId <= 0 || $levelId <= 0) {
            $error = 'Please fill all required fields correctly.';
        } else {
            try {
                if ($action === 'create') {
                    // Check duplicate matric or email
                    $stCheck = $pdo->prepare("SELECT UserID FROM Users WHERE LOWER(Username) = LOWER(?) OR LOWER(Email) = LOWER(?)");
                    $stCheck->execute([$matricNo, $email]);
                    if ($stCheck->fetch()) {
                        $error = 'A user account with this Matriculation Number or Email already exists.';
                    } else {
                        $passHash = password_hash(!empty($password) ? $password : 'Password123!', PASSWORD_BCRYPT);
                        
                        // Insert into Users
                        $stUser = $pdo->prepare("INSERT INTO Users (Username, PasswordHash, Email, Role, Status) VALUES (?, ?, ?, 'Student', ?)");
                        $stUser->execute([$matricNo, $passHash, $email, $status]);
                        $newUserId = (int)$pdo->lastInsertId();

                        // Insert into Students
                        $stStu = $pdo->prepare("
                            INSERT INTO Students (UserID, DepartmentID, ProgrammeID, LevelID, MatricNo, FirstName, LastName, Phone, AcademicSession)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                        ");
                        $stStu->execute([$newUserId, $deptId, $progId, $levelId, $matricNo, $firstName, $lastName, $phone, CURRENT_ACADEMIC_SESSION]);

                        logAudit($user['user_id'], 'STUDENT_CREATED', 'ADMIN', "Created student profile {$matricNo} ({$firstName} {$lastName})");
                        flash('success', "Student {$matricNo} successfully created.", 'success');
                        header('Location: ' . BASE_URL . '/admin/students.php');
                        exit;
                    }
                } elseif ($action === 'edit' && $studentId > 0) {
                    $stGet = $pdo->prepare("SELECT UserID FROM Students WHERE StudentID = ?");
                    $stGet->execute([$studentId]);
                    $currentUserId = (int)$stGet->fetchColumn();

                    if ($currentUserId > 0) {
                        // Update User
                        if (!empty($password)) {
                            $passHash = password_hash($password, PASSWORD_BCRYPT);
                            $pdo->prepare("UPDATE Users SET Email = ?, Status = ?, PasswordHash = ? WHERE UserID = ?")->execute([$email, $status, $passHash, $currentUserId]);
                        } else {
                            $pdo->prepare("UPDATE Users SET Email = ?, Status = ? WHERE UserID = ?")->execute([$email, $status, $currentUserId]);
                        }

                        // Update Student
                        $stUpd = $pdo->prepare("
                            UPDATE Students SET MatricNo = ?, FirstName = ?, LastName = ?, Phone = ?, DepartmentID = ?, ProgrammeID = ?, LevelID = ?
                            WHERE StudentID = ?
                        ");
                        $stUpd->execute([$matricNo, $firstName, $lastName, $phone, $deptId, $progId, $levelId, $studentId]);

                        logAudit($user['user_id'], 'STUDENT_UPDATED', 'ADMIN', "Updated student profile {$matricNo}");
                        flash('success', "Student record {$matricNo} updated successfully.", 'success');
                        header('Location: ' . BASE_URL . '/admin/students.php');
                        exit;
                    }
                }
            } catch (Exception $e) {
                $error = 'Database operation error: ' . $e->getMessage();
            }
        }
    }
}

// Fetch auxiliary data for dropdowns
$departments = $pdo->query("SELECT DepartmentID, DepartmentCode, DepartmentName FROM Departments ORDER BY DepartmentName ASC")->fetchAll();
$programmes = $pdo->query("SELECT ProgrammeID, ProgrammeCode, ProgrammeName FROM Programmes ORDER BY ProgrammeName ASC")->fetchAll();
$levels = $pdo->query("SELECT LevelID, LevelCode, LevelName FROM Levels ORDER BY LevelID ASC")->fetchAll();

// Edit view data
$editStudent = null;
if ($action === 'edit' && $studentId > 0) {
    $stEd = $pdo->prepare("
        SELECT s.*, u.Email, u.Status AS AccountStatus
        FROM Students s
        JOIN Users u ON s.UserID = u.UserID
        WHERE s.StudentID = ?
    ");
    $stEd->execute([$studentId]);
    $editStudent = $stEd->fetch();
}

// Filter List
$deptFilter = isset($_GET['dept']) ? (int)$_GET['dept'] : 0;
$sqlList = "
    SELECT s.StudentID, s.MatricNo, s.FirstName, s.LastName, s.Phone,
           d.DepartmentCode, d.DepartmentName, p.ProgrammeCode, l.LevelCode,
           u.Email, u.Status, u.LastLogin,
           (SELECT COUNT(*) FROM CourseRegistrations cr WHERE cr.StudentID = s.StudentID) AS EnrolledCount
    FROM Students s
    JOIN Users u ON s.UserID = u.UserID
    JOIN Departments d ON s.DepartmentID = d.DepartmentID
    JOIN Programmes p ON s.ProgrammeID = p.ProgrammeID
    JOIN Levels l ON s.LevelID = l.LevelID
";
if ($deptFilter > 0) {
    $sqlList .= " WHERE s.DepartmentID = {$deptFilter}";
}
$sqlList .= " ORDER BY s.MatricNo ASC";
$studentsList = $pdo->query($sqlList)->fetchAll();

$pageTitle = 'Manage Students';
require_once dirname(__DIR__) . '/includes/header.php';
?>

<div class="page-header">
    <div>
        <h1 class="page-title"><i class="fas fa-user-graduate text-primary"></i> Manage Students</h1>
        <div class="page-subtitle">Undergraduate &amp; postgraduate student enrolment management</div>
    </div>
    <div>
        <?php if ($action !== 'create'): ?>
            <a href="<?= BASE_URL ?>/admin/students.php?action=create" class="btn btn-primary">
                <i class="fas fa-plus-circle"></i> Add New Student
            </a>
        <?php else: ?>
            <a href="<?= BASE_URL ?>/admin/students.php" class="btn btn-outline">
                <i class="fas fa-arrow-left"></i> Back to Student List
            </a>
        <?php endif; ?>
    </div>
</div>

<?php if ($error): ?>
    <div class="alert alert-danger"><i class="fas fa-times-circle"></i> <?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<?php if ($action === 'create' || $action === 'edit'): ?>
    <!-- Form Card -->
    <div class="card" style="max-width: 800px; margin: 0 auto 2rem;">
        <div class="card-header">
            <h3 class="card-title">
                <i class="fas <?= ($action === 'create') ? 'fa-user-plus' : 'fa-user-edit' ?> text-primary"></i>
                <?= ($action === 'create') ? 'Register New Student' : 'Edit Student Profile' ?>
            </h3>
        </div>
        <div class="card-body">
            <form action="<?= BASE_URL ?>/admin/students.php?action=<?= $action ?><?= ($action === 'edit') ? "&id={$studentId}" : '' ?>" method="POST">
                <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                    <div class="form-group">
                        <label class="form-label" for="matric_no">Matriculation Number *</label>
                        <input type="text" id="matric_no" name="matric_no" class="form-control" 
                               value="<?= htmlspecialchars($editStudent['MatricNo'] ?? '') ?>" 
                               placeholder="e.g. FITAS/HND/CSC/24/001" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="email">Student Email *</label>
                        <input type="email" id="email" name="email" class="form-control" 
                               value="<?= htmlspecialchars($editStudent['Email'] ?? '') ?>" 
                               placeholder="student@fitas.edu.ng" required>
                    </div>
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                    <div class="form-group">
                        <label class="form-label" for="first_name">First Name *</label>
                        <input type="text" id="first_name" name="first_name" class="form-control" 
                               value="<?= htmlspecialchars($editStudent['FirstName'] ?? '') ?>" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="last_name">Last Name *</label>
                        <input type="text" id="last_name" name="last_name" class="form-control" 
                               value="<?= htmlspecialchars($editStudent['LastName'] ?? '') ?>" required>
                    </div>
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 1rem;">
                    <div class="form-group">
                        <label class="form-label" for="department_id">Department *</label>
                        <select name="department_id" id="department_id" class="form-select" required>
                            <option value="">-- Select --</option>
                            <?php foreach ($departments as $d): ?>
                                <option value="<?= $d['DepartmentID'] ?>" <?= (($editStudent['DepartmentID'] ?? 0) == $d['DepartmentID']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($d['DepartmentCode'] . ' - ' . $d['DepartmentName']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="programme_id">Programme *</label>
                        <select name="programme_id" id="programme_id" class="form-select" required>
                            <option value="">-- Select --</option>
                            <?php foreach ($programmes as $p): ?>
                                <option value="<?= $p['ProgrammeID'] ?>" <?= (($editStudent['ProgrammeID'] ?? 0) == $p['ProgrammeID']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($p['ProgrammeCode']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="level_id">Level *</label>
                        <select name="level_id" id="level_id" class="form-select" required>
                            <option value="">-- Select --</option>
                            <?php foreach ($levels as $l): ?>
                                <option value="<?= $l['LevelID'] ?>" <?= (($editStudent['LevelID'] ?? 0) == $l['LevelID']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($l['LevelCode']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 1rem;">
                    <div class="form-group">
                        <label class="form-label" for="phone">Phone Number</label>
                        <input type="text" id="phone" name="phone" class="form-control" 
                               value="<?= htmlspecialchars($editStudent['Phone'] ?? '') ?>" placeholder="08012345678">
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="status">Account Status</label>
                        <select name="status" id="status" class="form-select">
                            <option value="Active" <?= (($editStudent['AccountStatus'] ?? 'Active') === 'Active') ? 'selected' : '' ?>>Active</option>
                            <option value="Inactive" <?= (($editStudent['AccountStatus'] ?? '') === 'Inactive') ? 'selected' : '' ?>>Inactive</option>
                            <option value="Suspended" <?= (($editStudent['AccountStatus'] ?? '') === 'Suspended') ? 'selected' : '' ?>>Suspended</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="password">Password <?= ($action === 'create') ? '(Optional)' : '(Leave blank to keep)' ?></label>
                        <input type="password" id="password" name="password" class="form-control" placeholder="<?= ($action === 'create') ? 'Defaults to Password123!' : '••••••••' ?>">
                    </div>
                </div>

                <div class="d-flex gap-2 justify-between mt-3">
                    <a href="<?= BASE_URL ?>/admin/students.php" class="btn btn-outline">Cancel</a>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> <?= ($action === 'create') ? 'Save Student Record' : 'Update Student' ?>
                    </button>
                </div>
            </form>
        </div>
    </div>
<?php endif; ?>

<!-- Students List Table -->
<div class="card">
    <div class="card-header">
        <h3 class="card-title"><i class="fas fa-users text-primary"></i> Registered Students Directory (<?= count($studentsList) ?>)</h3>
        <input type="text" class="form-control" placeholder="Search matric, name..." style="max-width: 250px;" data-table-filter="#students-table">
    </div>
    <div class="table-responsive">
        <table class="table" id="students-table">
            <thead>
                <tr>
                    <th>Matriculation No</th>
                    <th>Full Name</th>
                    <th>Dept &amp; Level</th>
                    <th>Email / Phone</th>
                    <th>Enrolled Courses</th>
                    <th>Status</th>
                    <th class="text-right">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($studentsList)): ?>
                    <tr><td colspan="7" class="text-center text-muted" style="padding: 2.5rem;">No student records found.</td></tr>
                <?php else: ?>
                    <?php foreach ($studentsList as $s): ?>
                        <tr>
                            <td><strong><?= htmlspecialchars($s['MatricNo']) ?></strong></td>
                            <td><?= htmlspecialchars($s['FirstName'] . ' ' . $s['LastName']) ?></td>
                            <td><?= htmlspecialchars($s['DepartmentCode']) ?> &bull; <span class="badge badge-neutral"><?= htmlspecialchars($s['LevelCode']) ?></span></td>
                            <td>
                                <div><?= htmlspecialchars($s['Email']) ?></div>
                                <div class="text-muted" style="font-size: 0.775rem;"><?= htmlspecialchars($s['Phone'] ?: 'N/A') ?></div>
                            </td>
                            <td><span class="badge badge-info"><?= $s['EnrolledCount'] ?> Courses</span></td>
                            <td>
                                <span class="badge <?= ($s['Status'] === 'Active') ? 'badge-success' : (($s['Status'] === 'Suspended') ? 'badge-danger' : 'badge-neutral') ?>">
                                    <?= htmlspecialchars($s['Status']) ?>
                                </span>
                            </td>
                            <td class="text-right">
                                <a href="<?= BASE_URL ?>/admin/students.php?action=edit&id=<?= $s['StudentID'] ?>" class="btn btn-outline btn-sm" title="Edit Student">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <a href="<?= BASE_URL ?>/admin/students.php?action=delete&id=<?= $s['StudentID'] ?>&csrf=<?= csrf_token() ?>" 
                                   class="btn btn-danger btn-sm" 
                                   data-confirm="Are you sure you want to permanently remove student <?= htmlspecialchars($s['MatricNo']) ?>? All attendance records will be deleted." 
                                   title="Delete Student">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once dirname(__DIR__) . '/includes/footer.php'; ?>
