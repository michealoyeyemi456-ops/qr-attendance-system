<?php
/**
 * QR Attendance System Using MS SQL and Apache
 * Student Portal: Registered Courses & Exam Eligibility Breakdown
 */

require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/includes/functions.php';
require_once dirname(__DIR__) . '/includes/auth_guard.php';

$user = require_role('Student');
$pdo = Database::getConnection();

// Fetch Student ID
$stStu = $pdo->prepare("SELECT StudentID, MatricNo, FirstName, LastName FROM Students WHERE UserID = ?");
$stStu->execute([$user['user_id']]);
$student = $stStu->fetch();
$studentId = (int)$student['StudentID'];

// Fetch registered courses
$stCourses = $pdo->prepare("
    SELECT c.CourseID, c.CourseCode, c.CourseTitle, c.CreditUnits, c.Semester,
           d.DepartmentName,
           l.Title AS LecTitle, l.FirstName AS LecFirst, l.LastName AS LecLast, l.OfficeNumber,
           u.Email AS LecEmail
    FROM CourseRegistrations cr
    JOIN Courses c ON cr.CourseID = c.CourseID
    JOIN Departments d ON c.DepartmentID = d.DepartmentID
    LEFT JOIN CourseLecturers cl ON c.CourseID = cl.CourseID
    LEFT JOIN Lecturers l ON cl.LecturerID = l.LecturerID
    LEFT JOIN Users u ON l.UserID = u.UserID
    WHERE cr.StudentID = ?
    ORDER BY c.CourseCode ASC
");
$stCourses->execute([$studentId]);
$courses = $stCourses->fetchAll();

$pageTitle = 'My Registered Courses';
require_once dirname(__DIR__) . '/includes/header.php';
?>

<div class="page-header">
    <div>
        <h1 class="page-title"><i class="fas fa-book-open text-primary"></i> Registered Courses &amp; Eligibility</h1>
        <div class="page-subtitle"><?= CURRENT_ACADEMIC_SESSION ?> &bull; <?= CURRENT_SEMESTER ?> &bull; Exam Eligibility Threshold: &ge; <?= ATTENDANCE_THRESHOLD_PERCENT ?>%</div>
    </div>
    <div>
        <a href="<?= BASE_URL ?>/student/scan.php" class="btn btn-accent">
            <i class="fas fa-camera"></i> Scan Classroom QR
        </a>
    </div>
</div>

<div class="card mb-4" style="background-color: #f8fafc; border-left: 4px solid var(--primary);">
    <div class="card-body" style="padding: 1rem 1.5rem; font-size: 0.875rem;">
        <i class="fas fa-info-circle text-primary"></i> 
        <strong>Academic Policy Note:</strong> According to institutional regulations, students are required to achieve a minimum of <strong><?= ATTENDANCE_THRESHOLD_PERCENT ?>% attendance</strong> in every course to qualify to sit for the semester examination.
    </div>
</div>

<div class="card">
    <div class="card-header">
        <h3 class="card-title"><i class="fas fa-list text-primary"></i> Enrolled Courses (<?= count($courses) ?>)</h3>
        <input type="text" class="form-control" placeholder="Search courses..." style="max-width: 250px;" data-table-filter="#courses-table">
    </div>
    <div class="table-responsive">
        <table class="table" id="courses-table">
            <thead>
                <tr>
                    <th>Course</th>
                    <th>Credits</th>
                    <th>Lecturer &amp; Office</th>
                    <th>Attendance (Attended / Held)</th>
                    <th>Attendance %</th>
                    <th>Exam Status</th>
                    <th class="text-right">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($courses)): ?>
                    <tr>
                        <td colspan="7" class="text-center text-muted" style="padding: 2rem;">You are not currently enrolled in any courses for this semester.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($courses as $c): 
                        $att = calculateAttendancePercent($studentId, (int)$c['CourseID']);
                        $barClass = ($att['percentage'] >= ATTENDANCE_THRESHOLD_PERCENT) ? 'progress-success' : (($att['percentage'] >= 60) ? 'progress-warning' : 'progress-danger');
                    ?>
                        <tr>
                            <td>
                                <strong style="font-size: 1rem; color: #1e3a8a;"><?= htmlspecialchars($c['CourseCode']) ?></strong>
                                <div style="font-size: 0.85rem; color: #334155;"><?= htmlspecialchars($c['CourseTitle']) ?></div>
                            </td>
                            <td><span class="badge badge-neutral"><?= $c['CreditUnits'] ?> Units</span></td>
                            <td>
                                <div><?= htmlspecialchars(($c['LecTitle'] ?? '') . ' ' . ($c['LecFirst'] ?? '') . ' ' . ($c['LecLast'] ?? 'Faculty Staff')) ?></div>
                                <?php if (!empty($c['OfficeNumber'])): ?>
                                    <div class="text-muted" style="font-size: 0.775rem;"><i class="fas fa-door-open"></i> <?= htmlspecialchars($c['OfficeNumber']) ?></div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <strong><?= $att['attended'] ?></strong> of <?= $att['total'] ?> sessions
                            </td>
                            <td style="min-width: 160px;">
                                <div class="d-flex align-items-center gap-2">
                                    <span style="font-weight: 700; width: 45px;"><?= $att['percentage'] ?>%</span>
                                    <div class="progress-bar-container" style="flex:1;">
                                        <div class="progress-bar-fill <?= $barClass ?>" style="width: <?= min(100, $att['percentage']) ?>%;"></div>
                                    </div>
                                </div>
                            </td>
                            <td><?= getEligibilityBadge($att['percentage']) ?></td>
                            <td class="text-right">
                                <a href="<?= BASE_URL ?>/student/history.php?course_id=<?= $c['CourseID'] ?>" class="btn btn-outline btn-sm" title="View Class Logs">
                                    <i class="fas fa-eye"></i> View Logs
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once dirname(__DIR__) . '/includes/footer.php'; ?>
