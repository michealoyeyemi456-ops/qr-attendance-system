<?php
/**
 * QR Attendance System Using MS SQL and Apache
 * Lecturer Portal: Attendance Sessions History & Records
 */

require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/includes/functions.php';
require_once dirname(__DIR__) . '/includes/auth_guard.php';

$user = require_role('Lecturer');
$pdo = Database::getConnection();

// Fetch lecturer ID
$stLec = $pdo->prepare("SELECT LecturerID FROM Lecturers WHERE UserID = ?");
$stLec->execute([$user['user_id']]);
$lecturerId = (int)$stLec->fetchColumn();

// Filter parameters
$courseFilter = isset($_GET['course_id']) ? (int)$_GET['course_id'] : 0;
$dateFilter = trim($_GET['session_date'] ?? '');

$sql = "
    SELECT s.SessionID, s.SessionDate, s.StartTime, s.EndTime, s.DurationMinutes, s.SessionToken, s.Status,
           c.CourseID, c.CourseCode, c.CourseTitle,
           cl.RoomCode, cl.RoomName,
           (SELECT COUNT(*) FROM AttendanceRecords r WHERE r.SessionID = s.SessionID) AS AttendeesCount,
           (SELECT COUNT(*) FROM CourseRegistrations cr WHERE cr.CourseID = s.CourseID) AS RegisteredCount
    FROM AttendanceSessions s
    JOIN Courses c ON s.CourseID = c.CourseID
    JOIN Classrooms cl ON s.ClassroomID = cl.ClassroomID
    WHERE s.LecturerID = ?
";
$params = [$lecturerId];

if ($courseFilter > 0) {
    $sql .= " AND s.CourseID = ?";
    $params[] = $courseFilter;
}

if (!empty($dateFilter)) {
    $sql .= " AND s.SessionDate = ?";
    $params[] = $dateFilter;
}

$sql .= " ORDER BY s.SessionDate DESC, s.StartTime DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$sessions = $stmt->fetchAll();

// Fetch courses for filter
$courses = $pdo->prepare("SELECT c.CourseID, c.CourseCode, c.CourseTitle FROM CourseLecturers cl JOIN Courses c ON cl.CourseID = c.CourseID WHERE cl.LecturerID = ?");
$courses->execute([$lecturerId]);
$coursesList = $courses->fetchAll();

$pageTitle = 'Session Attendance Records';
require_once dirname(__DIR__) . '/includes/header.php';
?>

<div class="page-header">
    <div>
        <h1 class="page-title"><i class="fas fa-list-alt text-primary"></i> Attendance Sessions History</h1>
        <div class="page-subtitle">Historical log of all QR attendance sessions generated for your classes</div>
    </div>
    <div>
        <a href="<?= BASE_URL ?>/lecturer/create_session.php" class="btn btn-primary">
            <i class="fas fa-plus-circle"></i> Start New Session
        </a>
    </div>
</div>

<!-- Filters Bar -->
<div class="card mb-4">
    <div class="card-body" style="padding: 1.25rem;">
        <form method="GET" action="<?= BASE_URL ?>/lecturer/records.php" class="d-flex align-items-center gap-3 flex-wrap">
            <div style="flex: 1; min-width: 220px;">
                <label class="form-label" style="font-size: 0.8rem;">Filter by Course</label>
                <select name="course_id" class="form-select">
                    <option value="0">-- All Courses --</option>
                    <?php foreach ($coursesList as $c): ?>
                        <option value="<?= $c['CourseID'] ?>" <?= ($courseFilter === (int)$c['CourseID']) ? 'selected' : '' ?>>
                            <?= htmlspecialchars($c['CourseCode'] . ' - ' . $c['CourseTitle']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div style="width: 180px;">
                <label class="form-label" style="font-size: 0.8rem;">Filter by Date</label>
                <input type="date" name="session_date" class="form-control" value="<?= htmlspecialchars($dateFilter) ?>">
            </div>

            <div style="align-self: flex-end; display: flex; gap: 0.5rem;">
                <button type="submit" class="btn btn-primary"><i class="fas fa-filter"></i> Filter</button>
                <a href="<?= BASE_URL ?>/lecturer/records.php" class="btn btn-outline" title="Reset"><i class="fas fa-undo"></i></a>
            </div>
        </form>
    </div>
</div>

<!-- Sessions Table -->
<div class="card">
    <div class="card-header">
        <h3 class="card-title"><i class="fas fa-calendar-check text-primary"></i> Sessions List (<?= count($sessions) ?>)</h3>
        <input type="text" class="form-control" placeholder="Search sessions..." style="max-width: 250px;" data-table-filter="#sessions-table">
    </div>
    <div class="table-responsive">
        <table class="table" id="sessions-table">
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Course Code &amp; Title</th>
                    <th>Room</th>
                    <th>Time Window</th>
                    <th>Turnout (Attended / Enrolled)</th>
                    <th>Turnout %</th>
                    <th>Status</th>
                    <th class="text-right">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($sessions)): ?>
                    <tr>
                        <td colspan="8" class="text-center text-muted" style="padding: 2.5rem;">No attendance sessions found.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($sessions as $ses): 
                        $rate = ($ses['RegisteredCount'] > 0) ? round(($ses['AttendeesCount'] / $ses['RegisteredCount']) * 100, 1) : 0;
                    ?>
                        <tr>
                            <td><strong><?= formatDate($ses['SessionDate']) ?></strong></td>
                            <td>
                                <strong style="color: #1e3a8a;"><?= htmlspecialchars($ses['CourseCode']) ?></strong>
                                <div class="text-muted" style="font-size: 0.8rem;"><?= htmlspecialchars($ses['CourseTitle']) ?></div>
                            </td>
                            <td><?= htmlspecialchars($ses['RoomCode']) ?></td>
                            <td><?= formatTime($ses['StartTime']) ?> - <?= formatTime($ses['EndTime']) ?></td>
                            <td><strong><?= $ses['AttendeesCount'] ?></strong> of <?= $ses['RegisteredCount'] ?></td>
                            <td>
                                <span class="badge <?= ($rate >= 75) ? 'badge-success' : (($rate >= 50) ? 'badge-warning' : 'badge-danger') ?>">
                                    <?= $rate ?>%
                                </span>
                            </td>
                            <td>
                                <span class="badge <?= ($ses['Status'] === 'Active') ? 'badge-success' : 'badge-neutral' ?>">
                                    <?= htmlspecialchars($ses['Status']) ?>
                                </span>
                            </td>
                            <td class="text-right">
                                <a href="<?= BASE_URL ?>/lecturer/active_session.php?session_id=<?= $ses['SessionID'] ?>" class="btn btn-outline btn-sm" title="View Projector / Roster">
                                    <i class="fas fa-tv"></i> Projector / Roster
                                </a>
                                <a href="<?= BASE_URL ?>/reports/export_csv.php?session_id=<?= $ses['SessionID'] ?>" class="btn btn-outline btn-sm" title="Export CSV">
                                    <i class="fas fa-download"></i> CSV
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once dirname(__DIR__) . '/includes/footer.php'; ?>
