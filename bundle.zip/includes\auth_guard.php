<?php
/**
 * QR Attendance System Using MS SQL and Apache
 * Authentication & Role Authorization Guard
 */

if (!defined('APP_INIT')) {
    require_once dirname(__DIR__) . '/config/config.php';
    require_once dirname(__DIR__) . '/config/database.php';
    require_once dirname(__DIR__) . '/includes/functions.php';
}

// Ensure session is active
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * Require User to be Authenticated
 */
function require_auth(): array {
    if (empty($_SESSION['user_id']) || empty($_SESSION['user_role'])) {
        flash('auth_error', 'Please log in to access this page.', 'warning');
        header('Location: ' . BASE_URL . '/auth/login.php');
        exit;
    }

    // Verify account status
    if (isset($_SESSION['user_status']) && $_SESSION['user_status'] !== 'Active') {
        $status = $_SESSION['user_status'];
        session_unset();
        session_destroy();
        session_start();
        flash('auth_error', "Your account is currently {$status}. Please contact the system administrator.", 'danger');
        header('Location: ' . BASE_URL . '/auth/login.php');
        exit;
    }

    return [
        'user_id' => $_SESSION['user_id'],
        'username' => $_SESSION['username'],
        'email' => $_SESSION['user_email'] ?? '',
        'role' => $_SESSION['user_role'],
        'status' => $_SESSION['user_status'] ?? 'Active',
        'profile_id' => $_SESSION['profile_id'] ?? null,
        'full_name' => $_SESSION['user_fullname'] ?? $_SESSION['username']
    ];
}

/**
 * Require specific Role(s)
 * @param array|string $allowedRoles
 */
function require_role($allowedRoles): array {
    $user = require_auth();
    $roles = is_array($allowedRoles) ? $allowedRoles : [$allowedRoles];

    if (!in_array($user['role'], $roles)) {
        logAudit($user['user_id'], 'UNAUTHORIZED_ACCESS_ATTEMPT', 'AUTH', "Role {$user['role']} attempted to access unauthorized route restricted to: " . implode(', ', $roles));
        flash('auth_error', 'You do not have permission to access that section.', 'danger');
        
        // Redirect to user's respective portal
        switch ($user['role']) {
            case 'Admin':
                header('Location: ' . BASE_URL . '/admin/index.php');
                break;
            case 'Lecturer':
                header('Location: ' . BASE_URL . '/lecturer/index.php');
                break;
            case 'Student':
                header('Location: ' . BASE_URL . '/student/index.php');
                break;
            default:
                header('Location: ' . BASE_URL . '/auth/login.php');
                break;
        }
        exit;
    }

    return $user;
}

// Pre-populate active user info if authenticated
$currentUser = null;
if (!empty($_SESSION['user_id'])) {
    $currentUser = [
        'user_id' => $_SESSION['user_id'],
        'username' => $_SESSION['username'] ?? '',
        'email' => $_SESSION['user_email'] ?? '',
        'role' => $_SESSION['user_role'] ?? '',
        'status' => $_SESSION['user_status'] ?? 'Active',
        'profile_id' => $_SESSION['profile_id'] ?? null,
        'full_name' => $_SESSION['user_fullname'] ?? ($_SESSION['username'] ?? 'User')
    ];
}
