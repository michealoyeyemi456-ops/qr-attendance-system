<?php
/**
 * QR Attendance System Using MS SQL and Apache
 * Student Portal: QR Code Scanner & Manual Verification View
 */

require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/includes/functions.php';
require_once dirname(__DIR__) . '/includes/auth_guard.php';

$user = require_role('Student');
$prefilledToken = trim($_GET['token'] ?? '');

$pageTitle = 'Scan Class QR Code';
require_once dirname(__DIR__) . '/includes/header.php';
?>

<div class="page-header">
    <div>
        <h1 class="page-title"><i class="fas fa-camera text-primary"></i> Scan Attendance QR</h1>
        <div class="page-subtitle">Align the classroom projector QR code within the reticle to record your attendance</div>
    </div>
    <div>
        <a href="<?= BASE_URL ?>/student/index.php" class="btn btn-outline">
            <i class="fas fa-arrow-left"></i> Back to Dashboard
        </a>
    </div>
</div>

<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 1.5rem; align-items: start;">
    
    <!-- Left Column: Camera Scanner Viewport -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title"><i class="fas fa-video text-primary"></i> Live Camera Scanner</h3>
            <span class="badge badge-success"><i class="fas fa-circle pulse-indicator" style="width:8px; height:8px;"></i> Camera Ready</span>
        </div>
        <div class="card-body text-center">
            <div id="scanner-status"></div>

            <div class="scanner-viewport" id="reader-container">
                <div id="qr-reader" style="width: 100%;"></div>
            </div>

            <div class="mt-3 text-muted" style="font-size: 0.825rem;">
                <i class="fas fa-info-circle text-info"></i> Make sure your browser has camera permission enabled.
            </div>
        </div>
    </div>

    <!-- Right Column: Verification Result & Manual Token Entry -->
    <div>
        <!-- Scan Feedback Card -->
        <div id="scan-result-card" class="card" style="display: none; border: 2px solid #10b981;">
            <div class="card-header" style="background-color: #ecfdf5;">
                <h3 class="card-title text-success" id="result-header-title">
                    <i class="fas fa-check-circle"></i> Attendance Recorded!
                </h3>
            </div>
            <div class="card-body">
                <div id="result-message" class="mb-3 font-bold" style="font-size: 1.05rem; color: #065f46;"></div>
                
                <div style="background: #f8fafc; border-radius: var(--radius-md); padding: 1rem; border: 1px solid #e2e8f0; font-size: 0.9rem;">
                    <div class="d-flex justify-between mb-2">
                        <span class="text-muted">Course:</span>
                        <strong id="res-course">-</strong>
                    </div>
                    <div class="d-flex justify-between mb-2">
                        <span class="text-muted">Lecturer:</span>
                        <span id="res-lecturer">-</span>
                    </div>
                    <div class="d-flex justify-between mb-2">
                        <span class="text-muted">Classroom:</span>
                        <span id="res-classroom">-</span>
                    </div>
                    <div class="d-flex justify-between mb-2">
                        <span class="text-muted">Check-in Status:</span>
                        <span id="res-status" class="badge badge-success">Present</span>
                    </div>
                    <div class="d-flex justify-between">
                        <span class="text-muted">Recorded At:</span>
                        <span id="res-time">-</span>
                    </div>
                </div>

                <div class="mt-4 text-center">
                    <a href="<?= BASE_URL ?>/student/history.php" class="btn btn-primary btn-block">
                        <i class="fas fa-history"></i> View Full Attendance Log
                    </a>
                </div>
            </div>
        </div>

        <!-- Manual Token Fallback Card -->
        <div class="card">
            <div class="card-header">
                <h3 class="card-title"><i class="fas fa-keyboard text-primary"></i> Manual Token Input</h3>
            </div>
            <div class="card-body">
                <p class="text-muted" style="font-size: 0.85rem; margin-bottom: 1rem;">
                    If camera access is unavailable or your device cannot scan the screen, enter the session token provided on the projector screen:
                </p>

                <form id="manual-token-form">
                    <div class="form-group">
                        <label class="form-label" for="manual-token">Session Security Token</label>
                        <input type="text" id="manual-token" name="token" class="form-control" 
                               value="<?= htmlspecialchars($prefilledToken) ?>" 
                               placeholder="e.g. SES-COM312-LIVE-ACTIVE-TK8421" required>
                    </div>

                    <button type="submit" id="btn-submit-manual" class="btn btn-primary btn-block">
                        <i class="fas fa-check-circle"></i> Validate &amp; Check In
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<script src="<?= BASE_URL ?>/assets/js/scanner.js"></script>
<script>
document.addEventListener('DOMContentLoaded', () => {
    const resultCard = document.getElementById('scan-result-card');
    const resultHeader = document.getElementById('result-header-title');
    const resultMsg = document.getElementById('result-message');
    const resCourse = document.getElementById('res-course');
    const resLecturer = document.getElementById('res-lecturer');
    const resClassroom = document.getElementById('res-classroom');
    const resStatus = document.getElementById('res-status');
    const resTime = document.getElementById('res-time');
    const scannerStatus = document.getElementById('scanner-status');

    // Function to submit token to API
    function processAttendanceToken(tokenPayload, scanMethod = 'QR_CAMERA') {
        scannerStatus.innerHTML = `<div class="alert alert-info"><i class="fas fa-spinner fa-spin"></i> Verifying token with server...</div>`;

        fetch('<?= BASE_URL ?>/api/scan_qr.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: `token=${encodeURIComponent(tokenPayload)}&scan_method=${encodeURIComponent(scanMethod)}`
        })
        .then(res => res.json())
        .then(data => {
            scannerStatus.innerHTML = '';
            resultCard.style.display = 'block';

            if (data.success) {
                resultCard.style.borderColor = '#10b981';
                resultHeader.innerHTML = '<i class="fas fa-check-circle"></i> Attendance Recorded!';
                resultHeader.className = 'card-title text-success';
                resultMsg.className = 'mb-3 font-bold text-success';
                resultMsg.innerText = data.message;

                resCourse.innerText = `${data.data.course_code} - ${data.data.course_title}`;
                resLecturer.innerText = data.data.lecturer;
                resClassroom.innerText = data.data.classroom;
                resStatus.innerText = data.data.status;
                resStatus.className = `badge ${data.data.status === 'Present' ? 'badge-success' : 'badge-warning'}`;
                resTime.innerText = data.data.marked_at;

                // Smooth scroll to feedback
                resultCard.scrollIntoView({ behavior: 'smooth' });
            } else if (data.is_duplicate) {
                resultCard.style.borderColor = '#f59e0b';
                resultHeader.innerHTML = '<i class="fas fa-info-circle"></i> Already Recorded';
                resultHeader.className = 'card-title text-warning';
                resultMsg.className = 'mb-3 font-bold text-warning';
                resultMsg.innerText = data.message;
                resCourse.innerText = '-';
                resLecturer.innerText = '-';
                resClassroom.innerText = '-';
                resStatus.innerText = data.existing_status || 'Present';
                resStatus.className = 'badge badge-warning';
                resTime.innerText = data.marked_at || 'Earlier today';
                resultCard.scrollIntoView({ behavior: 'smooth' });
            } else {
                resultCard.style.borderColor = '#ef4444';
                resultHeader.innerHTML = '<i class="fas fa-times-circle"></i> Verification Failed';
                resultHeader.className = 'card-title text-danger';
                resultMsg.className = 'mb-3 font-bold text-danger';
                resultMsg.innerText = data.message;
                resCourse.innerText = 'N/A';
                resLecturer.innerText = 'N/A';
                resClassroom.innerText = 'N/A';
                resStatus.innerText = 'Rejected';
                resStatus.className = 'badge badge-danger';
                resTime.innerText = new Date().toLocaleTimeString();
                resultCard.scrollIntoView({ behavior: 'smooth' });
            }
        })
        .catch(err => {
            scannerStatus.innerHTML = `<div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> Network connection error: ${err.message}</div>`;
        });
    }

    // Initialize Camera Scanner
    const scanner = new QRScannerHandler('qr-reader', (scannedText) => {
        processAttendanceToken(scannedText, 'QR_CAMERA');
    });
    scanner.start();

    // Manual Form Submission
    const manualForm = document.getElementById('manual-token-form');
    manualForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const tokenVal = document.getElementById('manual-token').value.trim();
        if (tokenVal) {
            processAttendanceToken(tokenVal, 'MANUAL_TOKEN');
        }
    });

    // If token was prefilled in URL, trigger verification immediately
    const initialToken = "<?= addslashes($prefilledToken) ?>";
    if (initialToken.length > 0) {
        processAttendanceToken(initialToken, 'MANUAL_TOKEN');
    }
});
</script>

<?php require_once dirname(__DIR__) . '/includes/footer.php'; ?>
