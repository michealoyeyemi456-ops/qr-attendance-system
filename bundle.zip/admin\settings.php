<?php
/**
 * QR Attendance System Using MS SQL and Apache
 * Administrator Portal: System Settings & Academic Configurations
 */

require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/includes/functions.php';
require_once dirname(__DIR__) . '/includes/auth_guard.php';

$user = require_role('Admin');
$pdo = Database::getConnection();

$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        $error = 'Session expired. Please try again.';
    } else {
        $updates = [
            'INSTITUTION_NAME' => trim($_POST['institution_name'] ?? ''),
            'INSTITUTION_CODE' => trim($_POST['institution_code'] ?? ''),
            'ACADEMIC_SESSION' => trim($_POST['academic_session'] ?? ''),
            'SEMESTER' => trim($_POST['semester'] ?? ''),
            'ATTENDANCE_THRESHOLD' => (string)max(10, min(100, (int)($_POST['attendance_threshold'] ?? 75))),
            'DEFAULT_SESSION_DURATION' => (string)max(5, min(240, (int)($_POST['default_duration'] ?? 30)))
        ];

        try {
            $stUpd = $pdo->prepare("UPDATE SystemSettings SET SettingValue = ?, UpdatedAt = CURRENT_TIMESTAMP WHERE SettingKey = ?");
            foreach ($updates as $k => $v) {
                if (!empty($v)) {
                    $stUpd->execute([$v, $k]);
                }
            }

            logAudit($user['user_id'], 'SETTINGS_UPDATED', 'ADMIN', 'Updated institutional system settings');
            flash('success', 'System settings saved and applied successfully.', 'success');
            header('Location: ' . BASE_URL . '/admin/settings.php');
            exit;
        } catch (Exception $e) {
            $error = 'Failed to update settings: ' . $e->getMessage();
        }
    }
}

// Fetch current settings
$rows = $pdo->query("SELECT SettingKey, SettingValue, Description FROM SystemSettings")->fetchAll();
$settings = [];
foreach ($rows as $r) {
    $settings[$r['SettingKey']] = $r['SettingValue'];
}

$pageTitle = 'System Settings';
require_once dirname(__DIR__) . '/includes/header.php';
?>

<div class="page-header">
    <div>
        <h1 class="page-title"><i class="fas fa-cogs text-primary"></i> System Settings &amp; Configuration</h1>
        <div class="page-subtitle">Configure academic sessions, attendance policies, and institutional parameters</div>
    </div>
</div>

<?php if ($error): ?>
    <div class="alert alert-danger"><i class="fas fa-times-circle"></i> <?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<div style="display: grid; grid-template-columns: 1fr 340px; gap: 1.5rem; align-items: start;">
    
    <!-- Settings Form -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title"><i class="fas fa-sliders-h text-primary"></i> Academic Policies &amp; Institution Profile</h3>
        </div>
        <div class="card-body">
            <form action="<?= BASE_URL ?>/admin/settings.php" method="POST">
                <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">

                <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 1rem;">
                    <div class="form-group">
                        <label class="form-label" for="institution_name">Institution Name</label>
                        <input type="text" id="institution_name" name="institution_name" class="form-control" 
                               value="<?= htmlspecialchars($settings['INSTITUTION_NAME'] ?? INSTITUTION_NAME) ?>" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="institution_code">Institution Code</label>
                        <input type="text" id="institution_code" name="institution_code" class="form-control" 
                               value="<?= htmlspecialchars($settings['INSTITUTION_CODE'] ?? INSTITUTION_CODE) ?>" required>
                    </div>
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                    <div class="form-group">
                        <label class="form-label" for="academic_session">Current Academic Session</label>
                        <input type="text" id="academic_session" name="academic_session" class="form-control" 
                               value="<?= htmlspecialchars($settings['ACADEMIC_SESSION'] ?? CURRENT_ACADEMIC_SESSION) ?>" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="semester">Current Active Semester</label>
                        <select name="semester" id="semester" class="form-select">
                            <option value="First Semester" <?= (($settings['SEMESTER'] ?? CURRENT_SEMESTER) === 'First Semester') ? 'selected' : '' ?>>First Semester</option>
                            <option value="Second Semester" <?= (($settings['SEMESTER'] ?? CURRENT_SEMESTER) === 'Second Semester') ? 'selected' : '' ?>>Second Semester</option>
                        </select>
                    </div>
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                    <div class="form-group">
                        <label class="form-label" for="attendance_threshold">Exam Eligibility Threshold (%)</label>
                        <input type="number" id="attendance_threshold" name="attendance_threshold" class="form-control" 
                               value="<?= htmlspecialchars($settings['ATTENDANCE_THRESHOLD'] ?? '75') ?>" min="10" max="100" required>
                        <div class="form-text">Students with attendance percentage below this are flagged as ineligible for exams.</div>
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="default_duration">Default Session Duration (Minutes)</label>
                        <input type="number" id="default_duration" name="default_duration" class="form-control" 
                               value="<?= htmlspecialchars($settings['DEFAULT_SESSION_DURATION'] ?? '30') ?>" min="5" max="240" required>
                        <div class="form-text">Default lecture duration populated in session launch form.</div>
                    </div>
                </div>

                <div class="mt-4">
                    <button type="submit" class="btn btn-primary btn-lg">
                        <i class="fas fa-save"></i> Save Configuration Changes
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Server & Environment Information Card -->
    <div>
        <div class="card">
            <div class="card-header">
                <h3 class="card-title"><i class="fas fa-server text-primary"></i> Server Architecture</h3>
            </div>
            <div class="card-body" style="font-size: 0.85rem;">
                <div class="mb-3">
                    <span class="text-muted">Target RDBMS:</span>
                    <div class="font-bold text-primary">Microsoft SQL Server</div>
                </div>
                <div class="mb-3">
                    <span class="text-muted">Active Connection Driver:</span>
                    <div class="font-bold"><?= htmlspecialchars(Database::getDriverUsed()) ?></div>
                </div>
                <div class="mb-3">
                    <span class="text-muted">Web Server:</span>
                    <div class="font-bold"><?= htmlspecialchars($_SERVER['SERVER_SOFTWARE'] ?? 'Apache / PHP') ?></div>
                </div>
                <div class="mb-3">
                    <span class="text-muted">PHP Version:</span>
                    <div class="font-bold"><?= PHP_VERSION ?></div>
                </div>
                <div class="mb-3">
                    <span class="text-muted">App Version:</span>
                    <div>Ver <?= APP_VERSION ?></div>
                </div>
                <div>
                    <span class="text-muted">Timezone:</span>
                    <div><?= date_default_timezone_get() ?> (<?= date('Y-m-d H:i:s') ?>)</div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once dirname(__DIR__) . '/includes/footer.php'; ?>
