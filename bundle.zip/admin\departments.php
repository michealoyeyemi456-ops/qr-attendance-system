<?php
/**
 * QR Attendance System Using MS SQL and Apache
 * Administrator Portal: Manage Departments, Programmes & Classrooms
 */

require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/includes/functions.php';
require_once dirname(__DIR__) . '/includes/auth_guard.php';

$user = require_role('Admin');
$pdo = Database::getConnection();

$error = null;

// Handle Add Department
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        $error = 'Session expired. Please try again.';
    } else {
        $act = $_POST['action'];

        if ($act === 'add_dept') {
            $code = strtoupper(trim($_POST['department_code'] ?? ''));
            $name = trim($_POST['department_name'] ?? '');
            $faculty = trim($_POST['faculty'] ?? '');

            if (!empty($code) && !empty($name)) {
                try {
                    $pdo->prepare("INSERT INTO Departments (DepartmentCode, DepartmentName, Faculty) VALUES (?, ?, ?)")->execute([$code, $name, $faculty]);
                    logAudit($user['user_id'], 'DEPARTMENT_CREATED', 'ADMIN', "Created department {$code} ({$name})");
                    flash('success', "Department {$code} added successfully.", 'success');
                    header('Location: ' . BASE_URL . '/admin/departments.php');
                    exit;
                } catch (Exception $e) {
                    $error = 'Error adding department: ' . $e->getMessage();
                }
            }
        } elseif ($act === 'add_prog') {
            $deptId = (int)($_POST['department_id'] ?? 0);
            $code = strtoupper(trim($_POST['programme_code'] ?? ''));
            $name = trim($_POST['programme_name'] ?? '');
            $years = (int)($_POST['duration_years'] ?? 2);

            if ($deptId > 0 && !empty($code) && !empty($name)) {
                try {
                    $pdo->prepare("INSERT INTO Programmes (DepartmentID, ProgrammeCode, ProgrammeName, DurationYears) VALUES (?, ?, ?, ?)")->execute([$deptId, $code, $name, $years]);
                    logAudit($user['user_id'], 'PROGRAMME_CREATED', 'ADMIN', "Created programme {$code}");
                    flash('success', "Programme {$code} added successfully.", 'success');
                    header('Location: ' . BASE_URL . '/admin/departments.php');
                    exit;
                } catch (Exception $e) {
                    $error = 'Error adding programme: ' . $e->getMessage();
                }
            }
        } elseif ($act === 'add_room') {
            $code = strtoupper(trim($_POST['room_code'] ?? ''));
            $name = trim($_POST['room_name'] ?? '');
            $capacity = (int)($_POST['capacity'] ?? 60);
            $building = trim($_POST['building'] ?? '');

            if (!empty($code) && !empty($name)) {
                try {
                    $pdo->prepare("INSERT INTO Classrooms (RoomCode, RoomName, Capacity, Building) VALUES (?, ?, ?, ?)")->execute([$code, $name, $capacity, $building]);
                    logAudit($user['user_id'], 'CLASSROOM_CREATED', 'ADMIN', "Created classroom {$code} ({$name})");
                    flash('success', "Classroom {$code} added successfully.", 'success');
                    header('Location: ' . BASE_URL . '/admin/departments.php');
                    exit;
                } catch (Exception $e) {
                    $error = 'Error adding classroom: ' . $e->getMessage();
                }
            }
        }
    }
}

// Fetch records
$departments = $pdo->query("
    SELECT d.*, 
           (SELECT COUNT(*) FROM Students s WHERE s.DepartmentID = d.DepartmentID) AS StudentsCount,
           (SELECT COUNT(*) FROM Lecturers l WHERE l.DepartmentID = d.DepartmentID) AS LecturersCount
    FROM Departments d 
    ORDER BY d.DepartmentName ASC
")->fetchAll();

$programmes = $pdo->query("
    SELECT p.*, d.DepartmentCode 
    FROM Programmes p 
    JOIN Departments d ON p.DepartmentID = d.DepartmentID 
    ORDER BY p.ProgrammeName ASC
")->fetchAll();

$classrooms = $pdo->query("SELECT * FROM Classrooms ORDER BY RoomCode ASC")->fetchAll();

$pageTitle = 'Academic Structure & Classrooms';
require_once dirname(__DIR__) . '/includes/header.php';
?>

<div class="page-header">
    <div>
        <h1 class="page-title"><i class="fas fa-sitemap text-primary"></i> Academic Structure &amp; Classrooms</h1>
        <div class="page-subtitle">Configure institutional faculties, academic programmes, and lecture venues</div>
    </div>
</div>

<?php if ($error): ?>
    <div class="alert alert-danger"><i class="fas fa-times-circle"></i> <?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(340px, 1fr)); gap: 1.5rem;">
    
    <!-- Departments Section -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title"><i class="fas fa-building text-primary"></i> Departments (<?= count($departments) ?>)</h3>
        </div>
        <div class="card-body">
            <!-- Add Department Form -->
            <form action="<?= BASE_URL ?>/admin/departments.php" method="POST" class="mb-4" style="background: #f8fafc; padding: 1rem; border-radius: var(--radius-md); border: 1px solid #e2e8f0;">
                <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                <input type="hidden" name="action" value="add_dept">
                <div style="font-weight: 700; font-size: 0.85rem; margin-bottom: 0.75rem; color: #1e3a8a;">+ Add New Department</div>
                <div class="form-group mb-2">
                    <input type="text" name="department_code" class="form-control form-control-sm" placeholder="Dept Code (e.g. CSC)" required>
                </div>
                <div class="form-group mb-2">
                    <input type="text" name="department_name" class="form-control form-control-sm" placeholder="Department Name" required>
                </div>
                <div class="form-group mb-2">
                    <input type="text" name="faculty" class="form-control form-control-sm" placeholder="Faculty / School">
                </div>
                <button type="submit" class="btn btn-primary btn-sm btn-block">Add Department</button>
            </form>

            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr><th>Code</th><th>Name</th><th>Faculty</th><th>Stats</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($departments as $d): ?>
                            <tr>
                                <td><strong><?= htmlspecialchars($d['DepartmentCode']) ?></strong></td>
                                <td><?= htmlspecialchars($d['DepartmentName']) ?></td>
                                <td style="font-size: 0.8rem;"><?= htmlspecialchars($d['Faculty']) ?></td>
                                <td>
                                    <span class="badge badge-neutral"><?= $d['StudentsCount'] ?> Stus</span>
                                    <span class="badge badge-neutral"><?= $d['LecturersCount'] ?> Staff</span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Programmes Section -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title"><i class="fas fa-graduation-cap text-primary"></i> Programmes (<?= count($programmes) ?>)</h3>
        </div>
        <div class="card-body">
            <!-- Add Programme Form -->
            <form action="<?= BASE_URL ?>/admin/departments.php" method="POST" class="mb-4" style="background: #f8fafc; padding: 1rem; border-radius: var(--radius-md); border: 1px solid #e2e8f0;">
                <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                <input type="hidden" name="action" value="add_prog">
                <div style="font-weight: 700; font-size: 0.85rem; margin-bottom: 0.75rem; color: #1e3a8a;">+ Add New Programme</div>
                <div class="form-group mb-2">
                    <select name="department_id" class="form-select form-control-sm" required>
                        <option value="">-- Select Department --</option>
                        <?php foreach ($departments as $d): ?>
                            <option value="<?= $d['DepartmentID'] ?>"><?= htmlspecialchars($d['DepartmentCode']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group mb-2">
                    <input type="text" name="programme_code" class="form-control form-control-sm" placeholder="Programme Code (e.g. HND-CSC)" required>
                </div>
                <div class="form-group mb-2">
                    <input type="text" name="programme_name" class="form-control form-control-sm" placeholder="Programme Full Name" required>
                </div>
                <button type="submit" class="btn btn-primary btn-sm btn-block">Add Programme</button>
            </form>

            <div class="table-responsive">
                <table class="table">
                    <thead><tr><th>Code</th><th>Programme Name</th><th>Dept</th></tr></thead>
                    <tbody>
                        <?php foreach ($programmes as $p): ?>
                            <tr>
                                <td><strong><?= htmlspecialchars($p['ProgrammeCode']) ?></strong></td>
                                <td><?= htmlspecialchars($p['ProgrammeName']) ?></td>
                                <td><span class="badge badge-neutral"><?= htmlspecialchars($p['DepartmentCode']) ?></span></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Classrooms / Venues Section -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title"><i class="fas fa-map-marker-alt text-primary"></i> Classrooms &amp; Labs (<?= count($classrooms) ?>)</h3>
        </div>
        <div class="card-body">
            <!-- Add Classroom Form -->
            <form action="<?= BASE_URL ?>/admin/departments.php" method="POST" class="mb-4" style="background: #f8fafc; padding: 1rem; border-radius: var(--radius-md); border: 1px solid #e2e8f0;">
                <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                <input type="hidden" name="action" value="add_room">
                <div style="font-weight: 700; font-size: 0.85rem; margin-bottom: 0.75rem; color: #1e3a8a;">+ Add Lecture Venue</div>
                <div class="form-group mb-2">
                    <input type="text" name="room_code" class="form-control form-control-sm" placeholder="Room Code (e.g. LAB-1)" required>
                </div>
                <div class="form-group mb-2">
                    <input type="text" name="room_name" class="form-control form-control-sm" placeholder="Room Name (e.g. Main Lab 1)" required>
                </div>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 0.5rem;" class="mb-2">
                    <input type="number" name="capacity" class="form-control form-control-sm" placeholder="Capacity (e.g. 75)" value="75" required>
                    <input type="text" name="building" class="form-control form-control-sm" placeholder="Building Block">
                </div>
                <button type="submit" class="btn btn-primary btn-sm btn-block">Add Venue</button>
            </form>

            <div class="table-responsive">
                <table class="table">
                    <thead><tr><th>Room</th><th>Capacity</th><th>Building</th></tr></thead>
                    <tbody>
                        <?php foreach ($classrooms as $rm): ?>
                            <tr>
                                <td><strong><?= htmlspecialchars($rm['RoomCode']) ?></strong><div class="text-muted" style="font-size:0.75rem;"><?= htmlspecialchars($rm['RoomName']) ?></div></td>
                                <td><span class="badge badge-neutral"><?= $rm['Capacity'] ?> seats</span></td>
                                <td style="font-size: 0.8rem;"><?= htmlspecialchars($rm['Building'] ?: 'Main') ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php require_once dirname(__DIR__) . '/includes/footer.php'; ?>
