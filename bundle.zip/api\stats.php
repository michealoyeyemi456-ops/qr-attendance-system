<?php
/**
 * QR Attendance System Using MS SQL and Apache
 * API Endpoint: Aggregated Stats & Analytics
 */

require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/includes/functions.php';

header('Content-Type: application/json; charset=utf-8');

try {
    $pdo = Database::getConnection();

    $stats = [
        'total_students' => (int)$pdo->query("SELECT COUNT(*) FROM Students")->fetchColumn(),
        'total_lecturers' => (int)$pdo->query("SELECT COUNT(*) FROM Lecturers")->fetchColumn(),
        'total_courses' => (int)$pdo->query("SELECT COUNT(*) FROM Courses")->fetchColumn(),
        'total_sessions' => (int)$pdo->query("SELECT COUNT(*) FROM AttendanceSessions")->fetchColumn(),
        'active_sessions_today' => (int)$pdo->query("SELECT COUNT(*) FROM AttendanceSessions WHERE Status = 'Active' AND SessionDate = CURRENT_DATE")->fetchColumn(),
        'total_scans' => (int)$pdo->query("SELECT COUNT(*) FROM AttendanceRecords")->fetchColumn(),
    ];

    jsonResponse(['success' => true, 'stats' => $stats]);
} catch (Exception $e) {
    jsonResponse(['success' => false, 'message' => $e->getMessage()], 500);
}
