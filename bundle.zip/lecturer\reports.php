<?php
/**
 * QR Attendance System Using MS SQL and Apache
 * Lecturer Portal: Course Attendance Reports & Eligibility Analytics
 */

require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/includes/functions.php';
require_once dirname(__DIR__) . '/includes/auth_guard.php';

$user = require_role('Lecturer');
$pdo = Database::getConnection();

// Fetch lecturer ID
$stLec = $pdo->prepare("SELECT LecturerID FROM Lecturers WHERE UserID = ?");
$stLec->execute([$user['user_id']]);
$lecturerId = (int)$stLec->fetchColumn();

// Fetch assigned courses
$stCourses = $pdo->prepare("
    SELECT c.CourseID, c.CourseCode, c.CourseTitle 
    FROM CourseLecturers cl
    JOIN Courses c ON cl.CourseID = c.CourseID
    WHERE cl.LecturerID = ?
    ORDER BY c.CourseCode ASC
");
$stCourses->execute([$lecturerId]);
$courses = $stCourses->fetchAll();

// Default to first course if none selected
$selectedCourseId = isset($_GET['course_id']) ? (int)$_GET['course_id'] : (isset($courses[0]['CourseID']) ? (int)$courses[0]['CourseID'] : 0);

$courseDetails = null;
$studentsReport = [];
$totalLecturesHeld = 0;
$eligibleCount = 0;
$atRiskCount = 0;
$ineligibleCount = 0;

if ($selectedCourseId > 0) {
    // Verify course
    $stDetail = $pdo->prepare("SELECT CourseID, CourseCode, CourseTitle, CreditUnits FROM Courses WHERE CourseID = ?");
    $stDetail->execute([$selectedCourseId]);
    $courseDetails = $stDetail->fetch();

    // Total sessions held for this course
    $stSesCount = $pdo->prepare("SELECT COUNT(*) FROM AttendanceSessions WHERE CourseID = ? AND Status IN ('Active', 'Closed')");
    $stSesCount->execute([$selectedCourseId]);
    $totalLecturesHeld = (int)$stSesCount->fetchColumn();

    // Fetch enrolled students
    $stStudents = $pdo->prepare("
        SELECT s.StudentID, s.MatricNo, s.FirstName, s.LastName, s.Phone,
               d.DepartmentCode, lev.LevelCode
        FROM CourseRegistrations cr
        JOIN Students s ON cr.StudentID = s.StudentID
        JOIN Departments d ON s.DepartmentID = d.DepartmentID
        JOIN Levels lev ON s.LevelID = lev.LevelID
        WHERE cr.CourseID = ?
        ORDER BY s.MatricNo ASC
    ");
    $stStudents->execute([$selectedCourseId]);
    $enrolled = $stStudents->fetchAll();

    foreach ($enrolled as $stu) {
        $att = calculateAttendancePercent((int)$stu['StudentID'], $selectedCourseId);
        $pct = $att['percentage'];

        if ($pct >= ATTENDANCE_THRESHOLD_PERCENT) {
            $eligibleCount++;
        } elseif ($pct >= (ATTENDANCE_THRESHOLD_PERCENT - 15)) {
            $atRiskCount++;
        } else {
            $ineligibleCount++;
        }

        $studentsReport[] = [
            'student_id' => $stu['StudentID'],
            'matric_no' => $stu['MatricNo'],
            'name' => "{$stu['FirstName']} {$stu['LastName']}",
            'department' => $stu['DepartmentCode'],
            'level' => $stu['LevelCode'],
            'attended' => $att['attended'],
            'total' => $att['total'],
            'percentage' => $pct,
            'eligible' => $att['eligible']
        ];
    }
}

$pageTitle = 'Attendance Analysis & Reports';
require_once dirname(__DIR__) . '/includes/header.php';
?>

<div class="page-header">
    <div>
        <h1 class="page-title"><i class="fas fa-chart-line text-primary"></i> Course Attendance Reports</h1>
        <div class="page-subtitle">Evaluation of exam eligibility and attendance records for <?= CURRENT_ACADEMIC_SESSION ?></div>
    </div>
    <div class="d-flex gap-2">
        <button onclick="window.print()" class="btn btn-outline">
            <i class="fas fa-print"></i> Print Report
        </button>
        <?php if ($selectedCourseId > 0): ?>
            <a href="<?= BASE_URL ?>/reports/export_csv.php?course_id=<?= $selectedCourseId ?>" class="btn btn-primary">
                <i class="fas fa-file-csv"></i> Export Course CSV
            </a>
        <?php endif; ?>
    </div>
</div>

<!-- Course Selector Bar -->
<div class="card mb-4">
    <div class="card-body" style="padding: 1.25rem;">
        <form method="GET" action="<?= BASE_URL ?>/lecturer/reports.php" class="d-flex align-items-center gap-3 flex-wrap">
            <div style="flex: 1; min-width: 250px;">
                <label class="form-label" style="font-size: 0.8rem;">Select Course for Attendance Analysis</label>
                <select name="course_id" class="form-select" onchange="this.form.submit()">
                    <?php foreach ($courses as $c): ?>
                        <option value="<?= $c['CourseID'] ?>" <?= ($selectedCourseId === (int)$c['CourseID']) ? 'selected' : '' ?>>
                            <?= htmlspecialchars($c['CourseCode'] . ' - ' . $c['CourseTitle']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div style="align-self: flex-end;">
                <button type="submit" class="btn btn-primary"><i class="fas fa-sync-alt"></i> Generate Analytics</button>
            </div>
        </form>
    </div>
</div>

<?php if ($courseDetails): ?>
    <!-- Report Metrics Overview -->
    <div class="stat-grid">
        <div class="stat-card stat-primary">
            <div class="stat-icon-wrapper"><i class="fas fa-users"></i></div>
            <div class="stat-content">
                <div class="stat-value"><?= count($studentsReport) ?></div>
                <div class="stat-label">Total Enrolled</div>
            </div>
        </div>

        <div class="stat-card stat-info">
            <div class="stat-icon-wrapper"><i class="fas fa-chalkboard-teacher"></i></div>
            <div class="stat-content">
                <div class="stat-value"><?= $totalLecturesHeld ?></div>
                <div class="stat-label">Total Lectures Held</div>
            </div>
        </div>

        <div class="stat-card stat-success">
            <div class="stat-icon-wrapper"><i class="fas fa-check-double"></i></div>
            <div class="stat-content">
                <div class="stat-value"><?= $eligibleCount ?></div>
                <div class="stat-label">Exam Eligible (&ge; <?= ATTENDANCE_THRESHOLD_PERCENT ?>%)</div>
            </div>
        </div>

        <div class="stat-card stat-danger">
            <div class="stat-icon-wrapper"><i class="fas fa-exclamation-triangle"></i></div>
            <div class="stat-content">
                <div class="stat-value"><?= $atRiskCount + $ineligibleCount ?></div>
                <div class="stat-label">Flagged / At Risk</div>
            </div>
        </div>
    </div>

    <!-- Student Attendance List -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">
                <i class="fas fa-table text-primary"></i> 
                Student Attendance &amp; Exam Eligibility: <?= htmlspecialchars($courseDetails['CourseCode']) ?> &mdash; <?= htmlspecialchars($courseDetails['CourseTitle']) ?>
            </h3>
            <input type="text" class="form-control" placeholder="Search student..." style="max-width: 250px;" data-table-filter="#report-table">
        </div>
        <div class="table-responsive">
            <table class="table" id="report-table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Matriculation No</th>
                        <th>Student Name</th>
                        <th>Department &amp; Level</th>
                        <th>Lectures (Attended / Held)</th>
                        <th>Attendance %</th>
                        <th>Exam Eligibility</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($studentsReport)): ?>
                        <tr><td colspan="7" class="text-center text-muted" style="padding: 2rem;">No students enrolled in this course.</td></tr>
                    <?php else: ?>
                        <?php foreach ($studentsReport as $idx => $r): 
                            $barClass = ($r['percentage'] >= ATTENDANCE_THRESHOLD_PERCENT) ? 'progress-success' : (($r['percentage'] >= 60) ? 'progress-warning' : 'progress-danger');
                        ?>
                            <tr>
                                <td><strong><?= $idx + 1 ?></strong></td>
                                <td><strong><?= htmlspecialchars($r['matric_no']) ?></strong></td>
                                <td><?= htmlspecialchars($r['name']) ?></td>
                                <td><?= htmlspecialchars($r['department']) ?> (<?= htmlspecialchars($r['level']) ?>)</td>
                                <td><strong><?= $r['attended'] ?></strong> / <?= $r['total'] ?></td>
                                <td style="min-width: 150px;">
                                    <div class="d-flex align-items-center gap-2">
                                        <span style="font-weight: 700; width: 45px;"><?= $r['percentage'] ?>%</span>
                                        <div class="progress-bar-container" style="flex:1;">
                                            <div class="progress-bar-fill <?= $barClass ?>" style="width: <?= min(100, $r['percentage']) ?>%;"></div>
                                        </div>
                                    </div>
                                </td>
                                <td><?= getEligibilityBadge($r['percentage']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php endif; ?>

<?php require_once dirname(__DIR__) . '/includes/footer.php'; ?>
