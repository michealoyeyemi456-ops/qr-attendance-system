<?php
/**
 * QR Attendance System Using MS SQL and Apache
 * Sidebar Navigation Component
 */

$currentUri = $_SERVER['REQUEST_URI'] ?? '';
$role = $_SESSION['user_role'] ?? '';
$fullName = $_SESSION['user_fullname'] ?? ($_SESSION['username'] ?? 'User');
$initials = strtoupper(substr($fullName, 0, 2));

function isActive(string $path, string $currentUri): string {
    return (strpos($currentUri, $path) !== false) ? 'active' : '';
}
?>
<aside class="dashboard-sidebar">
    <!-- Header with Academic Logo -->
    <div class="sidebar-header">
        <img src="<?= BASE_URL ?>/assets/images/logo.svg" alt="Institution Logo" class="sidebar-logo">
        <div>
            <div class="sidebar-title"><?= htmlspecialchars(INSTITUTION_CODE) ?> ATTEND</div>
            <div class="sidebar-subtitle">MS SQL & APACHE</div>
        </div>
    </div>

    <!-- Navigation Menu -->
    <ul class="sidebar-menu">
        <?php if ($role === 'Admin'): ?>
            <li class="menu-section-label">Administration</li>
            <li class="menu-item">
                <a href="<?= BASE_URL ?>/admin/index.php" class="menu-link <?= isActive('/admin/index.php', $currentUri) ?>">
                    <i class="fas fa-th-large"></i> <span>KPI Dashboard</span>
                </a>
            </li>
            <li class="menu-item">
                <a href="<?= BASE_URL ?>/admin/students.php" class="menu-link <?= isActive('/admin/students.php', $currentUri) ?>">
                    <i class="fas fa-user-graduate"></i> <span>Manage Students</span>
                </a>
            </li>
            <li class="menu-item">
                <a href="<?= BASE_URL ?>/admin/lecturers.php" class="menu-link <?= isActive('/admin/lecturers.php', $currentUri) ?>">
                    <i class="fas fa-chalkboard-teacher"></i> <span>Manage Lecturers</span>
                </a>
            </li>

            <li class="menu-section-label">Academic Structure</li>
            <li class="menu-item">
                <a href="<?= BASE_URL ?>/admin/departments.php" class="menu-link <?= isActive('/admin/departments.php', $currentUri) ?>">
                    <i class="fas fa-sitemap"></i> <span>Depts & Programs</span>
                </a>
            </li>
            <li class="menu-item">
                <a href="<?= BASE_URL ?>/admin/courses.php" class="menu-link <?= isActive('/admin/courses.php', $currentUri) ?>">
                    <i class="fas fa-book-open"></i> <span>Courses & Allocations</span>
                </a>
            </li>
            <li class="menu-item">
                <a href="<?= BASE_URL ?>/admin/registrations.php" class="menu-link <?= isActive('/admin/registrations.php', $currentUri) ?>">
                    <i class="fas fa-id-card"></i> <span>Course Enrolments</span>
                </a>
            </li>

            <li class="menu-section-label">Attendance & Logs</li>
            <li class="menu-item">
                <a href="<?= BASE_URL ?>/admin/sessions.php" class="menu-link <?= isActive('/admin/sessions.php', $currentUri) ?>">
                    <i class="fas fa-qrcode"></i> <span>All Sessions</span>
                </a>
            </li>
            <li class="menu-item">
                <a href="<?= BASE_URL ?>/admin/records.php" class="menu-link <?= isActive('/admin/records.php', $currentUri) ?>">
                    <i class="fas fa-clipboard-list"></i> <span>Master Records</span>
                </a>
            </li>
            <li class="menu-item">
                <a href="<?= BASE_URL ?>/admin/audit.php" class="menu-link <?= isActive('/admin/audit.php', $currentUri) ?>">
                    <i class="fas fa-shield-alt"></i> <span>Security Audit Trail</span>
                </a>
            </li>
            <li class="menu-item">
                <a href="<?= BASE_URL ?>/admin/settings.php" class="menu-link <?= isActive('/admin/settings.php', $currentUri) ?>">
                    <i class="fas fa-cogs"></i> <span>System Settings</span>
                </a>
            </li>

        <?php elseif ($role === 'Lecturer'): ?>
            <li class="menu-section-label">Lecturer Portal</li>
            <li class="menu-item">
                <a href="<?= BASE_URL ?>/lecturer/index.php" class="menu-link <?= isActive('/lecturer/index.php', $currentUri) ?>">
                    <i class="fas fa-th-large"></i> <span>My Dashboard</span>
                </a>
            </li>
            <li class="menu-item">
                <a href="<?= BASE_URL ?>/lecturer/create_session.php" class="menu-link <?= isActive('/lecturer/create_session.php', $currentUri) ?>">
                    <i class="fas fa-plus-circle"></i> <span>Start QR Session</span>
                </a>
            </li>
            <li class="menu-item">
                <a href="<?= BASE_URL ?>/lecturer/courses.php" class="menu-link <?= isActive('/lecturer/courses.php', $currentUri) ?>">
                    <i class="fas fa-chalkboard"></i> <span>Assigned Courses</span>
                </a>
            </li>
            <li class="menu-item">
                <a href="<?= BASE_URL ?>/lecturer/records.php" class="menu-link <?= isActive('/lecturer/records.php', $currentUri) ?>">
                    <i class="fas fa-list-alt"></i> <span>Session History</span>
                </a>
            </li>
            <li class="menu-item">
                <a href="<?= BASE_URL ?>/lecturer/reports.php" class="menu-link <?= isActive('/lecturer/reports.php', $currentUri) ?>">
                    <i class="fas fa-file-invoice"></i> <span>Attendance Reports</span>
                </a>
            </li>

        <?php elseif ($role === 'Student'): ?>
            <li class="menu-section-label">Student Portal</li>
            <li class="menu-item">
                <a href="<?= BASE_URL ?>/student/index.php" class="menu-link <?= isActive('/student/index.php', $currentUri) ?>">
                    <i class="fas fa-th-large"></i> <span>Student Dashboard</span>
                </a>
            </li>
            <li class="menu-item">
                <a href="<?= BASE_URL ?>/student/scan.php" class="menu-link <?= isActive('/student/scan.php', $currentUri) ?>">
                    <i class="fas fa-camera"></i> <span>Scan Class QR</span>
                </a>
            </li>
            <li class="menu-item">
                <a href="<?= BASE_URL ?>/student/courses.php" class="menu-link <?= isActive('/student/courses.php', $currentUri) ?>">
                    <i class="fas fa-book"></i> <span>My Courses & %</span>
                </a>
            </li>
            <li class="menu-item">
                <a href="<?= BASE_URL ?>/student/history.php" class="menu-link <?= isActive('/student/history.php', $currentUri) ?>">
                    <i class="fas fa-history"></i> <span>Attendance Log</span>
                </a>
            </li>
        <?php endif; ?>
    </ul>

    <!-- Sidebar Footer with User Avatar -->
    <div class="sidebar-footer">
        <div class="user-badge-container">
            <div class="user-avatar"><?= $initials ?></div>
            <div class="user-meta">
                <div class="user-name" title="<?= htmlspecialchars($fullName) ?>"><?= htmlspecialchars($fullName) ?></div>
                <div class="user-role-tag">
                    <i class="fas fa-circle" style="font-size: 0.5rem; color: #10b981; vertical-align: middle;"></i> 
                    <?= htmlspecialchars($role) ?>
                </div>
            </div>
        </div>
    </div>
</aside>
