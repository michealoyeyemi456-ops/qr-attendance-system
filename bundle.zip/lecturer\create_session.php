<?php
/**
 * QR Attendance System Using MS SQL and Apache
 * Lecturer Portal: Create / Launch New Attendance Session
 */

require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/includes/functions.php';
require_once dirname(__DIR__) . '/includes/auth_guard.php';

$user = require_role('Lecturer');
$pdo = Database::getConnection();

// Fetch lecturer profile ID
$stLec = $pdo->prepare("SELECT LecturerID FROM Lecturers WHERE UserID = ?");
$stLec->execute([$user['user_id']]);
$lecturerId = (int)$stLec->fetchColumn();

// Fetch lecturer's assigned courses
$stCourses = $pdo->prepare("
    SELECT c.CourseID, c.CourseCode, c.CourseTitle 
    FROM CourseLecturers cl
    JOIN Courses c ON cl.CourseID = c.CourseID
    WHERE cl.LecturerID = ?
    ORDER BY c.CourseCode ASC
");
$stCourses->execute([$lecturerId]);
$courses = $stCourses->fetchAll();

// Fetch classrooms
$classrooms = $pdo->query("SELECT ClassroomID, RoomCode, RoomName, Building FROM Classrooms ORDER BY RoomCode ASC")->fetchAll();

$error = null;
$preselectedCourse = isset($_GET['course_id']) ? (int)$_GET['course_id'] : 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $submittedCsrf = $_POST['csrf_token'] ?? '';
    $courseId = (int)($_POST['course_id'] ?? 0);
    $classroomId = (int)($_POST['classroom_id'] ?? 0);
    $sessionDate = trim($_POST['session_date'] ?? date('Y-m-d'));
    $startTime = trim($_POST['start_time'] ?? date('H:i'));
    $durationMinutes = max(5, min(240, (int)($_POST['duration_minutes'] ?? 30)));

    if (!verify_csrf($submittedCsrf)) {
        $error = 'Session expired. Please submit again.';
    } elseif ($courseId <= 0 || $classroomId <= 0) {
        $error = 'Please select a valid course and classroom.';
    } else {
        try {
            // Calculate end time
            $startTs = strtotime("{$sessionDate} {$startTime}:00");
            $endTs = $startTs + ($durationMinutes * 60);
            $endTime = date('H:i:s', $endTs);
            $startTimeFormatted = date('H:i:s', $startTs);

            // Generate unique secure session token
            $tokenSeed = "SES-FITAS-" . strtoupper(bin2hex(random_bytes(6)));
            
            // Insert Session
            $stInsert = $pdo->prepare("
                INSERT INTO AttendanceSessions (CourseID, LecturerID, ClassroomID, SessionDate, StartTime, EndTime, DurationMinutes, SessionToken, Status, CreatedAt)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Active', CURRENT_TIMESTAMP)
            ");
            $stInsert->execute([$courseId, $lecturerId, $classroomId, $sessionDate, $startTimeFormatted, $endTime, $durationMinutes, $tokenSeed]);
            $newSessionId = (int)$pdo->lastInsertId();

            // Fetch course code for audit log
            $cCode = $pdo->query("SELECT CourseCode FROM Courses WHERE CourseID = {$courseId}")->fetchColumn();
            logAudit($user['user_id'], 'SESSION_CREATED', 'SESSION', "Launched live session for {$cCode} in classroom #{$classroomId}, token: {$tokenSeed}");

            flash('success', "Attendance session launched successfully! Display the QR code on the projector.", 'success');
            header("Location: " . BASE_URL . "/lecturer/active_session.php?session_id={$newSessionId}");
            exit;

        } catch (Exception $e) {
            $error = 'Database error creating session: ' . $e->getMessage();
        }
    }
}

$pageTitle = 'Launch Attendance Session';
require_once dirname(__DIR__) . '/includes/header.php';
?>

<div class="page-header">
    <div>
        <h1 class="page-title"><i class="fas fa-qrcode text-primary"></i> Launch Attendance Session</h1>
        <div class="page-subtitle">Configure lecture parameters and broadcast live dynamic QR code to students</div>
    </div>
    <div>
        <a href="<?= BASE_URL ?>/lecturer/index.php" class="btn btn-outline">
            <i class="fas fa-arrow-left"></i> Back to Dashboard
        </a>
    </div>
</div>

<div style="max-width: 680px; margin: 0 auto;">
    <?php if ($error): ?>
        <div class="alert alert-danger"><i class="fas fa-times-circle"></i> <?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header">
            <h3 class="card-title"><i class="fas fa-sliders-h text-primary"></i> Lecture Session Configuration</h3>
        </div>
        <div class="card-body">
            <form action="<?= BASE_URL ?>/lecturer/create_session.php" method="POST">
                <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">

                <div class="form-group">
                    <label class="form-label" for="course_id"><i class="fas fa-book text-muted"></i> Teaching Course</label>
                    <select name="course_id" id="course_id" class="form-select" required>
                        <option value="">-- Select Course --</option>
                        <?php foreach ($courses as $c): ?>
                            <option value="<?= $c['CourseID'] ?>" <?= ($preselectedCourse === (int)$c['CourseID']) ? 'selected' : '' ?>>
                                <?= htmlspecialchars($c['CourseCode'] . ' - ' . $c['CourseTitle']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label class="form-label" for="classroom_id"><i class="fas fa-map-marker-alt text-muted"></i> Lecture Room / Hall</label>
                    <select name="classroom_id" id="classroom_id" class="form-select" required>
                        <option value="">-- Select Classroom --</option>
                        <?php foreach ($classrooms as $room): ?>
                            <option value="<?= $room['ClassroomID'] ?>">
                                <?= htmlspecialchars($room['RoomCode'] . ' - ' . $room['RoomName'] . ' (' . ($room['Building'] ?: 'Campus') . ')') ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                    <div class="form-group">
                        <label class="form-label" for="session_date"><i class="fas fa-calendar-day text-muted"></i> Date</label>
                        <input type="date" id="session_date" name="session_date" class="form-control" value="<?= date('Y-m-d') ?>" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="start_time"><i class="fas fa-clock text-muted"></i> Start Time</label>
                        <input type="time" id="start_time" name="start_time" class="form-control" value="<?= date('H:i') ?>" required>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label" for="duration_minutes"><i class="fas fa-hourglass-half text-muted"></i> Attendance Window Duration</label>
                    <select name="duration_minutes" id="duration_minutes" class="form-select" required>
                        <option value="15">15 Minutes (Fast Check-in)</option>
                        <option value="30" selected>30 Minutes (Standard Lecture)</option>
                        <option value="45">45 Minutes</option>
                        <option value="60">60 Minutes (1 Hour Lab Session)</option>
                        <option value="90">90 Minutes (Practical Block)</option>
                    </select>
                    <div class="form-text">Students scanning after the initial 20 minutes will automatically be marked as "Late".</div>
                </div>

                <button type="submit" class="btn btn-primary btn-block btn-lg mt-4">
                    <i class="fas fa-play"></i> Generate QR Code &amp; Start Live Session
                </button>
            </form>
        </div>
    </div>
</div>

<?php require_once dirname(__DIR__) . '/includes/footer.php'; ?>
