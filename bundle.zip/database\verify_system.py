import sqlite3
import os

db_file = os.path.join(os.path.dirname(__file__), 'attendance_portable.db')
conn = sqlite3.connect(db_file)
cur = conn.cursor()

print("================ SYSTEM VERIFICATION ================")
cur.execute("SELECT name FROM sqlite_master WHERE type='table' and name!='sqlite_sequence' ORDER BY name;")
tables = [row[0] for row in cur.fetchall()]
print(f"Total tables created ({len(tables)}): {', '.join(tables)}")

for t in tables:
    cur.execute(f"SELECT COUNT(*) FROM {t}")
    count = cur.fetchone()[0]
    print(f"  - {t:22}: {count} records")

print("\n--- SAMPLE USERS ---")
cur.execute("SELECT UserID, Username, Role, Status, Email FROM Users")
for row in cur.fetchall():
    print(f"  User #{row[0]}: {row[1]:16} | Role: {row[2]:10} | Status: {row[3]:8} | {row[4]}")

print("\n--- ATTENDANCE SESSIONS ---")
cur.execute("""
    SELECT s.SessionID, c.CourseCode, s.SessionDate, s.StartTime, s.EndTime, s.Status, s.SessionToken
    FROM AttendanceSessions s
    JOIN Courses c ON s.CourseID = c.CourseID
""")
for row in cur.fetchall():
    print(f"  Session #{row[0]}: {row[1]} on {row[2]} ({row[3]} - {row[4]}) [{row[5]}] Token: {row[6]}")

print("\n--- ATTENDANCE RECORDS ---")
cur.execute("""
    SELECT r.RecordID, s.MatricNo, c.CourseCode, r.Status, r.ScanMethod, r.MarkedAt
    FROM AttendanceRecords r
    JOIN Students s ON r.StudentID = s.StudentID
    JOIN Courses c ON r.CourseID = c.CourseID
""")
for row in cur.fetchall():
    print(f"  Record #{row[0]}: {row[1]} in {row[2]} -> {row[3]} via {row[4]} at {row[5]}")

print("\nAll database tables and relationships are verified and healthy!")
conn.close()
