<?php
/**
 * QR Attendance System Using MS SQL and Apache
 * Administrator Portal: Manage All Institutional Attendance Sessions
 */

require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/includes/functions.php';
require_once dirname(__DIR__) . '/includes/auth_guard.php';

$user = require_role('Admin');
$pdo = Database::getConnection();

// Action: Close session
if (isset($_GET['action']) && $_GET['action'] === 'close' && isset($_GET['id'])) {
    if (verify_csrf($_GET['csrf'] ?? '')) {
        $sesId = (int)$_GET['id'];
        $pdo->prepare("UPDATE AttendanceSessions SET Status = 'Closed', ClosedAt = CURRENT_TIMESTAMP WHERE SessionID = ?")->execute([$sesId]);
        logAudit($user['user_id'], 'SESSION_CLOSED_BY_ADMIN', 'SESSION', "Admin closed session #{$sesId}");
        flash('success', "Session #{$sesId} marked closed.", 'info');
    }
    header('Location: ' . BASE_URL . '/admin/sessions.php');
    exit;
}

// Filter parameters
$courseFilter = isset($_GET['course_id']) ? (int)$_GET['course_id'] : 0;
$statusFilter = trim($_GET['status'] ?? '');

$sql = "
    SELECT s.SessionID, s.SessionDate, s.StartTime, s.EndTime, s.DurationMinutes, s.SessionToken, s.Status,
           c.CourseCode, c.CourseTitle, cl.RoomCode,
           l.Title AS LecTitle, l.LastName AS LecLast, l.StaffID,
           (SELECT COUNT(*) FROM AttendanceRecords r WHERE r.SessionID = s.SessionID) AS AttendeesCount,
           (SELECT COUNT(*) FROM CourseRegistrations cr WHERE cr.CourseID = s.CourseID) AS RegisteredCount
    FROM AttendanceSessions s
    JOIN Courses c ON s.CourseID = c.CourseID
    JOIN Classrooms cl ON s.ClassroomID = cl.ClassroomID
    JOIN Lecturers l ON s.LecturerID = l.LecturerID
    WHERE 1=1
";
$params = [];

if ($courseFilter > 0) {
    $sql .= " AND s.CourseID = ?";
    $params[] = $courseFilter;
}
if (!empty($statusFilter)) {
    $sql .= " AND s.Status = ?";
    $params[] = $statusFilter;
}

$sql .= " ORDER BY s.SessionID DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$sessions = $stmt->fetchAll();

$courses = $pdo->query("SELECT CourseID, CourseCode, CourseTitle FROM Courses ORDER BY CourseCode ASC")->fetchAll();

$pageTitle = 'Institutional Attendance Sessions';
require_once dirname(__DIR__) . '/includes/header.php';
?>

<div class="page-header">
    <div>
        <h1 class="page-title"><i class="fas fa-qrcode text-primary"></i> Master Attendance Sessions</h1>
        <div class="page-subtitle">Oversight and management of all digital lecture sessions across departments</div>
    </div>
</div>

<!-- Filters Bar -->
<div class="card mb-4">
    <div class="card-body" style="padding: 1.25rem;">
        <form method="GET" action="<?= BASE_URL ?>/admin/sessions.php" class="d-flex align-items-center gap-3 flex-wrap">
            <div style="flex: 1; min-width: 250px;">
                <label class="form-label" style="font-size: 0.8rem;">Filter by Course</label>
                <select name="course_id" class="form-select">
                    <option value="0">-- All Courses --</option>
                    <?php foreach ($courses as $c): ?>
                        <option value="<?= $c['CourseID'] ?>" <?= ($courseFilter === (int)$c['CourseID']) ? 'selected' : '' ?>>
                            <?= htmlspecialchars($c['CourseCode'] . ' - ' . $c['CourseTitle']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div style="width: 170px;">
                <label class="form-label" style="font-size: 0.8rem;">Filter by Status</label>
                <select name="status" class="form-select">
                    <option value="">-- All Statuses --</option>
                    <option value="Active" <?= ($statusFilter === 'Active') ? 'selected' : '' ?>>Active Now</option>
                    <option value="Closed" <?= ($statusFilter === 'Closed') ? 'selected' : '' ?>>Closed</option>
                </select>
            </div>

            <div style="align-self: flex-end; display: flex; gap: 0.5rem;">
                <button type="submit" class="btn btn-primary"><i class="fas fa-filter"></i> Filter</button>
                <a href="<?= BASE_URL ?>/admin/sessions.php" class="btn btn-outline"><i class="fas fa-undo"></i></a>
            </div>
        </form>
    </div>
</div>

<!-- Sessions Table -->
<div class="card">
    <div class="card-header">
        <h3 class="card-title"><i class="fas fa-calendar-alt text-primary"></i> Sessions Record Archive (<?= count($sessions) ?>)</h3>
        <input type="text" class="form-control" placeholder="Search sessions..." style="max-width: 250px;" data-table-filter="#all-sessions-table">
    </div>
    <div class="table-responsive">
        <table class="table" id="all-sessions-table">
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Course Code &amp; Title</th>
                    <th>Lecturer</th>
                    <th>Room</th>
                    <th>Time Window</th>
                    <th>Turnout</th>
                    <th>Status</th>
                    <th class="text-right">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($sessions)): ?>
                    <tr><td colspan="8" class="text-center text-muted" style="padding: 2.5rem;">No sessions found.</td></tr>
                <?php else: ?>
                    <?php foreach ($sessions as $ses): 
                        $rate = ($ses['RegisteredCount'] > 0) ? round(($ses['AttendeesCount'] / $ses['RegisteredCount']) * 100, 1) : 0;
                    ?>
                        <tr>
                            <td><strong><?= formatDate($ses['SessionDate']) ?></strong></td>
                            <td>
                                <strong style="color: #1e3a8a;"><?= htmlspecialchars($ses['CourseCode']) ?></strong>
                                <div class="text-muted" style="font-size: 0.8rem;"><?= htmlspecialchars($ses['CourseTitle']) ?></div>
                            </td>
                            <td><?= htmlspecialchars($ses['LecTitle'] . ' ' . $ses['LecLast']) ?></td>
                            <td><span class="badge badge-neutral"><?= htmlspecialchars($ses['RoomCode']) ?></span></td>
                            <td><?= formatTime($ses['StartTime']) ?> - <?= formatTime($ses['EndTime']) ?></td>
                            <td><strong><?= $ses['AttendeesCount'] ?></strong> / <?= $ses['RegisteredCount'] ?> (<?= $rate ?>%)</td>
                            <td>
                                <span class="badge <?= ($ses['Status'] === 'Active') ? 'badge-success' : 'badge-neutral' ?>">
                                    <?= htmlspecialchars($ses['Status']) ?>
                                </span>
                            </td>
                            <td class="text-right">
                                <a href="<?= BASE_URL ?>/lecturer/active_session.php?session_id=<?= $ses['SessionID'] ?>" class="btn btn-outline btn-sm" target="_blank" title="View Live Projector">
                                    <i class="fas fa-external-link-alt"></i> View
                                </a>
                                <?php if ($ses['Status'] === 'Active'): ?>
                                    <a href="<?= BASE_URL ?>/admin/sessions.php?action=close&id=<?= $ses['SessionID'] ?>&csrf=<?= csrf_token() ?>" 
                                       class="btn btn-danger btn-sm" data-confirm="End this session now?">
                                        <i class="fas fa-stop-circle"></i> Close
                                    </a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once dirname(__DIR__) . '/includes/footer.php'; ?>
