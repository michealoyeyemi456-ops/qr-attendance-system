<?php
/**
 * QR Attendance System Using MS SQL and Apache
 * Database Seeder & Schema Initializer
 */

if (!defined('APP_INIT')) {
    require_once dirname(__DIR__) . '/config/config.php';
}

function seedDatabase(PDO $pdo): void {
    $driver = $pdo->getAttribute(PDO::ATTR_DRIVER_NAME);

    // Common password hash for 'Password123!'
    // Pre-computed bcrypt hash for instantaneous setup
    $defaultPassHash = '$2y$10$wI5f7N3V0j5e4M444L0O7eQn5iEeeM0M8Fq5l.T5y12/zD8Q0zQe.';
    // Generate fresh hash if needed
    if (function_exists('password_hash')) {
        $freshHash = password_hash('Password123!', PASSWORD_BCRYPT);
        if ($freshHash) {
            $defaultPassHash = $freshHash;
        }
    }

    if ($driver === 'sqlite') {
        // SQLite Schema creation
        $queries = [
            "CREATE TABLE IF NOT EXISTS Users (
                UserID INTEGER PRIMARY KEY AUTOINCREMENT,
                Username TEXT NOT NULL UNIQUE,
                PasswordHash TEXT NOT NULL,
                Email TEXT NOT NULL UNIQUE,
                Role TEXT NOT NULL CHECK (Role IN ('Admin', 'Lecturer', 'Student')),
                Status TEXT NOT NULL DEFAULT 'Active' CHECK (Status IN ('Active', 'Inactive', 'Suspended')),
                CreatedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
                LastLogin DATETIME NULL
            );",
            "CREATE TABLE IF NOT EXISTS Departments (
                DepartmentID INTEGER PRIMARY KEY AUTOINCREMENT,
                DepartmentCode TEXT NOT NULL UNIQUE,
                DepartmentName TEXT NOT NULL,
                Faculty TEXT NOT NULL DEFAULT 'School of Applied Science & Technology'
            );",
            "CREATE TABLE IF NOT EXISTS Programmes (
                ProgrammeID INTEGER PRIMARY KEY AUTOINCREMENT,
                DepartmentID INTEGER NOT NULL REFERENCES Departments(DepartmentID) ON DELETE CASCADE,
                ProgrammeCode TEXT NOT NULL UNIQUE,
                ProgrammeName TEXT NOT NULL,
                DurationYears INTEGER NOT NULL DEFAULT 2
            );",
            "CREATE TABLE IF NOT EXISTS Levels (
                LevelID INTEGER PRIMARY KEY AUTOINCREMENT,
                LevelCode TEXT NOT NULL UNIQUE,
                LevelName TEXT NOT NULL
            );",
            "CREATE TABLE IF NOT EXISTS Classrooms (
                ClassroomID INTEGER PRIMARY KEY AUTOINCREMENT,
                RoomCode TEXT NOT NULL UNIQUE,
                RoomName TEXT NOT NULL,
                Capacity INTEGER NOT NULL DEFAULT 60,
                Building TEXT NULL
            );",
            "CREATE TABLE IF NOT EXISTS Lecturers (
                LecturerID INTEGER PRIMARY KEY AUTOINCREMENT,
                UserID INTEGER NOT NULL UNIQUE REFERENCES Users(UserID) ON DELETE CASCADE,
                DepartmentID INTEGER NOT NULL REFERENCES Departments(DepartmentID),
                StaffID TEXT NOT NULL UNIQUE,
                Title TEXT NOT NULL DEFAULT 'Lecturer',
                FirstName TEXT NOT NULL,
                LastName TEXT NOT NULL,
                Phone TEXT NULL,
                OfficeNumber TEXT NULL
            );",
            "CREATE TABLE IF NOT EXISTS Students (
                StudentID INTEGER PRIMARY KEY AUTOINCREMENT,
                UserID INTEGER NOT NULL UNIQUE REFERENCES Users(UserID) ON DELETE CASCADE,
                DepartmentID INTEGER NOT NULL REFERENCES Departments(DepartmentID),
                ProgrammeID INTEGER NOT NULL REFERENCES Programmes(ProgrammeID),
                LevelID INTEGER NOT NULL REFERENCES Levels(LevelID),
                MatricNo TEXT NOT NULL UNIQUE,
                FirstName TEXT NOT NULL,
                LastName TEXT NOT NULL,
                Phone TEXT NULL,
                AcademicSession TEXT NOT NULL DEFAULT '2025/2026'
            );",
            "CREATE TABLE IF NOT EXISTS Courses (
                CourseID INTEGER PRIMARY KEY AUTOINCREMENT,
                DepartmentID INTEGER NOT NULL REFERENCES Departments(DepartmentID),
                LevelID INTEGER NOT NULL REFERENCES Levels(LevelID),
                CourseCode TEXT NOT NULL UNIQUE,
                CourseTitle TEXT NOT NULL,
                CreditUnits INTEGER NOT NULL DEFAULT 3,
                Semester TEXT NOT NULL DEFAULT 'First Semester'
            );",
            "CREATE TABLE IF NOT EXISTS CourseLecturers (
                AllocationID INTEGER PRIMARY KEY AUTOINCREMENT,
                CourseID INTEGER NOT NULL REFERENCES Courses(CourseID) ON DELETE CASCADE,
                LecturerID INTEGER NOT NULL REFERENCES Lecturers(LecturerID) ON DELETE CASCADE,
                AcademicSession TEXT NOT NULL DEFAULT '2025/2026',
                Semester TEXT NOT NULL DEFAULT 'First Semester',
                UNIQUE (CourseID, LecturerID, AcademicSession, Semester)
            );",
            "CREATE TABLE IF NOT EXISTS CourseRegistrations (
                RegistrationID INTEGER PRIMARY KEY AUTOINCREMENT,
                StudentID INTEGER NOT NULL REFERENCES Students(StudentID) ON DELETE CASCADE,
                CourseID INTEGER NOT NULL REFERENCES Courses(CourseID) ON DELETE CASCADE,
                AcademicSession TEXT NOT NULL DEFAULT '2025/2026',
                Semester TEXT NOT NULL DEFAULT 'First Semester',
                RegisteredAt DATETIME DEFAULT CURRENT_TIMESTAMP,
                UNIQUE (StudentID, CourseID, AcademicSession, Semester)
            );",
            "CREATE TABLE IF NOT EXISTS AttendanceSessions (
                SessionID INTEGER PRIMARY KEY AUTOINCREMENT,
                CourseID INTEGER NOT NULL REFERENCES Courses(CourseID),
                LecturerID INTEGER NOT NULL REFERENCES Lecturers(LecturerID),
                ClassroomID INTEGER NOT NULL REFERENCES Classrooms(ClassroomID),
                SessionDate DATE NOT NULL,
                StartTime TIME NOT NULL,
                EndTime TIME NOT NULL,
                DurationMinutes INTEGER NOT NULL DEFAULT 30,
                SessionToken TEXT NOT NULL UNIQUE,
                Status TEXT NOT NULL DEFAULT 'Active' CHECK (Status IN ('Active', 'Closed', 'Cancelled')),
                CreatedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
                ClosedAt DATETIME NULL
            );",
            "CREATE TABLE IF NOT EXISTS AttendanceRecords (
                RecordID INTEGER PRIMARY KEY AUTOINCREMENT,
                SessionID INTEGER NOT NULL REFERENCES AttendanceSessions(SessionID) ON DELETE CASCADE,
                StudentID INTEGER NOT NULL REFERENCES Students(StudentID) ON DELETE CASCADE,
                CourseID INTEGER NOT NULL REFERENCES Courses(CourseID),
                MarkedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
                ScanMethod TEXT NOT NULL DEFAULT 'QR_CAMERA' CHECK (ScanMethod IN ('QR_CAMERA', 'MANUAL_TOKEN', 'ADMIN_OVERRIDE', 'LECTURER_MANUAL')),
                Status TEXT NOT NULL DEFAULT 'Present' CHECK (Status IN ('Present', 'Late', 'Excused')),
                IPAddress TEXT NULL,
                UserAgent TEXT NULL,
                UNIQUE (SessionID, StudentID)
            );",
            "CREATE TABLE IF NOT EXISTS AuditLogs (
                LogID INTEGER PRIMARY KEY AUTOINCREMENT,
                UserID INTEGER NULL REFERENCES Users(UserID) ON DELETE SET NULL,
                Action TEXT NOT NULL,
                Category TEXT NOT NULL,
                Details TEXT NULL,
                IPAddress TEXT NULL,
                Timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
            );",
            "CREATE TABLE IF NOT EXISTS SystemSettings (
                SettingKey TEXT PRIMARY KEY,
                SettingValue TEXT NOT NULL,
                Description TEXT NULL,
                UpdatedAt DATETIME DEFAULT CURRENT_TIMESTAMP
            );"
        ];

        foreach ($queries as $sql) {
            $pdo->exec($sql);
        }

        // Check if data already exists
        $stmt = $pdo->query("SELECT COUNT(*) FROM Users");
        if ((int)$stmt->fetchColumn() > 0) {
            return; // Already seeded
        }

        // Insert Settings
        $settings = [
            ['INSTITUTION_NAME', 'Federal Institute of Technology & Applied Sciences', 'Name of the tertiary institution'],
            ['INSTITUTION_CODE', 'FITAS', 'Short institution code / acronym'],
            ['ACADEMIC_SESSION', '2025/2026', 'Current active academic session'],
            ['SEMESTER', 'First Semester', 'Current active academic semester'],
            ['ATTENDANCE_THRESHOLD', '75', 'Minimum percentage attendance required for exam eligibility'],
            ['DEFAULT_SESSION_DURATION', '30', 'Default attendance session validity duration in minutes'],
            ['QR_REFRESH_INTERVAL', '15', 'QR code display auto-refresh interval in seconds']
        ];
        $st = $pdo->prepare("INSERT INTO SystemSettings (SettingKey, SettingValue, Description) VALUES (?, ?, ?)");
        foreach ($settings as $s) {
            $st->execute($s);
        }

        // Insert Departments
        $depts = [
            ['CSC', 'Computer Science', 'School of Applied Science & Technology'],
            ['EEE', 'Electrical & Electronic Engineering', 'School of Engineering'],
            ['STA', 'Statistics & Mathematics', 'School of Applied Science & Technology'],
            ['SLT', 'Science Laboratory Technology', 'School of Pure & Applied Sciences']
        ];
        $st = $pdo->prepare("INSERT INTO Departments (DepartmentCode, DepartmentName, Faculty) VALUES (?, ?, ?)");
        foreach ($depts as $d) {
            $st->execute($d);
        }

        // Insert Programmes
        $progs = [
            [1, 'ND-CSC', 'National Diploma in Computer Science', 2],
            [1, 'HND-CSC', 'Higher National Diploma in Computer Science', 2],
            [2, 'ND-EEE', 'National Diploma in Electrical/Electronics Engineering', 2],
            [3, 'ND-STA', 'National Diploma in Statistics', 2]
        ];
        $st = $pdo->prepare("INSERT INTO Programmes (DepartmentID, ProgrammeCode, ProgrammeName, DurationYears) VALUES (?, ?, ?, ?)");
        foreach ($progs as $p) {
            $st->execute($p);
        }

        // Insert Levels
        $levels = [
            ['ND1', 'National Diploma I (ND I)'],
            ['ND2', 'National Diploma II (ND II)'],
            ['HND1', 'Higher National Diploma I (HND I)'],
            ['HND2', 'Higher National Diploma II (HND II)']
        ];
        $st = $pdo->prepare("INSERT INTO Levels (LevelCode, LevelName) VALUES (?, ?)");
        foreach ($levels as $l) {
            $st->execute($l);
        }

        // Insert Classrooms
        $rooms = [
            ['LAB-1', 'Main Computer Lab 1', 75, 'ICT Complex, Block A'],
            ['LAB-2', 'Advanced Software Lab 2', 60, 'ICT Complex, Block B'],
            ['HALL-A', 'Auditorium Hall A', 250, 'Academic Complex Ground Floor'],
            ['LT-04', 'Lecture Theater 04', 120, 'Science Building Level 2'],
            ['CR-102', 'Classroom 102', 50, 'Engineering Wing 1']
        ];
        $st = $pdo->prepare("INSERT INTO Classrooms (RoomCode, RoomName, Capacity, Building) VALUES (?, ?, ?, ?)");
        foreach ($rooms as $r) {
            $st->execute($r);
        }

        // Insert Users (Admin, Lecturers, Students)
        $users = [
            ['admin', $defaultPassHash, 'admin@fitas.edu.ng', 'Admin', 'Active'],
            ['dr.ibrahim', $defaultPassHash, 'a.ibrahim@fitas.edu.ng', 'Lecturer', 'Active'],
            ['engr.adeyemi', $defaultPassHash, 'o.adeyemi@fitas.edu.ng', 'Lecturer', 'Active'],
            ['dr.musa', $defaultPassHash, 'b.musa@fitas.edu.ng', 'Lecturer', 'Active'],
            ['fitas/2024/001', $defaultPassHash, 'chinedu.o@student.fitas.edu.ng', 'Student', 'Active'],
            ['fitas/2024/002', $defaultPassHash, 'amina.b@student.fitas.edu.ng', 'Student', 'Active'],
            ['fitas/2024/003', $defaultPassHash, 'oluwaseun.a@student.fitas.edu.ng', 'Student', 'Active'],
            ['fitas/2024/004', $defaultPassHash, 'fatima.s@student.fitas.edu.ng', 'Student', 'Active'],
            ['fitas/2024/005', $defaultPassHash, 'emeka.n@student.fitas.edu.ng', 'Student', 'Active']
        ];
        $st = $pdo->prepare("INSERT INTO Users (Username, PasswordHash, Email, Role, Status) VALUES (?, ?, ?, ?, ?)");
        foreach ($users as $u) {
            $st->execute($u);
        }

        // Insert Lecturers
        $lecturers = [
            [2, 1, 'FITAS/STF/CSC01', 'Dr.', 'Aliyu', 'Ibrahim', '08031234567', 'ICT Complex Rm 204'],
            [3, 1, 'FITAS/STF/CSC02', 'Engr.', 'Olumide', 'Adeyemi', '08029876543', 'ICT Complex Rm 208'],
            [4, 2, 'FITAS/STF/EEE01', 'Dr.', 'Bello', 'Musa', '08134567890', 'Engineering Wing B-12']
        ];
        $st = $pdo->prepare("INSERT INTO Lecturers (UserID, DepartmentID, StaffID, Title, FirstName, LastName, Phone, OfficeNumber) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        foreach ($lecturers as $lec) {
            $st->execute($lec);
        }

        // Insert Students
        $students = [
            [5, 1, 2, 3, 'FITAS/HND/CSC/24/001', 'Chinedu', 'Okonkwo', '08051112233', '2025/2026'],
            [6, 1, 2, 3, 'FITAS/HND/CSC/24/002', 'Amina', 'Bello', '08072223344', '2025/2026'],
            [7, 1, 2, 3, 'FITAS/HND/CSC/24/003', 'Oluwaseun', 'Adebayo', '08093334455', '2025/2026'],
            [8, 1, 2, 3, 'FITAS/HND/CSC/24/004', 'Fatima', 'Sanusi', '08084445566', '2025/2026'],
            [9, 1, 2, 3, 'FITAS/HND/CSC/24/005', 'Emeka', 'Nnamdi', '08065556677', '2025/2026']
        ];
        $st = $pdo->prepare("INSERT INTO Students (UserID, DepartmentID, ProgrammeID, LevelID, MatricNo, FirstName, LastName, Phone, AcademicSession) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        foreach ($students as $stu) {
            $st->execute($stu);
        }

        // Insert Courses
        $courses = [
            [1, 3, 'COM 311', 'Operating Systems & Architecture', 3, 'First Semester'],
            [1, 3, 'COM 312', 'Database Design & Management (MS SQL)', 3, 'First Semester'],
            [1, 3, 'COM 313', 'Computer Programming Using C++/Java', 4, 'First Semester'],
            [1, 3, 'COM 314', 'Software Engineering Methodologies', 3, 'First Semester'],
            [1, 3, 'GNS 301', 'Communication in English & Research', 2, 'First Semester']
        ];
        $st = $pdo->prepare("INSERT INTO Courses (DepartmentID, LevelID, CourseCode, CourseTitle, CreditUnits, Semester) VALUES (?, ?, ?, ?, ?, ?)");
        foreach ($courses as $c) {
            $st->execute($c);
        }

        // Insert Course Allocations
        $allocs = [
            [1, 1, '2025/2026', 'First Semester'],
            [2, 1, '2025/2026', 'First Semester'],
            [3, 2, '2025/2026', 'First Semester'],
            [4, 2, '2025/2026', 'First Semester']
        ];
        $st = $pdo->prepare("INSERT INTO CourseLecturers (CourseID, LecturerID, AcademicSession, Semester) VALUES (?, ?, ?, ?)");
        foreach ($allocs as $a) {
            $st->execute($a);
        }

        // Insert Course Registrations (all 5 students for COM 311 - COM 314)
        $st = $pdo->prepare("INSERT INTO CourseRegistrations (StudentID, CourseID, AcademicSession, Semester) VALUES (?, ?, '2025/2026', 'First Semester')");
        for ($s = 1; $s <= 5; $s++) {
            for ($c = 1; $c <= 4; $c++) {
                $st->execute([$s, $c]);
            }
        }

        // Insert Attendance Sessions (2 past sessions + 1 active today)
        $today = date('Y-m-d');
        $now = date('H:i:s');
        $endLater = date('H:i:s', strtotime('+60 minutes'));
        $pastDate1 = date('Y-m-d', strtotime('-7 days'));
        $pastDate2 = date('Y-m-d', strtotime('-3 days'));

        $pdo->exec("INSERT INTO AttendanceSessions (CourseID, LecturerID, ClassroomID, SessionDate, StartTime, EndTime, DurationMinutes, SessionToken, Status, CreatedAt, ClosedAt) VALUES
            (2, 1, 1, '{$pastDate1}', '09:00:00', '09:30:00', 30, 'SES-COM312-HIST01-SEC982', 'Closed', '{$pastDate1} 09:00:00', '{$pastDate1} 09:30:00'),
            (2, 1, 1, '{$pastDate2}', '09:00:00', '09:30:00', 30, 'SES-COM312-HIST02-SEC105', 'Closed', '{$pastDate2} 09:00:00', '{$pastDate2} 09:30:00'),
            (2, 1, 1, '{$today}', '{$now}', '{$endLater}', 60, 'SES-COM312-LIVE-ACTIVE-TK8421', 'Active', CURRENT_TIMESTAMP, NULL)
        ");

        // Insert Attendance Records
        $pdo->exec("INSERT INTO AttendanceRecords (SessionID, StudentID, CourseID, MarkedAt, ScanMethod, Status, IPAddress) VALUES
            (1, 1, 2, '{$pastDate1} 09:04:12', 'QR_CAMERA', 'Present', '192.168.1.101'),
            (1, 2, 2, '{$pastDate1} 09:07:44', 'QR_CAMERA', 'Present', '192.168.1.102'),
            (1, 3, 2, '{$pastDate1} 09:11:05', 'QR_CAMERA', 'Present', '192.168.1.103'),
            (1, 4, 2, '{$pastDate1} 09:14:22', 'QR_CAMERA', 'Present', '192.168.1.104'),
            (1, 5, 2, '{$pastDate1} 09:26:19', 'QR_CAMERA', 'Late', '192.168.1.105'),
            (2, 1, 2, '{$pastDate2} 09:05:30', 'QR_CAMERA', 'Present', '192.168.1.101'),
            (2, 2, 2, '{$pastDate2} 09:06:50', 'QR_CAMERA', 'Present', '192.168.1.102'),
            (2, 3, 2, '{$pastDate2} 09:09:15', 'QR_CAMERA', 'Present', '192.168.1.103'),
            (3, 1, 2, CURRENT_TIMESTAMP, 'QR_CAMERA', 'Present', '192.168.1.101'),
            (3, 2, 2, CURRENT_TIMESTAMP, 'QR_CAMERA', 'Present', '192.168.1.102')
        ");

        // Insert Audit Logs
        $pdo->exec("INSERT INTO AuditLogs (UserID, Action, Category, Details, IPAddress) VALUES
            (1, 'SYSTEM_INITIALIZATION', 'ADMIN', 'Initialized system schema, academic settings, and security credentials', '127.0.0.1'),
            (2, 'SESSION_CREATED', 'SESSION', 'Created live attendance session for COM 312 in Room LAB-1', '192.168.1.50'),
            (5, 'QR_ATTENDANCE_RECORDED', 'ATTENDANCE', 'Student Chinedu Okonkwo scanned QR code for COM 312', '192.168.1.101'),
            (6, 'QR_ATTENDANCE_RECORDED', 'ATTENDANCE', 'Student Amina Bello scanned QR code for COM 312', '192.168.1.102')
        ");
    }
}
