<?php
/**
 * QR Attendance System Using MS SQL and Apache
 * Administrator Portal: Manage Course Registrations / Student Enrolments
 */

require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/includes/functions.php';
require_once dirname(__DIR__) . '/includes/auth_guard.php';

$user = require_role('Admin');
$pdo = Database::getConnection();

$error = null;

// Handle Delete Registration
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    if (verify_csrf($_GET['csrf'] ?? '')) {
        $regId = (int)$_GET['id'];
        $pdo->prepare("DELETE FROM CourseRegistrations WHERE RegistrationID = ?")->execute([$regId]);
        logAudit($user['user_id'], 'REGISTRATION_DELETED', 'REGISTRATION', "Removed enrolment #{$regId}");
        flash('success', 'Student course enrolment removed successfully.', 'info');
    }
    header('Location: ' . BASE_URL . '/admin/registrations.php');
    exit;
}

// Handle Add Registration
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'enrol') {
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        $error = 'Session expired. Please try again.';
    } else {
        $studentId = (int)($_POST['student_id'] ?? 0);
        $courseId = (int)($_POST['course_id'] ?? 0);
        $session = trim($_POST['academic_session'] ?? CURRENT_ACADEMIC_SESSION);
        $semester = trim($_POST['semester'] ?? CURRENT_SEMESTER);

        if ($studentId > 0 && $courseId > 0) {
            try {
                $stCheck = $pdo->prepare("SELECT RegistrationID FROM CourseRegistrations WHERE StudentID = ? AND CourseID = ? AND AcademicSession = ? AND Semester = ?");
                $stCheck->execute([$studentId, $courseId, $session, $semester]);
                if ($stCheck->fetch()) {
                    $error = 'This student is already enrolled in this course for this semester.';
                } else {
                    $stIns = $pdo->prepare("
                        INSERT INTO CourseRegistrations (StudentID, CourseID, AcademicSession, Semester, RegisteredAt)
                        VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
                    ");
                    $stIns->execute([$studentId, $courseId, $session, $semester]);

                    logAudit($user['user_id'], 'STUDENT_ENROLLED', 'REGISTRATION', "Enrolled Student #{$studentId} in Course #{$courseId}");
                    flash('success', 'Student enrolled into course successfully.', 'success');
                    header('Location: ' . BASE_URL . '/admin/registrations.php');
                    exit;
                }
            } catch (Exception $e) {
                $error = 'Enrolment error: ' . $e->getMessage();
            }
        }
    }
}

// Filter
$courseFilter = isset($_GET['course_id']) ? (int)$_GET['course_id'] : 0;
$sqlList = "
    SELECT cr.RegistrationID, cr.AcademicSession, cr.Semester, cr.RegisteredAt,
           s.StudentID, s.MatricNo, s.FirstName, s.LastName,
           c.CourseID, c.CourseCode, c.CourseTitle, c.CreditUnits,
           d.DepartmentCode
    FROM CourseRegistrations cr
    JOIN Students s ON cr.StudentID = s.StudentID
    JOIN Courses c ON cr.CourseID = c.CourseID
    JOIN Departments d ON s.DepartmentID = d.DepartmentID
";
if ($courseFilter > 0) {
    $sqlList .= " WHERE cr.CourseID = {$courseFilter}";
}
$sqlList .= " ORDER BY cr.RegistrationID DESC";
$registrations = $pdo->query($sqlList)->fetchAll();

// Dropdown lists
$students = $pdo->query("SELECT StudentID, MatricNo, FirstName, LastName FROM Students ORDER BY MatricNo ASC")->fetchAll();
$courses = $pdo->query("SELECT CourseID, CourseCode, CourseTitle FROM Courses ORDER BY CourseCode ASC")->fetchAll();

$pageTitle = 'Course Enrolments';
require_once dirname(__DIR__) . '/includes/header.php';
?>

<div class="page-header">
    <div>
        <h1 class="page-title"><i class="fas fa-id-card text-primary"></i> Course Enrolments &amp; Registrations</h1>
        <div class="page-subtitle">Official semester course registrations determining lecture attendance eligibility</div>
    </div>
</div>

<?php if ($error): ?>
    <div class="alert alert-danger"><i class="fas fa-times-circle"></i> <?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<!-- Quick Enrolment Form Card -->
<div class="card mb-4" style="background: #f8fafc; border: 1px solid #cbd5e1;">
    <div class="card-header" style="background: #ffffff;">
        <h3 class="card-title"><i class="fas fa-user-plus text-primary"></i> Enrol Student into Course</h3>
    </div>
    <div class="card-body">
        <form action="<?= BASE_URL ?>/admin/registrations.php" method="POST" class="d-flex align-items-center gap-3 flex-wrap">
            <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
            <input type="hidden" name="action" value="enrol">

            <div style="flex: 1; min-width: 260px;">
                <label class="form-label" style="font-size: 0.8rem;">Select Student *</label>
                <select name="student_id" class="form-select" required>
                    <option value="">-- Choose Student --</option>
                    <?php foreach ($students as $s): ?>
                        <option value="<?= $s['StudentID'] ?>">
                            <?= htmlspecialchars($s['MatricNo'] . ' - ' . $s['FirstName'] . ' ' . $s['LastName']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div style="flex: 1; min-width: 260px;">
                <label class="form-label" style="font-size: 0.8rem;">Select Course *</label>
                <select name="course_id" class="form-select" required>
                    <option value="">-- Choose Course --</option>
                    <?php foreach ($courses as $c): ?>
                        <option value="<?= $c['CourseID'] ?>">
                            <?= htmlspecialchars($c['CourseCode'] . ' - ' . $c['CourseTitle']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div style="width: 140px;">
                <label class="form-label" style="font-size: 0.8rem;">Session</label>
                <input type="text" name="academic_session" class="form-control" value="<?= CURRENT_ACADEMIC_SESSION ?>" required>
            </div>

            <div style="width: 150px;">
                <label class="form-label" style="font-size: 0.8rem;">Semester</label>
                <input type="text" name="semester" class="form-control" value="<?= CURRENT_SEMESTER ?>" required>
            </div>

            <div style="align-self: flex-end;">
                <button type="submit" class="btn btn-primary"><i class="fas fa-check"></i> Enrol Student</button>
            </div>
        </form>
    </div>
</div>

<!-- Enrolments Table -->
<div class="card">
    <div class="card-header">
        <h3 class="card-title"><i class="fas fa-list text-primary"></i> Active Course Enrolment Records (<?= count($registrations) ?>)</h3>
        <input type="text" class="form-control" placeholder="Search student or course..." style="max-width: 250px;" data-table-filter="#regs-table">
    </div>
    <div class="table-responsive">
        <table class="table" id="regs-table">
            <thead>
                <tr>
                    <th>Matriculation No</th>
                    <th>Student Name</th>
                    <th>Department</th>
                    <th>Course Code &amp; Title</th>
                    <th>Session &amp; Term</th>
                    <th>Enrolled Date</th>
                    <th class="text-right">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($registrations)): ?>
                    <tr><td colspan="7" class="text-center text-muted" style="padding: 2.5rem;">No course registration records found.</td></tr>
                <?php else: ?>
                    <?php foreach ($registrations as $r): ?>
                        <tr>
                            <td><strong><?= htmlspecialchars($r['MatricNo']) ?></strong></td>
                            <td><?= htmlspecialchars($r['FirstName'] . ' ' . $r['LastName']) ?></td>
                            <td><span class="badge badge-neutral"><?= htmlspecialchars($r['DepartmentCode']) ?></span></td>
                            <td>
                                <strong style="color: #1e3a8a;"><?= htmlspecialchars($r['CourseCode']) ?></strong>
                                <div class="text-muted" style="font-size: 0.775rem;"><?= htmlspecialchars($r['CourseTitle']) ?></div>
                            </td>
                            <td><?= htmlspecialchars($r['AcademicSession']) ?> &bull; <?= htmlspecialchars($r['Semester']) ?></td>
                            <td style="font-size: 0.825rem;"><?= formatDateTime($r['RegisteredAt']) ?></td>
                            <td class="text-right">
                                <a href="<?= BASE_URL ?>/admin/registrations.php?action=delete&id=<?= $r['RegistrationID'] ?>&csrf=<?= csrf_token() ?>" 
                                   class="btn btn-danger btn-sm" 
                                   data-confirm="Unenrol <?= htmlspecialchars($r['MatricNo']) ?> from <?= htmlspecialchars($r['CourseCode']) ?>?"
                                   title="Unenrol Student">
                                    <i class="fas fa-user-minus"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once dirname(__DIR__) . '/includes/footer.php'; ?>
