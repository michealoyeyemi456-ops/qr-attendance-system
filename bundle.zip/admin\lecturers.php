<?php
/**
 * QR Attendance System Using MS SQL and Apache
 * Administrator Portal: Manage Lecturers (Full CRUD)
 */

require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/includes/functions.php';
require_once dirname(__DIR__) . '/includes/auth_guard.php';

$user = require_role('Admin');
$pdo = Database::getConnection();

$action = $_GET['action'] ?? 'list';
$lecturerId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$error = null;

// Handle DELETE
if ($action === 'delete' && $lecturerId > 0) {
    if (verify_csrf($_GET['csrf'] ?? '')) {
        try {
            $stU = $pdo->prepare("SELECT UserID, StaffID FROM Lecturers WHERE LecturerID = ?");
            $stU->execute([$lecturerId]);
            $lec = $stU->fetch();
            if ($lec) {
                $pdo->prepare("DELETE FROM Users WHERE UserID = ?")->execute([$lec['UserID']]);
                logAudit($user['user_id'], 'LECTURER_DELETED', 'ADMIN', "Deleted lecturer {$lec['StaffID']}");
                flash('success', "Lecturer record {$lec['StaffID']} deleted successfully.", 'info');
            }
        } catch (Exception $e) {
            flash('danger', 'Error deleting lecturer: ' . $e->getMessage(), 'danger');
        }
    }
    header('Location: ' . BASE_URL . '/admin/lecturers.php');
    exit;
}

// Handle CREATE / UPDATE
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        $error = 'Security session expired. Please submit again.';
    } else {
        $staffId = strtoupper(trim($_POST['staff_id'] ?? ''));
        $title = trim($_POST['title'] ?? 'Dr.');
        $firstName = trim($_POST['first_name'] ?? '');
        $lastName = trim($_POST['last_name'] ?? '');
        $email = strtolower(trim($_POST['email'] ?? ''));
        $phone = trim($_POST['phone'] ?? '');
        $officeNumber = trim($_POST['office_number'] ?? '');
        $deptId = (int)($_POST['department_id'] ?? 0);
        $status = in_array($_POST['status'] ?? '', ['Active', 'Inactive', 'Suspended']) ? $_POST['status'] : 'Active';
        $password = trim($_POST['password'] ?? '');

        if (empty($staffId) || empty($firstName) || empty($lastName) || empty($email) || $deptId <= 0) {
            $error = 'Please fill all required fields correctly.';
        } else {
            try {
                if ($action === 'create') {
                    $stCheck = $pdo->prepare("SELECT UserID FROM Users WHERE LOWER(Username) = LOWER(?) OR LOWER(Email) = LOWER(?)");
                    $stCheck->execute([$staffId, $email]);
                    if ($stCheck->fetch()) {
                        $error = 'A user account with this Staff ID or Email already exists.';
                    } else {
                        $passHash = password_hash(!empty($password) ? $password : 'Password123!', PASSWORD_BCRYPT);
                        
                        // Insert User
                        $stUser = $pdo->prepare("INSERT INTO Users (Username, PasswordHash, Email, Role, Status) VALUES (?, ?, ?, 'Lecturer', ?)");
                        $stUser->execute([$staffId, $passHash, $email, $status]);
                        $newUserId = (int)$pdo->lastInsertId();

                        // Insert Lecturer
                        $stLec = $pdo->prepare("
                            INSERT INTO Lecturers (UserID, DepartmentID, StaffID, Title, FirstName, LastName, Phone, OfficeNumber)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                        ");
                        $stLec->execute([$newUserId, $deptId, $staffId, $title, $firstName, $lastName, $phone, $officeNumber]);

                        logAudit($user['user_id'], 'LECTURER_CREATED', 'ADMIN', "Created lecturer {$title} {$firstName} {$lastName} ({$staffId})");
                        flash('success', "Lecturer {$staffId} successfully created.", 'success');
                        header('Location: ' . BASE_URL . '/admin/lecturers.php');
                        exit;
                    }
                } elseif ($action === 'edit' && $lecturerId > 0) {
                    $stGet = $pdo->prepare("SELECT UserID FROM Lecturers WHERE LecturerID = ?");
                    $stGet->execute([$lecturerId]);
                    $currentUserId = (int)$stGet->fetchColumn();

                    if ($currentUserId > 0) {
                        // Update User
                        if (!empty($password)) {
                            $passHash = password_hash($password, PASSWORD_BCRYPT);
                            $pdo->prepare("UPDATE Users SET Email = ?, Status = ?, PasswordHash = ? WHERE UserID = ?")->execute([$email, $status, $passHash, $currentUserId]);
                        } else {
                            $pdo->prepare("UPDATE Users SET Email = ?, Status = ? WHERE UserID = ?")->execute([$email, $status, $currentUserId]);
                        }

                        // Update Lecturer
                        $stUpd = $pdo->prepare("
                            UPDATE Lecturers SET StaffID = ?, Title = ?, FirstName = ?, LastName = ?, Phone = ?, OfficeNumber = ?, DepartmentID = ?
                            WHERE LecturerID = ?
                        ");
                        $stUpd->execute([$staffId, $title, $firstName, $lastName, $phone, $officeNumber, $deptId, $lecturerId]);

                        logAudit($user['user_id'], 'LECTURER_UPDATED', 'ADMIN', "Updated lecturer profile {$staffId}");
                        flash('success', "Lecturer profile {$staffId} updated successfully.", 'success');
                        header('Location: ' . BASE_URL . '/admin/lecturers.php');
                        exit;
                    }
                }
            } catch (Exception $e) {
                $error = 'Database error: ' . $e->getMessage();
            }
        }
    }
}

$departments = $pdo->query("SELECT DepartmentID, DepartmentCode, DepartmentName FROM Departments ORDER BY DepartmentName ASC")->fetchAll();

$editLecturer = null;
if ($action === 'edit' && $lecturerId > 0) {
    $stEd = $pdo->prepare("
        SELECT l.*, u.Email, u.Status AS AccountStatus
        FROM Lecturers l
        JOIN Users u ON l.UserID = u.UserID
        WHERE l.LecturerID = ?
    ");
    $stEd->execute([$lecturerId]);
    $editLecturer = $stEd->fetch();
}

$lecturersList = $pdo->query("
    SELECT l.LecturerID, l.StaffID, l.Title, l.FirstName, l.LastName, l.Phone, l.OfficeNumber,
           d.DepartmentCode, d.DepartmentName,
           u.Email, u.Status, u.LastLogin,
           (SELECT COUNT(*) FROM CourseLecturers cl WHERE cl.LecturerID = l.LecturerID) AS AssignedCoursesCount
    FROM Lecturers l
    JOIN Users u ON l.UserID = u.UserID
    JOIN Departments d ON l.DepartmentID = d.DepartmentID
    ORDER BY l.StaffID ASC
")->fetchAll();

$pageTitle = 'Manage Lecturers';
require_once dirname(__DIR__) . '/includes/header.php';
?>

<div class="page-header">
    <div>
        <h1 class="page-title"><i class="fas fa-chalkboard-teacher text-primary"></i> Manage Lecturers</h1>
        <div class="page-subtitle">Faculty staff directory, appointments &amp; teaching roles</div>
    </div>
    <div>
        <?php if ($action !== 'create'): ?>
            <a href="<?= BASE_URL ?>/admin/lecturers.php?action=create" class="btn btn-primary">
                <i class="fas fa-plus-circle"></i> Add New Lecturer
            </a>
        <?php else: ?>
            <a href="<?= BASE_URL ?>/admin/lecturers.php" class="btn btn-outline">
                <i class="fas fa-arrow-left"></i> Back to Lecturer List
            </a>
        <?php endif; ?>
    </div>
</div>

<?php if ($error): ?>
    <div class="alert alert-danger"><i class="fas fa-times-circle"></i> <?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<?php if ($action === 'create' || $action === 'edit'): ?>
    <div class="card" style="max-width: 800px; margin: 0 auto 2rem;">
        <div class="card-header">
            <h3 class="card-title">
                <i class="fas <?= ($action === 'create') ? 'fa-user-plus' : 'fa-user-edit' ?> text-primary"></i>
                <?= ($action === 'create') ? 'Register Faculty Lecturer' : 'Edit Lecturer Profile' ?>
            </h3>
        </div>
        <div class="card-body">
            <form action="<?= BASE_URL ?>/admin/lecturers.php?action=<?= $action ?><?= ($action === 'edit') ? "&id={$lecturerId}" : '' ?>" method="POST">
                <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                    <div class="form-group">
                        <label class="form-label" for="staff_id">Staff Identification ID *</label>
                        <input type="text" id="staff_id" name="staff_id" class="form-control" 
                               value="<?= htmlspecialchars($editLecturer['StaffID'] ?? '') ?>" 
                               placeholder="e.g. FITAS/STF/CSC01" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="email">Institutional Email *</label>
                        <input type="email" id="email" name="email" class="form-control" 
                               value="<?= htmlspecialchars($editLecturer['Email'] ?? '') ?>" 
                               placeholder="lecturer@fitas.edu.ng" required>
                    </div>
                </div>

                <div style="display: grid; grid-template-columns: 100px 1fr 1fr; gap: 1rem;">
                    <div class="form-group">
                        <label class="form-label" for="title">Title *</label>
                        <select name="title" id="title" class="form-select" required>
                            <option value="Dr." <?= (($editLecturer['Title'] ?? '') === 'Dr.') ? 'selected' : '' ?>>Dr.</option>
                            <option value="Prof." <?= (($editLecturer['Title'] ?? '') === 'Prof.') ? 'selected' : '' ?>>Prof.</option>
                            <option value="Engr." <?= (($editLecturer['Title'] ?? '') === 'Engr.') ? 'selected' : '' ?>>Engr.</option>
                            <option value="Mr." <?= (($editLecturer['Title'] ?? '') === 'Mr.') ? 'selected' : '' ?>>Mr.</option>
                            <option value="Mrs." <?= (($editLecturer['Title'] ?? '') === 'Mrs.') ? 'selected' : '' ?>>Mrs.</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="first_name">First Name *</label>
                        <input type="text" id="first_name" name="first_name" class="form-control" 
                               value="<?= htmlspecialchars($editLecturer['FirstName'] ?? '') ?>" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="last_name">Last Name *</label>
                        <input type="text" id="last_name" name="last_name" class="form-control" 
                               value="<?= htmlspecialchars($editLecturer['LastName'] ?? '') ?>" required>
                    </div>
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                    <div class="form-group">
                        <label class="form-label" for="department_id">Department *</label>
                        <select name="department_id" id="department_id" class="form-select" required>
                            <option value="">-- Select Department --</option>
                            <?php foreach ($departments as $d): ?>
                                <option value="<?= $d['DepartmentID'] ?>" <?= (($editLecturer['DepartmentID'] ?? 0) == $d['DepartmentID']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($d['DepartmentCode'] . ' - ' . $d['DepartmentName']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="office_number">Office / Room Location</label>
                        <input type="text" id="office_number" name="office_number" class="form-control" 
                               value="<?= htmlspecialchars($editLecturer['OfficeNumber'] ?? '') ?>" placeholder="e.g. ICT Complex Rm 204">
                    </div>
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 1rem;">
                    <div class="form-group">
                        <label class="form-label" for="phone">Phone Number</label>
                        <input type="text" id="phone" name="phone" class="form-control" 
                               value="<?= htmlspecialchars($editLecturer['Phone'] ?? '') ?>" placeholder="08012345678">
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="status">Account Status</label>
                        <select name="status" id="status" class="form-select">
                            <option value="Active" <?= (($editLecturer['AccountStatus'] ?? 'Active') === 'Active') ? 'selected' : '' ?>>Active</option>
                            <option value="Inactive" <?= (($editLecturer['AccountStatus'] ?? '') === 'Inactive') ? 'selected' : '' ?>>Inactive</option>
                            <option value="Suspended" <?= (($editLecturer['AccountStatus'] ?? '') === 'Suspended') ? 'selected' : '' ?>>Suspended</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="password">Password <?= ($action === 'create') ? '(Optional)' : '(Leave blank to keep)' ?></label>
                        <input type="password" id="password" name="password" class="form-control" placeholder="<?= ($action === 'create') ? 'Defaults to Password123!' : '••••••••' ?>">
                    </div>
                </div>

                <div class="d-flex gap-2 justify-between mt-3">
                    <a href="<?= BASE_URL ?>/admin/lecturers.php" class="btn btn-outline">Cancel</a>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> <?= ($action === 'create') ? 'Save Lecturer Profile' : 'Update Lecturer' ?>
                    </button>
                </div>
            </form>
        </div>
    </div>
<?php endif; ?>

<!-- Lecturers Directory Table -->
<div class="card">
    <div class="card-header">
        <h3 class="card-title"><i class="fas fa-chalkboard text-primary"></i> Faculty Lecturer Directory (<?= count($lecturersList) ?>)</h3>
        <input type="text" class="form-control" placeholder="Search staff ID, name..." style="max-width: 250px;" data-table-filter="#lecturers-table">
    </div>
    <div class="table-responsive">
        <table class="table" id="lecturers-table">
            <thead>
                <tr>
                    <th>Staff ID</th>
                    <th>Lecturer Name &amp; Title</th>
                    <th>Department</th>
                    <th>Email / Phone</th>
                    <th>Office</th>
                    <th>Courses</th>
                    <th>Status</th>
                    <th class="text-right">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($lecturersList)): ?>
                    <tr><td colspan="8" class="text-center text-muted" style="padding: 2.5rem;">No lecturer records found.</td></tr>
                <?php else: ?>
                    <?php foreach ($lecturersList as $l): ?>
                        <tr>
                            <td><strong><?= htmlspecialchars($l['StaffID']) ?></strong></td>
                            <td>
                                <strong><?= htmlspecialchars($l['Title'] . ' ' . $l['FirstName'] . ' ' . $l['LastName']) ?></strong>
                            </td>
                            <td><?= htmlspecialchars($l['DepartmentCode']) ?></td>
                            <td>
                                <div><?= htmlspecialchars($l['Email']) ?></div>
                                <div class="text-muted" style="font-size: 0.775rem;"><?= htmlspecialchars($l['Phone'] ?: 'N/A') ?></div>
                            </td>
                            <td><?= htmlspecialchars($l['OfficeNumber'] ?: 'Campus') ?></td>
                            <td><span class="badge badge-info"><?= $l['AssignedCoursesCount'] ?> Courses</span></td>
                            <td>
                                <span class="badge <?= ($l['Status'] === 'Active') ? 'badge-success' : 'badge-neutral' ?>">
                                    <?= htmlspecialchars($l['Status']) ?>
                                </span>
                            </td>
                            <td class="text-right">
                                <a href="<?= BASE_URL ?>/admin/lecturers.php?action=edit&id=<?= $l['LecturerID'] ?>" class="btn btn-outline btn-sm" title="Edit Lecturer">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <a href="<?= BASE_URL ?>/admin/lecturers.php?action=delete&id=<?= $l['LecturerID'] ?>&csrf=<?= csrf_token() ?>" 
                                   class="btn btn-danger btn-sm" 
                                   data-confirm="Are you sure you want to remove lecturer <?= htmlspecialchars($l['StaffID']) ?>?" 
                                   title="Delete Lecturer">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once dirname(__DIR__) . '/includes/footer.php'; ?>
