import sqlite3
import os
import hashlib

db_path = os.path.join(os.path.dirname(__file__), 'attendance_portable.db')
conn = sqlite3.connect(db_path)
cur = conn.cursor()

# Enable foreign keys
cur.execute("PRAGMA foreign_keys = ON;")

# Tables
cur.executescript("""
CREATE TABLE IF NOT EXISTS Users (
    UserID INTEGER PRIMARY KEY AUTOINCREMENT,
    Username TEXT NOT NULL UNIQUE,
    PasswordHash TEXT NOT NULL,
    Email TEXT NOT NULL UNIQUE,
    Role TEXT NOT NULL CHECK (Role IN ('Admin', 'Lecturer', 'Student')),
    Status TEXT NOT NULL DEFAULT 'Active' CHECK (Status IN ('Active', 'Inactive', 'Suspended')),
    CreatedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    LastLogin DATETIME NULL
);

CREATE TABLE IF NOT EXISTS Departments (
    DepartmentID INTEGER PRIMARY KEY AUTOINCREMENT,
    DepartmentCode TEXT NOT NULL UNIQUE,
    DepartmentName TEXT NOT NULL,
    Faculty TEXT NOT NULL DEFAULT 'School of Applied Science & Technology'
);

CREATE TABLE IF NOT EXISTS Programmes (
    ProgrammeID INTEGER PRIMARY KEY AUTOINCREMENT,
    DepartmentID INTEGER NOT NULL REFERENCES Departments(DepartmentID) ON DELETE CASCADE,
    ProgrammeCode TEXT NOT NULL UNIQUE,
    ProgrammeName TEXT NOT NULL,
    DurationYears INTEGER NOT NULL DEFAULT 2
);

CREATE TABLE IF NOT EXISTS Levels (
    LevelID INTEGER PRIMARY KEY AUTOINCREMENT,
    LevelCode TEXT NOT NULL UNIQUE,
    LevelName TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS Classrooms (
    ClassroomID INTEGER PRIMARY KEY AUTOINCREMENT,
    RoomCode TEXT NOT NULL UNIQUE,
    RoomName TEXT NOT NULL,
    Capacity INTEGER NOT NULL DEFAULT 60,
    Building TEXT NULL
);

CREATE TABLE IF NOT EXISTS Lecturers (
    LecturerID INTEGER PRIMARY KEY AUTOINCREMENT,
    UserID INTEGER NOT NULL UNIQUE REFERENCES Users(UserID) ON DELETE CASCADE,
    DepartmentID INTEGER NOT NULL REFERENCES Departments(DepartmentID),
    StaffID TEXT NOT NULL UNIQUE,
    Title TEXT NOT NULL DEFAULT 'Lecturer',
    FirstName TEXT NOT NULL,
    LastName TEXT NOT NULL,
    Phone TEXT NULL,
    OfficeNumber TEXT NULL
);

CREATE TABLE IF NOT EXISTS Students (
    StudentID INTEGER PRIMARY KEY AUTOINCREMENT,
    UserID INTEGER NOT NULL UNIQUE REFERENCES Users(UserID) ON DELETE CASCADE,
    DepartmentID INTEGER NOT NULL REFERENCES Departments(DepartmentID),
    ProgrammeID INTEGER NOT NULL REFERENCES Programmes(ProgrammeID),
    LevelID INTEGER NOT NULL REFERENCES Levels(LevelID),
    MatricNo TEXT NOT NULL UNIQUE,
    FirstName TEXT NOT NULL,
    LastName TEXT NOT NULL,
    Phone TEXT NULL,
    AcademicSession TEXT NOT NULL DEFAULT '2025/2026'
);

CREATE TABLE IF NOT EXISTS Courses (
    CourseID INTEGER PRIMARY KEY AUTOINCREMENT,
    DepartmentID INTEGER NOT NULL REFERENCES Departments(DepartmentID),
    LevelID INTEGER NOT NULL REFERENCES Levels(LevelID),
    CourseCode TEXT NOT NULL UNIQUE,
    CourseTitle TEXT NOT NULL,
    CreditUnits INTEGER NOT NULL DEFAULT 3,
    Semester TEXT NOT NULL DEFAULT 'First Semester'
);

CREATE TABLE IF NOT EXISTS CourseLecturers (
    AllocationID INTEGER PRIMARY KEY AUTOINCREMENT,
    CourseID INTEGER NOT NULL REFERENCES Courses(CourseID) ON DELETE CASCADE,
    LecturerID INTEGER NOT NULL REFERENCES Lecturers(LecturerID) ON DELETE CASCADE,
    AcademicSession TEXT NOT NULL DEFAULT '2025/2026',
    Semester TEXT NOT NULL DEFAULT 'First Semester',
    UNIQUE (CourseID, LecturerID, AcademicSession, Semester)
);

CREATE TABLE IF NOT EXISTS CourseRegistrations (
    RegistrationID INTEGER PRIMARY KEY AUTOINCREMENT,
    StudentID INTEGER NOT NULL REFERENCES Students(StudentID) ON DELETE CASCADE,
    CourseID INTEGER NOT NULL REFERENCES Courses(CourseID) ON DELETE CASCADE,
    AcademicSession TEXT NOT NULL DEFAULT '2025/2026',
    Semester TEXT NOT NULL DEFAULT 'First Semester',
    RegisteredAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (StudentID, CourseID, AcademicSession, Semester)
);

CREATE TABLE IF NOT EXISTS AttendanceSessions (
    SessionID INTEGER PRIMARY KEY AUTOINCREMENT,
    CourseID INTEGER NOT NULL REFERENCES Courses(CourseID),
    LecturerID INTEGER NOT NULL REFERENCES Lecturers(LecturerID),
    ClassroomID INTEGER NOT NULL REFERENCES Classrooms(ClassroomID),
    SessionDate DATE NOT NULL,
    StartTime TIME NOT NULL,
    EndTime TIME NOT NULL,
    DurationMinutes INTEGER NOT NULL DEFAULT 30,
    SessionToken TEXT NOT NULL UNIQUE,
    Status TEXT NOT NULL DEFAULT 'Active' CHECK (Status IN ('Active', 'Closed', 'Cancelled')),
    CreatedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    ClosedAt DATETIME NULL
);

CREATE TABLE IF NOT EXISTS AttendanceRecords (
    RecordID INTEGER PRIMARY KEY AUTOINCREMENT,
    SessionID INTEGER NOT NULL REFERENCES AttendanceSessions(SessionID) ON DELETE CASCADE,
    StudentID INTEGER NOT NULL REFERENCES Students(StudentID) ON DELETE CASCADE,
    CourseID INTEGER NOT NULL REFERENCES Courses(CourseID),
    MarkedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    ScanMethod TEXT NOT NULL DEFAULT 'QR_CAMERA' CHECK (ScanMethod IN ('QR_CAMERA', 'MANUAL_TOKEN', 'ADMIN_OVERRIDE', 'LECTURER_MANUAL')),
    Status TEXT NOT NULL DEFAULT 'Present' CHECK (Status IN ('Present', 'Late', 'Excused')),
    IPAddress TEXT NULL,
    UserAgent TEXT NULL,
    UNIQUE (SessionID, StudentID)
);

CREATE TABLE IF NOT EXISTS AuditLogs (
    LogID INTEGER PRIMARY KEY AUTOINCREMENT,
    UserID INTEGER NULL REFERENCES Users(UserID) ON DELETE SET NULL,
    Action TEXT NOT NULL,
    Category TEXT NOT NULL,
    Details TEXT NULL,
    IPAddress TEXT NULL,
    Timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS SystemSettings (
    SettingKey TEXT PRIMARY KEY,
    SettingValue TEXT NOT NULL,
    Description TEXT NULL,
    UpdatedAt DATETIME DEFAULT CURRENT_TIMESTAMP
);
""")

# Seed data if empty
cur.execute("SELECT COUNT(*) FROM Users;")
if cur.fetchone()[0] == 0:
    # Standard bcrypt hash for 'Password123!'
    # $2y$10$tZ2zVqjXp.Y3M7FqA8qHveiEjeJqWjSg78hX1Bv9kLmNoPqRsTuVw
    pass_hash = '$2y$10$tZ2zVqjXp.Y3M7FqA8qHveiEjeJqWjSg78hX1Bv9kLmNoPqRsTuVw'

    # SystemSettings
    cur.executemany("INSERT INTO SystemSettings (SettingKey, SettingValue, Description) VALUES (?, ?, ?)", [
        ('INSTITUTION_NAME', 'Federal Institute of Technology & Applied Sciences', 'Name of the tertiary institution'),
        ('INSTITUTION_CODE', 'FITAS', 'Short institution code / acronym'),
        ('ACADEMIC_SESSION', '2025/2026', 'Current active academic session'),
        ('SEMESTER', 'First Semester', 'Current active academic semester'),
        ('ATTENDANCE_THRESHOLD', '75', 'Minimum percentage attendance required for exam eligibility'),
        ('DEFAULT_SESSION_DURATION', '30', 'Default attendance session validity duration in minutes'),
        ('QR_REFRESH_INTERVAL', '15', 'QR code display auto-refresh interval in seconds')
    ])

    # Departments
    cur.executemany("INSERT INTO Departments (DepartmentCode, DepartmentName, Faculty) VALUES (?, ?, ?)", [
        ('CSC', 'Computer Science', 'School of Applied Science & Technology'),
        ('EEE', 'Electrical & Electronic Engineering', 'School of Engineering'),
        ('STA', 'Statistics & Mathematics', 'School of Applied Science & Technology'),
        ('SLT', 'Science Laboratory Technology', 'School of Pure & Applied Sciences')
    ])

    # Programmes
    cur.executemany("INSERT INTO Programmes (DepartmentID, ProgrammeCode, ProgrammeName, DurationYears) VALUES (?, ?, ?, ?)", [
        (1, 'ND-CSC', 'National Diploma in Computer Science', 2),
        (1, 'HND-CSC', 'Higher National Diploma in Computer Science', 2),
        (2, 'ND-EEE', 'National Diploma in Electrical/Electronics Engineering', 2),
        (3, 'ND-STA', 'National Diploma in Statistics', 2)
    ])

    # Levels
    cur.executemany("INSERT INTO Levels (LevelCode, LevelName) VALUES (?, ?)", [
        ('ND1', 'National Diploma I (ND I)'),
        ('ND2', 'National Diploma II (ND II)'),
        ('HND1', 'Higher National Diploma I (HND I)'),
        ('HND2', 'Higher National Diploma II (HND II)')
    ])

    # Classrooms
    cur.executemany("INSERT INTO Classrooms (RoomCode, RoomName, Capacity, Building) VALUES (?, ?, ?, ?)", [
        ('LAB-1', 'Main Computer Lab 1', 75, 'ICT Complex, Block A'),
        ('LAB-2', 'Advanced Software Lab 2', 60, 'ICT Complex, Block B'),
        ('HALL-A', 'Auditorium Hall A', 250, 'Academic Complex Ground Floor'),
        ('LT-04', 'Lecture Theater 04', 120, 'Science Building Level 2'),
        ('CR-102', 'Classroom 102', 50, 'Engineering Wing 1')
    ])

    # Users
    cur.executemany("INSERT INTO Users (Username, PasswordHash, Email, Role, Status) VALUES (?, ?, ?, ?, ?)", [
        ('admin', pass_hash, 'admin@fitas.edu.ng', 'Admin', 'Active'),
        ('dr.ibrahim', pass_hash, 'a.ibrahim@fitas.edu.ng', 'Lecturer', 'Active'),
        ('engr.adeyemi', pass_hash, 'o.adeyemi@fitas.edu.ng', 'Lecturer', 'Active'),
        ('dr.musa', pass_hash, 'b.musa@fitas.edu.ng', 'Lecturer', 'Active'),
        ('fitas/2024/001', pass_hash, 'chinedu.o@student.fitas.edu.ng', 'Student', 'Active'),
        ('fitas/2024/002', pass_hash, 'amina.b@student.fitas.edu.ng', 'Student', 'Active'),
        ('fitas/2024/003', pass_hash, 'oluwaseun.a@student.fitas.edu.ng', 'Student', 'Active'),
        ('fitas/2024/004', pass_hash, 'fatima.s@student.fitas.edu.ng', 'Student', 'Active'),
        ('fitas/2024/005', pass_hash, 'emeka.n@student.fitas.edu.ng', 'Student', 'Active')
    ])

    # Lecturers
    cur.executemany("INSERT INTO Lecturers (UserID, DepartmentID, StaffID, Title, FirstName, LastName, Phone, OfficeNumber) VALUES (?, ?, ?, ?, ?, ?, ?, ?)", [
        (2, 1, 'FITAS/STF/CSC01', 'Dr.', 'Aliyu', 'Ibrahim', '08031234567', 'ICT Complex Rm 204'),
        (3, 1, 'FITAS/STF/CSC02', 'Engr.', 'Olumide', 'Adeyemi', '08029876543', 'ICT Complex Rm 208'),
        (4, 2, 'FITAS/STF/EEE01', 'Dr.', 'Bello', 'Musa', '08134567890', 'Engineering Wing B-12')
    ])

    # Students
    cur.executemany("INSERT INTO Students (UserID, DepartmentID, ProgrammeID, LevelID, MatricNo, FirstName, LastName, Phone, AcademicSession) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)", [
        (5, 1, 2, 3, 'FITAS/HND/CSC/24/001', 'Chinedu', 'Okonkwo', '08051112233', '2025/2026'),
        (6, 1, 2, 3, 'FITAS/HND/CSC/24/002', 'Amina', 'Bello', '08072223344', '2025/2026'),
        (7, 1, 2, 3, 'FITAS/HND/CSC/24/003', 'Oluwaseun', 'Adebayo', '08093334455', '2025/2026'),
        (8, 1, 2, 3, 'FITAS/HND/CSC/24/004', 'Fatima', 'Sanusi', '08084445566', '2025/2026'),
        (9, 1, 2, 3, 'FITAS/HND/CSC/24/005', 'Emeka', 'Nnamdi', '08065556677', '2025/2026')
    ])

    # Courses
    cur.executemany("INSERT INTO Courses (DepartmentID, LevelID, CourseCode, CourseTitle, CreditUnits, Semester) VALUES (?, ?, ?, ?, ?, ?)", [
        (1, 3, 'COM 311', 'Operating Systems & Architecture', 3, 'First Semester'),
        (1, 3, 'COM 312', 'Database Design & Management (MS SQL)', 3, 'First Semester'),
        (1, 3, 'COM 313', 'Computer Programming Using C++/Java', 4, 'First Semester'),
        (1, 3, 'COM 314', 'Software Engineering Methodologies', 3, 'First Semester'),
        (1, 3, 'GNS 301', 'Communication in English & Research', 2, 'First Semester')
    ])

    # Allocations
    cur.executemany("INSERT INTO CourseLecturers (CourseID, LecturerID, AcademicSession, Semester) VALUES (?, ?, ?, ?)", [
        (1, 1, '2025/2026', 'First Semester'),
        (2, 1, '2025/2026', 'First Semester'),
        (3, 2, '2025/2026', 'First Semester'),
        (4, 2, '2025/2026', 'First Semester')
    ])

    # Registrations
    regs = []
    for s in range(1, 6):
        for c in range(1, 5):
            regs.append((s, c, '2025/2026', 'First Semester'))
    cur.executemany("INSERT INTO CourseRegistrations (StudentID, CourseID, AcademicSession, Semester) VALUES (?, ?, ?, ?)", regs)

    # Sessions
    cur.executemany("INSERT INTO AttendanceSessions (CourseID, LecturerID, ClassroomID, SessionDate, StartTime, EndTime, DurationMinutes, SessionToken, Status, CreatedAt, ClosedAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now', '-7 days'), datetime('now', '-7 days', '+30 minutes'))", [
        (2, 1, 1, '2026-09-10', '09:00:00', '09:30:00', 30, 'SES-COM312-HIST01-SEC982', 'Closed'),
        (2, 1, 1, '2026-09-14', '09:00:00', '09:30:00', 30, 'SES-COM312-HIST02-SEC105', 'Closed')
    ])
    cur.execute("INSERT INTO AttendanceSessions (CourseID, LecturerID, ClassroomID, SessionDate, StartTime, EndTime, DurationMinutes, SessionToken, Status, CreatedAt, ClosedAt) VALUES (2, 1, 1, date('now'), time('now'), time('now', '+60 minutes'), 60, 'SES-COM312-LIVE-ACTIVE-TK8421', 'Active', datetime('now'), NULL)")

    # Attendance Records
    cur.executemany("INSERT INTO AttendanceRecords (SessionID, StudentID, CourseID, MarkedAt, ScanMethod, Status, IPAddress) VALUES (?, ?, ?, datetime('now', '-7 days', '+5 minutes'), 'QR_CAMERA', ?, '192.168.1.101')", [
        (1, 1, 2, 'Present'),
        (1, 2, 2, 'Present'),
        (1, 3, 2, 'Present'),
        (1, 4, 2, 'Present'),
        (1, 5, 2, 'Late')
    ])
    cur.executemany("INSERT INTO AttendanceRecords (SessionID, StudentID, CourseID, MarkedAt, ScanMethod, Status, IPAddress) VALUES (?, ?, ?, datetime('now', '-3 days', '+5 minutes'), 'QR_CAMERA', ?, '192.168.1.101')", [
        (2, 1, 2, 'Present'),
        (2, 2, 2, 'Present'),
        (2, 3, 2, 'Present')
    ])
    cur.executemany("INSERT INTO AttendanceRecords (SessionID, StudentID, CourseID, MarkedAt, ScanMethod, Status, IPAddress) VALUES (?, ?, ?, datetime('now', '-2 minutes'), 'QR_CAMERA', 'Present', '192.168.1.101')", [
        (3, 1, 2),
        (3, 2, 2)
    ])

    # Audit Logs
    cur.executemany("INSERT INTO AuditLogs (UserID, Action, Category, Details, IPAddress) VALUES (?, ?, ?, ?, ?)", [
        (1, 'SYSTEM_INITIALIZATION', 'ADMIN', 'Initialized database schema, academic settings, and security credentials', '127.0.0.1'),
        (2, 'SESSION_CREATED', 'SESSION', 'Created live attendance session for COM 312 in Room LAB-1', '192.168.1.50'),
        (5, 'QR_ATTENDANCE_RECORDED', 'ATTENDANCE', 'Student Chinedu Okonkwo scanned QR code for COM 312', '192.168.1.101'),
        (6, 'QR_ATTENDANCE_RECORDED', 'ATTENDANCE', 'Student Amina Bello scanned QR code for COM 312', '192.168.1.102')
    ])

conn.commit()
conn.close()
print("Portable SQLite database created and seeded successfully.")
