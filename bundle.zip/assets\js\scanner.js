/**
 * QR Attendance System Using MS SQL and Apache
 * In-Browser QR Code Camera Scanner & Processor
 */

class QRScannerHandler {
    constructor(readerElementId, resultCallback) {
        this.readerId = readerElementId;
        this.resultCallback = resultCallback;
        this.html5QrCode = null;
        this.isScanning = false;
        this.lastScannedToken = null;
        this.lastScanTime = 0;
    }

    /**
     * Play synthetic beep sound on successful scan
     */
    playBeep() {
        try {
            const ctx = new (window.AudioContext || window.webkitAudioContext)();
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.type = 'sine';
            osc.frequency.setValueAtTime(880, ctx.currentTime); // A5 note
            gain.gain.setValueAtTime(0.2, ctx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.15);
            osc.connect(gain);
            gain.connect(ctx.destination);
            osc.start();
            osc.stop(ctx.currentTime + 0.15);
        } catch (e) {
            console.log('Audio not supported or blocked');
        }
    }

    /**
     * Start camera scanning using Html5Qrcode
     */
    start() {
        if (typeof Html5Qrcode === 'undefined') {
            console.warn('Html5Qrcode library not loaded.');
            return;
        }

        const config = {
            fps: 10,
            qrbox: { width: 250, height: 250 },
            aspectRatio: 1.0
        };

        this.html5QrCode = new Html5Qrcode(this.readerId);
        
        Html5Qrcode.getCameras().then(cameras => {
            if (cameras && cameras.length) {
                // Prefer back camera on mobile
                const backCam = cameras.find(c => c.label.toLowerCase().includes('back') || c.label.toLowerCase().includes('rear'));
                const selectedCameraId = backCam ? backCam.id : cameras[0].id;

                this.html5QrCode.start(
                    selectedCameraId,
                    config,
                    (decodedText, decodedResult) => {
                        const now = Date.now();
                        // Debounce scanning duplicate within 3 seconds
                        if (decodedText === this.lastScannedToken && (now - this.lastScanTime) < 3000) {
                            return;
                        }
                        this.lastScannedToken = decodedText;
                        this.lastScanTime = now;
                        this.playBeep();
                        if (this.resultCallback) {
                            this.resultCallback(decodedText);
                        }
                    },
                    (errorMessage) => {
                        // Scan parse error (ignore frame misses)
                    }
                ).then(() => {
                    this.isScanning = true;
                }).catch(err => {
                    console.error('Failed to start camera:', err);
                    document.getElementById('scanner-status').innerHTML = `
                        <div class="alert alert-warning">
                            <i class="fas fa-video-slash"></i> Camera access error: ${err.message || 'Permission denied'}. You can type the session token manually below.
                        </div>`;
                });
            } else {
                document.getElementById('scanner-status').innerHTML = `
                    <div class="alert alert-warning">
                        <i class="fas fa-camera"></i> No camera detected on this device. Please use manual token entry.
                    </div>`;
            }
        }).catch(err => {
            console.error('Camera enumeration failed:', err);
        });
    }

    /**
     * Stop scanning
     */
    stop() {
        if (this.html5QrCode && this.isScanning) {
            this.html5QrCode.stop().then(() => {
                this.isScanning = false;
            }).catch(err => console.error('Error stopping scanner:', err));
        }
    }
}
