<?php
/**
 * QR Attendance System Using MS SQL and Apache
 * Lecturer Portal: Instructor Dashboard
 */

require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/includes/functions.php';
require_once dirname(__DIR__) . '/includes/auth_guard.php';

$user = require_role('Lecturer');
$pdo = Database::getConnection();

// Fetch lecturer profile
$stLec = $pdo->prepare("
    SELECT l.LecturerID, l.StaffID, l.Title, l.FirstName, l.LastName, l.Phone, l.OfficeNumber,
           d.DepartmentName, d.DepartmentCode
    FROM Lecturers l
    JOIN Departments d ON l.DepartmentID = d.DepartmentID
    WHERE l.UserID = ?
");
$stLec->execute([$user['user_id']]);
$lecturer = $stLec->fetch();
$lecturerId = (int)$lecturer['LecturerID'];

// Check for active sessions today created by this lecturer
$stActive = $pdo->prepare("
    SELECT s.SessionID, s.SessionDate, s.StartTime, s.EndTime, s.DurationMinutes, s.SessionToken,
           c.CourseCode, c.CourseTitle, cl.RoomCode, cl.Building,
           (SELECT COUNT(*) FROM AttendanceRecords r WHERE r.SessionID = s.SessionID) AS AttendeeCount
    FROM AttendanceSessions s
    JOIN Courses c ON s.CourseID = c.CourseID
    JOIN Classrooms cl ON s.ClassroomID = cl.ClassroomID
    WHERE s.LecturerID = ? AND s.Status = 'Active' AND s.SessionDate = CURRENT_DATE
    ORDER BY s.SessionID DESC
");
$stActive->execute([$lecturerId]);
$activeSessions = $stActive->fetchAll();

// Fetch assigned courses
$stCourses = $pdo->prepare("
    SELECT c.CourseID, c.CourseCode, c.CourseTitle, c.CreditUnits, c.Semester,
           (SELECT COUNT(*) FROM CourseRegistrations cr WHERE cr.CourseID = c.CourseID) AS EnrolledCount,
           (SELECT COUNT(*) FROM AttendanceSessions ses WHERE ses.CourseID = c.CourseID AND ses.LecturerID = ?) AS SessionsCount
    FROM CourseLecturers cl
    JOIN Courses c ON cl.CourseID = c.CourseID
    WHERE cl.LecturerID = ?
    ORDER BY c.CourseCode ASC
");
$stCourses->execute([$lecturerId, $lecturerId]);
$assignedCourses = $stCourses->fetchAll();

// Total stats
$totalSessionsConducted = (int)$pdo->prepare("SELECT COUNT(*) FROM AttendanceSessions WHERE LecturerID = ?")->execute([$lecturerId]) ? $pdo->query("SELECT COUNT(*) FROM AttendanceSessions WHERE LecturerID = {$lecturerId}")->fetchColumn() : 0;
$totalScansReceived = (int)$pdo->query("
    SELECT COUNT(*) FROM AttendanceRecords ar
    JOIN AttendanceSessions s ON ar.SessionID = s.SessionID
    WHERE s.LecturerID = {$lecturerId}
")->fetchColumn();

// Recent 5 Sessions
$stRecent = $pdo->prepare("
    SELECT s.SessionID, s.SessionDate, s.StartTime, s.EndTime, s.Status,
           c.CourseCode, c.CourseTitle, cl.RoomCode,
           (SELECT COUNT(*) FROM AttendanceRecords r WHERE r.SessionID = s.SessionID) AS AttendeeCount
    FROM AttendanceSessions s
    JOIN Courses c ON s.CourseID = c.CourseID
    JOIN Classrooms cl ON s.ClassroomID = cl.ClassroomID
    WHERE s.LecturerID = ?
    ORDER BY s.SessionID DESC
    LIMIT 5
");
$stRecent->execute([$lecturerId]);
$recentSessions = $stRecent->fetchAll();

$pageTitle = 'Lecturer Dashboard';
require_once dirname(__DIR__) . '/includes/header.php';
?>

<!-- Lecturer Welcome Banner -->
<div class="card mb-4" style="background: linear-gradient(135deg, #0f2b48 0%, #1e3a8a 100%); color: #ffffff; border: none;">
    <div class="card-body" style="padding: 1.75rem 2rem;">
        <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 1rem;">
            <div>
                <span class="badge" style="background: rgba(255,255,255,0.2); color: #ffffff; margin-bottom: 0.5rem;">
                    <i class="fas fa-id-badge"></i> <?= htmlspecialchars($lecturer['StaffID']) ?> &bull; <?= htmlspecialchars($lecturer['DepartmentName']) ?>
                </span>
                <h2 style="color: #ffffff; font-size: 1.75rem; margin-bottom: 0.25rem;">
                    <?= htmlspecialchars($lecturer['Title'] . ' ' . $lecturer['FirstName'] . ' ' . $lecturer['LastName']) ?>
                </h2>
                <div style="opacity: 0.85; font-size: 0.9rem;">
                    Instructor Portal &bull; <?= CURRENT_ACADEMIC_SESSION ?> &bull; <?= CURRENT_SEMESTER ?>
                </div>
            </div>
            <div>
                <a href="<?= BASE_URL ?>/lecturer/create_session.php" class="btn btn-accent btn-lg">
                    <i class="fas fa-plus-circle"></i> Launch New QR Session
                </a>
            </div>
        </div>
    </div>
</div>

<!-- Active Live Class Banner if currently open -->
<?php if (!empty($activeSessions)): ?>
    <?php foreach ($activeSessions as $live): ?>
        <div class="card mb-4" style="border: 2px solid #10b981; background: #f0fdf4;">
            <div class="card-body" style="padding: 1.25rem 1.75rem;">
                <div class="d-flex align-items-center justify-between flex-wrap gap-2">
                    <div>
                        <div class="d-flex align-items-center gap-2 mb-1">
                            <div class="pulse-indicator"></div>
                            <h3 style="color: #065f46; font-size: 1.25rem; margin: 0;">
                                Active Live Session: <?= htmlspecialchars($live['CourseCode']) ?> &mdash; <?= htmlspecialchars($live['CourseTitle']) ?>
                            </h3>
                        </div>
                        <div class="text-muted" style="font-size: 0.85rem;">
                            <i class="fas fa-map-marker-alt"></i> Room: <?= htmlspecialchars($live['RoomCode']) ?> &bull; 
                            <i class="fas fa-clock"></i> <?= formatTime($live['StartTime']) ?> - <?= formatTime($live['EndTime']) ?> &bull;
                            <i class="fas fa-users"></i> Attendees: <strong class="text-success"><?= $live['AttendeeCount'] ?></strong> checked in
                        </div>
                    </div>

                    <div class="d-flex gap-2">
                        <a href="<?= BASE_URL ?>/lecturer/active_session.php?session_id=<?= $live['SessionID'] ?>" class="btn btn-success btn-lg">
                            <i class="fas fa-tv"></i> Open Projector View
                        </a>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
<?php endif; ?>

<!-- Stats KPI Grid -->
<div class="stat-grid">
    <div class="stat-card stat-primary">
        <div class="stat-icon-wrapper">
            <i class="fas fa-chalkboard"></i>
        </div>
        <div class="stat-content">
            <div class="stat-value"><?= count($assignedCourses) ?></div>
            <div class="stat-label">Assigned Courses</div>
        </div>
    </div>

    <div class="stat-card stat-success">
        <div class="stat-icon-wrapper">
            <i class="fas fa-qrcode"></i>
        </div>
        <div class="stat-content">
            <div class="stat-value"><?= $totalSessionsConducted ?></div>
            <div class="stat-label">Sessions Conducted</div>
        </div>
    </div>

    <div class="stat-card stat-warning">
        <div class="stat-icon-wrapper">
            <i class="fas fa-clipboard-check"></i>
        </div>
        <div class="stat-content">
            <div class="stat-value"><?= $totalScansReceived ?></div>
            <div class="stat-label">Total Student Scans</div>
        </div>
    </div>

    <div class="stat-card stat-info">
        <div class="stat-icon-wrapper">
            <i class="fas fa-calendar-day"></i>
        </div>
        <div class="stat-content">
            <div class="stat-value"><?= count($activeSessions) ?></div>
            <div class="stat-label">Active Right Now</div>
        </div>
    </div>
</div>

<!-- Assigned Courses Quick Grid -->
<div class="card mb-4">
    <div class="card-header">
        <h3 class="card-title"><i class="fas fa-book text-primary"></i> My Assigned Teaching Courses</h3>
        <a href="<?= BASE_URL ?>/lecturer/courses.php" class="btn btn-outline btn-sm">View Details</a>
    </div>
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>Course Code</th>
                    <th>Course Title</th>
                    <th>Credits</th>
                    <th>Enrolled Students</th>
                    <th>Sessions Held</th>
                    <th class="text-right">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($assignedCourses)): ?>
                    <tr><td colspan="6" class="text-center text-muted">No course allocations assigned for this semester.</td></tr>
                <?php else: ?>
                    <?php foreach ($assignedCourses as $c): ?>
                        <tr>
                            <td><strong style="color: #1e3a8a;"><?= htmlspecialchars($c['CourseCode']) ?></strong></td>
                            <td><?= htmlspecialchars($c['CourseTitle']) ?></td>
                            <td><span class="badge badge-neutral"><?= $c['CreditUnits'] ?> Units</span></td>
                            <td><i class="fas fa-user-graduate text-muted"></i> <?= $c['EnrolledCount'] ?> registered</td>
                            <td><i class="fas fa-history text-muted"></i> <?= $c['SessionsCount'] ?> sessions</td>
                            <td class="text-right">
                                <a href="<?= BASE_URL ?>/lecturer/create_session.php?course_id=<?= $c['CourseID'] ?>" class="btn btn-primary btn-sm">
                                    <i class="fas fa-play"></i> Start Session
                                </a>
                                <a href="<?= BASE_URL ?>/lecturer/reports.php?course_id=<?= $c['CourseID'] ?>" class="btn btn-outline btn-sm">
                                    <i class="fas fa-chart-bar"></i> Report
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Recent Sessions Table -->
<div class="card">
    <div class="card-header">
        <h3 class="card-title"><i class="fas fa-history text-primary"></i> Recent Attendance Sessions</h3>
        <a href="<?= BASE_URL ?>/lecturer/records.php" class="btn btn-outline btn-sm">View All Sessions</a>
    </div>
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Course</th>
                    <th>Room</th>
                    <th>Time Window</th>
                    <th>Attendees</th>
                    <th>Status</th>
                    <th class="text-right">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($recentSessions)): ?>
                    <tr><td colspan="7" class="text-center text-muted">No attendance sessions recorded yet.</td></tr>
                <?php else: ?>
                    <?php foreach ($recentSessions as $ses): ?>
                        <tr>
                            <td><?= formatDate($ses['SessionDate']) ?></td>
                            <td><strong><?= htmlspecialchars($ses['CourseCode']) ?></strong></td>
                            <td><?= htmlspecialchars($ses['RoomCode']) ?></td>
                            <td><?= formatTime($ses['StartTime']) ?> - <?= formatTime($ses['EndTime']) ?></td>
                            <td><strong><?= $ses['AttendeeCount'] ?></strong> students</td>
                            <td>
                                <span class="badge <?= ($ses['Status'] === 'Active') ? 'badge-success' : 'badge-neutral' ?>">
                                    <?= htmlspecialchars($ses['Status']) ?>
                                </span>
                            </td>
                            <td class="text-right">
                                <?php if ($ses['Status'] === 'Active'): ?>
                                    <a href="<?= BASE_URL ?>/lecturer/active_session.php?session_id=<?= $ses['SessionID'] ?>" class="btn btn-success btn-sm">
                                        <i class="fas fa-tv"></i> Live Projector
                                    </a>
                                <?php else: ?>
                                    <a href="<?= BASE_URL ?>/lecturer/active_session.php?session_id=<?= $ses['SessionID'] ?>" class="btn btn-outline btn-sm">
                                        <i class="fas fa-users"></i> View Attendees
                                    </a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once dirname(__DIR__) . '/includes/footer.php'; ?>
