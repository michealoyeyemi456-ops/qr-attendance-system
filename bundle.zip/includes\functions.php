<?php
/**
 * QR Attendance System Using MS SQL and Apache
 * Core Helper Functions & Security Library
 */

if (!defined('APP_INIT')) {
    require_once dirname(__DIR__) . '/config/config.php';
    require_once dirname(__DIR__) . '/config/database.php';
}

/**
 * Sanitize user input string
 */
function sanitize(?string $data): string {
    if ($data === null) return '';
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

/**
 * Generate or get CSRF token
 */
function csrf_token(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Verify submitted CSRF token
 */
function verify_csrf(?string $token): bool {
    if (empty($_SESSION['csrf_token']) || empty($token)) {
        return false;
    }
    return hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * Set a session flash message
 */
function flash(string $key, string $message, string $type = 'info'): void {
    $_SESSION['flash'][$key] = [
        'message' => $message,
        'type' => $type // success, danger, warning, info
    ];
}

/**
 * Get and clear a session flash message
 */
function get_flash(string $key): ?array {
    if (isset($_SESSION['flash'][$key])) {
        $msg = $_SESSION['flash'][$key];
        unset($_SESSION['flash'][$key]);
        return $msg;
    }
    return null;
}

/**
 * Log action into AuditLogs table
 */
function logAudit(?int $userId, string $action, string $category, ?string $details = null): void {
    try {
        $pdo = Database::getConnection();
        $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
        $stmt = $pdo->prepare("INSERT INTO AuditLogs (UserID, Action, Category, Details, IPAddress, Timestamp) VALUES (?, ?, ?, ?, ?, ?)");
        $now = date('Y-m-d H:i:s');
        $stmt->execute([$userId, $action, $category, $details, $ip, $now]);
    } catch (Exception $e) {
        error_log("Failed to log audit: " . $e->getMessage());
    }
}

/**
 * Get system setting value by key
 */
function getSystemSetting(string $key, $default = null) {
    try {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare("SELECT SettingValue FROM SystemSettings WHERE SettingKey = ?");
        $stmt->execute([$key]);
        $val = $stmt->fetchColumn();
        return ($val !== false) ? $val : $default;
    } catch (Exception $e) {
        return $default;
    }
}

/**
 * Calculate Student Attendance Percentage for a Course
 */
function calculateAttendancePercent(int $studentId, int $courseId, ?string $academicSession = null, ?string $semester = null): array {
    $pdo = Database::getConnection();
    $session = $academicSession ?: (defined('CURRENT_ACADEMIC_SESSION') ? CURRENT_ACADEMIC_SESSION : '2025/2026');
    $sem = $semester ?: (defined('CURRENT_SEMESTER') ? CURRENT_SEMESTER : 'First Semester');

    // Total conducted sessions for this course
    $totalQuery = "SELECT COUNT(*) FROM AttendanceSessions 
                   WHERE CourseID = ? AND Status IN ('Active', 'Closed')";
    $stmtTotal = $pdo->prepare($totalQuery);
    $stmtTotal->execute([$courseId]);
    $totalLectures = (int)$stmtTotal->fetchColumn();

    // Attended lectures by this student
    $attendedQuery = "SELECT COUNT(*) FROM AttendanceRecords ar
                      JOIN AttendanceSessions s ON ar.SessionID = s.SessionID
                      WHERE ar.StudentID = ? AND ar.CourseID = ? AND ar.Status IN ('Present', 'Late', 'Excused')";
    $stmtAttended = $pdo->prepare($attendedQuery);
    $stmtAttended->execute([$studentId, $courseId]);
    $attendedLectures = (int)$stmtAttended->fetchColumn();

    $percentage = ($totalLectures > 0) ? round(($attendedLectures / $totalLectures) * 100, 1) : 100.0;

    return [
        'attended' => $attendedLectures,
        'total' => $totalLectures,
        'percentage' => $percentage,
        'eligible' => ($percentage >= ATTENDANCE_THRESHOLD_PERCENT)
    ];
}

/**
 * Generate human readable eligibility status badge
 */
function getEligibilityBadge(float $percentage): string {
    $threshold = (float)getSystemSetting('ATTENDANCE_THRESHOLD', ATTENDANCE_THRESHOLD_PERCENT);
    if ($percentage >= $threshold) {
        return '<span class="badge badge-success"><i class="fas fa-check-circle"></i> Exam Eligible (' . $percentage . '%)</span>';
    } elseif ($percentage >= ($threshold - 15)) {
        return '<span class="badge badge-warning"><i class="fas fa-exclamation-triangle"></i> At Risk (' . $percentage . '%)</span>';
    } else {
        return '<span class="badge badge-danger"><i class="fas fa-times-circle"></i> Ineligible (' . $percentage . '%)</span>';
    }
}

/**
 * Generate Dynamic Secure QR Token
 * Combines Session Token, Session ID, and dynamic timestamp hash
 */
function generateSecureQRToken(int $sessionId, string $baseSessionToken): string {
    $timestamp = time();
    $salt = 'FITAS_SECURE_QR_SALT_2026';
    $signature = hash_hmac('sha256', "{$sessionId}:{$baseSessionToken}:{$timestamp}", $salt);
    // Compact token payload
    $payload = [
        'sid' => $sessionId,
        'stk' => $baseSessionToken,
        'ts' => $timestamp,
        'sig' => substr($signature, 0, 16)
    ];
    return base64_encode(json_encode($payload));
}

/**
 * Decode and verify Secure QR Token
 */
function decodeSecureQRToken(string $rawToken): ?array {
    $decoded = base64_decode($rawToken);
    if (!$decoded) {
        // Check if raw token is the raw base SessionToken itself
        return ['stk' => trim($rawToken), 'sid' => null, 'ts' => null];
    }
    $json = json_decode($decoded, true);
    if (is_array($json) && !empty($json['stk'])) {
        return $json;
    }
    return ['stk' => trim($rawToken), 'sid' => null, 'ts' => null];
}

/**
 * JSON response helper
 */
function jsonResponse(array $data, int $statusCode = 200): void {
    http_response_code($statusCode);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data);
    exit;
}

/**
 * Check if request is an AJAX/JSON request
 */
function isJsonRequest(): bool {
    return (
        (!empty($_SERVER['HTTP_ACCEPT']) && strpos($_SERVER['HTTP_ACCEPT'], 'application/json') !== false) ||
        (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest')
    );
}

/**
 * Format standard Date and Time
 */
function formatDateTime(?string $dateTime): string {
    if (empty($dateTime)) return 'N/A';
    return date('M d, Y - h:i A', strtotime($dateTime));
}

function formatDate(?string $date): string {
    if (empty($date)) return 'N/A';
    return date('M d, Y', strtotime($date));
}

function formatTime(?string $time): string {
    if (empty($time)) return 'N/A';
    return date('h:i A', strtotime($time));
}
