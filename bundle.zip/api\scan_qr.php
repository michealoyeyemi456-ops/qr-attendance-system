<?php
/**
 * QR Attendance System Using MS SQL and Apache
 * API Endpoint: Process & Validate Student QR Code Attendance Scan
 */

require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/includes/functions.php';

header('Content-Type: application/json; charset=utf-8');

// Ensure request is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['success' => false, 'message' => 'Invalid request method. POST required.'], 405);
}

// Ensure Student is authenticated
if (empty($_SESSION['user_id']) || empty($_SESSION['user_role']) || $_SESSION['user_role'] !== 'Student') {
    jsonResponse(['success' => false, 'message' => 'Unauthorized. Only logged-in students can scan attendance.'], 401);
}

// Receive payload
$rawInput = file_get_contents('php://input');
$inputData = json_decode($rawInput, true);

$token = trim($_POST['token'] ?? ($inputData['token'] ?? ''));
$scanMethod = trim($_POST['scan_method'] ?? ($inputData['scan_method'] ?? 'QR_CAMERA'));

if (empty($token)) {
    jsonResponse(['success' => false, 'message' => 'QR Code token payload cannot be empty.'], 400);
}

try {
    $pdo = Database::getConnection();
    $userId = (int)$_SESSION['user_id'];

    // 1. Fetch Student Profile
    $stStudent = $pdo->prepare("SELECT StudentID, MatricNo, FirstName, LastName, DepartmentID FROM Students WHERE UserID = ?");
    $stStudent->execute([$userId]);
    $student = $stStudent->fetch();

    if (!$student) {
        jsonResponse(['success' => false, 'message' => 'Student record profile not found.'], 404);
    }
    $studentId = (int)$student['StudentID'];

    // 2. Decode Token
    $tokenInfo = decodeSecureQRToken($token);
    $baseToken = $tokenInfo['stk'];

    // 3. Look up Attendance Session
    $stSession = $pdo->prepare("
        SELECT s.SessionID, s.CourseID, s.LecturerID, s.ClassroomID, s.SessionDate, s.StartTime, s.EndTime, 
               s.DurationMinutes, s.Status, c.CourseCode, c.CourseTitle, cl.RoomCode,
               l.Title AS LecTitle, l.FirstName AS LecFirst, l.LastName AS LecLast
        FROM AttendanceSessions s
        JOIN Courses c ON s.CourseID = c.CourseID
        JOIN Classrooms cl ON s.ClassroomID = cl.ClassroomID
        JOIN Lecturers l ON s.LecturerID = l.LecturerID
        WHERE s.SessionToken = ?
    ");
    $stSession->execute([$baseToken]);
    $session = $stSession->fetch();

    if (!$session) {
        jsonResponse(['success' => false, 'message' => 'Invalid or unrecognized QR attendance token.'], 404);
    }

    $sessionId = (int)$session['SessionID'];
    $courseId = (int)$session['CourseID'];

    // 4. Verify Session Status & Time Window
    if ($session['Status'] !== 'Active') {
        jsonResponse([
            'success' => false, 
            'message' => "Attendance session is currently {$session['Status']}. New scans are not accepted."
        ], 403);
    }

    $today = date('Y-m-d');
    $nowTime = date('H:i:s');

    // Check if session date matches today
    if ($session['SessionDate'] !== $today) {
        jsonResponse(['success' => false, 'message' => 'This attendance session was scheduled for a different date.'], 403);
    }

    // Check if session has ended
    if ($nowTime > $session['EndTime']) {
        // Auto mark session closed if past end time
        $pdo->prepare("UPDATE AttendanceSessions SET Status = 'Closed', ClosedAt = CURRENT_TIMESTAMP WHERE SessionID = ?")->execute([$sessionId]);
        jsonResponse(['success' => false, 'message' => 'Session time has expired. Attendance window is closed.'], 403);
    }

    // 5. Verify Student Course Registration
    $stReg = $pdo->prepare("SELECT RegistrationID FROM CourseRegistrations WHERE StudentID = ? AND CourseID = ?");
    $stReg->execute([$studentId, $courseId]);
    if (!$stReg->fetch()) {
        jsonResponse([
            'success' => false, 
            'message' => "You are not officially registered for {$session['CourseCode']} ({$session['CourseTitle']}) in this semester."
        ], 403);
    }

    // 6. Check for Duplicate Attendance Scan
    $stDup = $pdo->prepare("SELECT RecordID, MarkedAt, Status FROM AttendanceRecords WHERE SessionID = ? AND StudentID = ?");
    $stDup->execute([$sessionId, $studentId]);
    $existing = $stDup->fetch();

    if ($existing) {
        jsonResponse([
            'success' => false,
            'is_duplicate' => true,
            'message' => "You have already recorded your attendance for {$session['CourseCode']} at " . date('h:i A', strtotime($existing['MarkedAt'])),
            'existing_status' => $existing['Status'],
            'marked_at' => $existing['MarkedAt']
        ], 409);
    }

    // 7. Calculate Status (Present vs Late)
    // If student checked in after first 20 minutes of session duration, mark as Late
    $sessionStartTs = strtotime("{$session['SessionDate']} {$session['StartTime']}");
    $minutesElapsed = max(0, (time() - $sessionStartTs) / 60);
    $attendanceStatus = ($minutesElapsed > 20) ? 'Late' : 'Present';

    // 8. Commit Attendance Record
    $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
    $ua = substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 255);

    $stInsert = $pdo->prepare("
        INSERT INTO AttendanceRecords (SessionID, StudentID, CourseID, MarkedAt, ScanMethod, Status, IPAddress, UserAgent)
        VALUES (?, ?, ?, CURRENT_TIMESTAMP, ?, ?, ?, ?)
    ");
    $stInsert->execute([$sessionId, $studentId, $courseId, $scanMethod, $attendanceStatus, $ip, $ua]);

    // 9. Audit Trail
    $lecturerFullName = "{$session['LecTitle']} {$session['LecFirst']} {$session['LecLast']}";
    logAudit($userId, 'ATTENDANCE_RECORDED', 'ATTENDANCE', "Student {$student['MatricNo']} marked {$attendanceStatus} for {$session['CourseCode']} via {$scanMethod}");

    jsonResponse([
        'success' => true,
        'message' => 'Attendance verified and recorded successfully!',
        'data' => [
            'course_code' => $session['CourseCode'],
            'course_title' => $session['CourseTitle'],
            'lecturer' => $lecturerFullName,
            'classroom' => $session['RoomCode'],
            'status' => $attendanceStatus,
            'marked_at' => date('M d, Y h:i:s A'),
            'matric_no' => $student['MatricNo']
        ]
    ], 200);

} catch (Exception $e) {
    error_log("Scan QR Exception: " . $e->getMessage());
    jsonResponse(['success' => false, 'message' => 'Database transaction failed: ' . $e->getMessage()], 500);
}
