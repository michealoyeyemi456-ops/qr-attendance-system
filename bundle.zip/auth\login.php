<?php
/**
 * QR Attendance System Using MS SQL and Apache
 * Unified Multi-Role Authentication Portal
 */

require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/includes/functions.php';

// Redirect if already authenticated
if (!empty($_SESSION['user_id']) && !empty($_SESSION['user_role'])) {
    switch ($_SESSION['user_role']) {
        case 'Admin': header('Location: ' . BASE_URL . '/admin/index.php'); exit;
        case 'Lecturer': header('Location: ' . BASE_URL . '/lecturer/index.php'); exit;
        case 'Student': header('Location: ' . BASE_URL . '/student/index.php'); exit;
    }
}

$error = null;

// Handle Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $submittedCsrf = $_POST['csrf_token'] ?? '';

    if (!verify_csrf($submittedCsrf)) {
        $error = 'Security session expired. Please refresh and try again.';
    } elseif (empty($username) || empty($password)) {
        $error = 'Please provide both username/matric number and password.';
    } else {
        try {
            $pdo = Database::getConnection();
            $stmt = $pdo->prepare("SELECT UserID, Username, PasswordHash, Email, Role, Status FROM Users WHERE LOWER(Username) = LOWER(?) OR LOWER(Email) = LOWER(?)");
            $stmt->execute([$username, $username]);
            $user = $stmt->fetch();

            if ($user && password_verify($password, $user['PasswordHash'])) {
                if ($user['Status'] !== 'Active') {
                    $error = "Account is {$user['Status']}. Please contact the institution ICT administrator.";
                    logAudit($user['UserID'], 'LOGIN_BLOCKED', 'AUTH', "Attempted login to inactive/suspended account: {$user['Username']}");
                } else {
                    // Fetch role profile details
                    $profileId = null;
                    $fullName = $user['Username'];

                    if ($user['Role'] === 'Lecturer') {
                        $st = $pdo->prepare("SELECT LecturerID, Title, FirstName, LastName FROM Lecturers WHERE UserID = ?");
                        $st->execute([$user['UserID']]);
                        $lec = $st->fetch();
                        if ($lec) {
                            $profileId = $lec['LecturerID'];
                            $fullName = "{$lec['Title']} {$lec['FirstName']} {$lec['LastName']}";
                        }
                    } elseif ($user['Role'] === 'Student') {
                        $st = $pdo->prepare("SELECT StudentID, MatricNo, FirstName, LastName FROM Students WHERE UserID = ?");
                        $st->execute([$user['UserID']]);
                        $stu = $st->fetch();
                        if ($stu) {
                            $profileId = $stu['StudentID'];
                            $fullName = "{$stu['FirstName']} {$stu['LastName']} ({$stu['MatricNo']})";
                        }
                    } else {
                        $fullName = 'System Administrator';
                    }

                    // Regenerate session ID for security
                    session_regenerate_id(true);
                    $_SESSION['user_id'] = $user['UserID'];
                    $_SESSION['username'] = $user['Username'];
                    $_SESSION['user_email'] = $user['Email'];
                    $_SESSION['user_role'] = $user['Role'];
                    $_SESSION['user_status'] = $user['Status'];
                    $_SESSION['profile_id'] = $profileId;
                    $_SESSION['user_fullname'] = $fullName;

                    // Update LastLogin
                    $upd = $pdo->prepare("UPDATE Users SET LastLogin = CURRENT_TIMESTAMP WHERE UserID = ?");
                    $upd->execute([$user['UserID']]);

                    // Audit Log
                    logAudit($user['UserID'], 'USER_LOGIN_SUCCESS', 'AUTH', "Logged in successfully as {$user['Role']}");

                    flash('success', "Welcome back, {$fullName}!", 'success');

                    // Role-based redirect
                    switch ($user['Role']) {
                        case 'Admin': header('Location: ' . BASE_URL . '/admin/index.php'); exit;
                        case 'Lecturer': header('Location: ' . BASE_URL . '/lecturer/index.php'); exit;
                        case 'Student': header('Location: ' . BASE_URL . '/student/index.php'); exit;
                    }
                }
            } else {
                $error = 'Invalid credentials. Please verify your username and password.';
                logAudit(null, 'LOGIN_FAILED', 'AUTH', "Failed login attempt for username: {$username}");
            }
        } catch (Exception $e) {
            $error = 'Database authentication error: ' . $e->getMessage();
        }
    }
}

$flashAuth = get_flash('auth_error');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign In | <?= APP_NAME ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
    <style>
        body {
            background: linear-gradient(135deg, #091e3a 0%, #172554 50%, #0f172a 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 1.5rem;
        }
        .login-card {
            width: 100%;
            max-width: 460px;
            background: #ffffff;
            border-radius: var(--radius-xl);
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.45);
            padding: 2.5rem 2rem;
            position: relative;
        }
        .login-logo {
            width: 64px;
            height: 64px;
            margin: 0 auto 1.25rem;
            display: block;
        }
        .demo-pill {
            cursor: pointer;
            padding: 0.35rem 0.65rem;
            background: #f1f5f9;
            border-radius: 6px;
            font-size: 0.75rem;
            font-weight: 600;
            color: #334155;
            border: 1px solid #e2e8f0;
            transition: var(--transition);
        }
        .demo-pill:hover {
            background: #e2e8f0;
            border-color: #cbd5e1;
        }
    </style>
</head>
<body>

<div class="login-card">
    <img src="<?= BASE_URL ?>/assets/images/logo.svg" alt="Institution Seal" class="login-logo">
    <div class="text-center mb-4">
        <h2 style="font-size: 1.45rem; font-weight: 800; color: #0f172a; margin-bottom: 0.25rem;"><?= APP_NAME ?></h2>
        <div style="font-size: 0.8rem; color: #d97706; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em;"><?= APP_SUBTITLE ?></div>
        <p class="text-muted" style="font-size: 0.825rem; margin-top: 0.4rem;"><?= INSTITUTION_NAME ?></p>
    </div>

    <?php if ($flashAuth): ?>
        <div class="alert alert-warning"><i class="fas fa-exclamation-triangle"></i> <?= htmlspecialchars($flashAuth['message']) ?></div>
    <?php endif; ?>

    <?php if ($error): ?>
        <div class="alert alert-danger"><i class="fas fa-times-circle"></i> <?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form action="<?= BASE_URL ?>/auth/login.php" method="POST" autocomplete="off">
        <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">

        <div class="form-group">
            <label class="form-label" for="username"><i class="fas fa-user text-muted"></i> Username / Staff ID / Matric No</label>
            <input type="text" id="username" name="username" class="form-control" placeholder="e.g. admin or dr.ibrahim or fitas/2024/001" required autofocus>
        </div>

        <div class="form-group">
            <label class="form-label" for="password"><i class="fas fa-lock text-muted"></i> Password</label>
            <input type="password" id="password" name="password" class="form-control" placeholder="••••••••••••" required>
        </div>

        <button type="submit" class="btn btn-primary btn-block btn-lg mt-3">
            <i class="fas fa-sign-in-alt"></i> Sign In to Portal
        </button>
    </form>

    <!-- Quick Demo Logins Helper -->
    <div style="margin-top: 1.75rem; padding-top: 1.25rem; border-top: 1px solid #e2e8f0;">
        <div style="font-size: 0.75rem; font-weight: 700; text-transform: uppercase; color: #64748b; margin-bottom: 0.65rem; text-align: center;">
            <i class="fas fa-bolt text-warning"></i> Quick Demo Logins (Click to autofill)
        </div>
        <div style="display: flex; gap: 0.4rem; justify-content: center; flex-wrap: wrap;">
            <button type="button" class="demo-pill" onclick="fillDemo('admin', 'Password123!')">
                <i class="fas fa-user-shield text-danger"></i> Admin
            </button>
            <button type="button" class="demo-pill" onclick="fillDemo('dr.ibrahim', 'Password123!')">
                <i class="fas fa-chalkboard-teacher text-primary"></i> Lecturer
            </button>
            <button type="button" class="demo-pill" onclick="fillDemo('fitas/2024/001', 'Password123!')">
                <i class="fas fa-user-graduate text-success"></i> Student
            </button>
        </div>
        <div class="text-center mt-2" style="font-size: 0.725rem; color: #94a3b8;">
            Universal Seed Password: <code>Password123!</code>
        </div>
    </div>
</div>

<script>
function fillDemo(username, password) {
    document.getElementById('username').value = username;
    document.getElementById('password').value = password;
}
</script>

</body>
</html>
