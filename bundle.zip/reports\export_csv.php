<?php
/**
 * QR Attendance System Using MS SQL and Apache
 * Reports & Export Module: CSV Export Engine
 */

require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/includes/functions.php';
require_once dirname(__DIR__) . '/includes/auth_guard.php';

// Ensure user is at least a Lecturer or Admin
$user = require_role(['Admin', 'Lecturer']);
$pdo = Database::getConnection();

$sessionId = isset($_GET['session_id']) ? (int)$_GET['session_id'] : 0;
$courseId = isset($_GET['course_id']) ? (int)$_GET['course_id'] : 0;
$exportType = trim($_GET['type'] ?? '');

// 1. Export Specific Session Attendees
if ($sessionId > 0) {
    // Fetch session details
    $stSes = $pdo->prepare("
        SELECT s.SessionID, s.SessionDate, s.StartTime, s.EndTime, c.CourseCode, c.CourseTitle, cl.RoomCode,
               l.Title AS LecTitle, l.FirstName AS LecFirst, l.LastName AS LecLast
        FROM AttendanceSessions s
        JOIN Courses c ON s.CourseID = c.CourseID
        JOIN Classrooms cl ON s.ClassroomID = cl.ClassroomID
        JOIN Lecturers l ON s.LecturerID = l.LecturerID
        WHERE s.SessionID = ?
    ");
    $stSes->execute([$sessionId]);
    $ses = $stSes->fetch();

    if (!$ses) {
        die('Session not found.');
    }

    $filename = "Attendance_{$ses['CourseCode']}_{$ses['SessionDate']}_Session{$sessionId}.csv";
    header('Content-Type: text/csv; charset=utf-8');
    header("Content-Disposition: attachment; filename=\"{$filename}\"");

    $output = fopen('php://output', 'w');

    // Header info rows
    fputcsv($output, [INSTITUTION_NAME]);
    fputcsv($output, ["Course: {$ses['CourseCode']} - {$ses['CourseTitle']}"]);
    fputcsv($output, ["Lecturer: {$ses['LecTitle']} {$ses['LecFirst']} {$ses['LecLast']}"]);
    fputcsv($output, ["Date: {$ses['SessionDate']} | Time: {$ses['StartTime']} - {$ses['EndTime']} | Venue: {$ses['RoomCode']}"]);
    fputcsv($output, []); // blank line
    fputcsv($output, ['S/N', 'Matriculation No', 'Student Full Name', 'Department', 'Attendance Status', 'Scan Method', 'Marked Timestamp', 'IP Address']);

    $stRecs = $pdo->prepare("
        SELECT r.RecordID, r.MarkedAt, r.ScanMethod, r.Status, r.IPAddress,
               s.MatricNo, s.FirstName, s.LastName, d.DepartmentCode
        FROM AttendanceRecords r
        JOIN Students s ON r.StudentID = s.StudentID
        JOIN Departments d ON s.DepartmentID = d.DepartmentID
        WHERE r.SessionID = ?
        ORDER BY r.MarkedAt ASC
    ");
    $stRecs->execute([$sessionId]);
    $records = $stRecs->fetchAll();

    $sn = 1;
    foreach ($records as $r) {
        fputcsv($output, [
            $sn++,
            $r['MatricNo'],
            "{$r['FirstName']} {$r['LastName']}",
            $r['DepartmentCode'],
            $r['Status'],
            $r['ScanMethod'],
            $r['MarkedAt'],
            $r['IPAddress']
        ]);
    }
    fclose($output);
    exit;
}

// 2. Export Course Overall Attendance & Eligibility Report
if ($courseId > 0) {
    $stCourse = $pdo->prepare("SELECT CourseID, CourseCode, CourseTitle FROM Courses WHERE CourseID = ?");
    $stCourse->execute([$courseId]);
    $c = $stCourse->fetch();

    if (!$c) {
        die('Course not found.');
    }

    $filename = "CourseReport_{$c['CourseCode']}_" . date('Y-m-d') . ".csv";
    header('Content-Type: text/csv; charset=utf-8');
    header("Content-Disposition: attachment; filename=\"{$filename}\"");

    $output = fopen('php://output', 'w');
    fputcsv($output, [INSTITUTION_NAME]);
    fputcsv($output, ["Course Attendance & Exam Eligibility Report: {$c['CourseCode']} - {$c['CourseTitle']}"]);
    fputcsv($output, ["Generated on: " . date('Y-m-d H:i:s') . " | Eligibility Threshold: " . ATTENDANCE_THRESHOLD_PERCENT . "%"]);
    fputcsv($output, []);
    fputcsv($output, ['S/N', 'Matriculation No', 'Student Full Name', 'Department', 'Level', 'Lectures Held', 'Lectures Attended', 'Attendance %', 'Exam Eligibility Status']);

    $stStudents = $pdo->prepare("
        SELECT s.StudentID, s.MatricNo, s.FirstName, s.LastName, d.DepartmentCode, lev.LevelCode
        FROM CourseRegistrations cr
        JOIN Students s ON cr.StudentID = s.StudentID
        JOIN Departments d ON s.DepartmentID = d.DepartmentID
        JOIN Levels lev ON s.LevelID = lev.LevelID
        WHERE cr.CourseID = ?
        ORDER BY s.MatricNo ASC
    ");
    $stStudents->execute([$courseId]);
    $students = $stStudents->fetchAll();

    $sn = 1;
    foreach ($students as $stu) {
        $att = calculateAttendancePercent((int)$stu['StudentID'], $courseId);
        fputcsv($output, [
            $sn++,
            $stu['MatricNo'],
            "{$stu['FirstName']} {$stu['LastName']}",
            $stu['DepartmentCode'],
            $stu['LevelCode'],
            $att['total'],
            $att['attended'],
            "{$att['percentage']}%",
            $att['eligible'] ? 'ELIGIBLE' : 'INELIGIBLE'
        ]);
    }
    fclose($output);
    exit;
}

// 3. Export Master Records (Admin Only)
if ($exportType === 'all' && $user['role'] === 'Admin') {
    $filename = "Master_Attendance_Ledger_" . date('Y-m-d') . ".csv";
    header('Content-Type: text/csv; charset=utf-8');
    header("Content-Disposition: attachment; filename=\"{$filename}\"");

    $output = fopen('php://output', 'w');
    fputcsv($output, [INSTITUTION_NAME, "MASTER ATTENDANCE LEDGER"]);
    fputcsv($output, ['Record ID', 'Matric No', 'Student Name', 'Course Code', 'Course Title', 'Room', 'Status', 'Scan Method', 'Marked At', 'IP Address']);

    $recs = $pdo->query("
        SELECT r.RecordID, r.MarkedAt, r.ScanMethod, r.Status, r.IPAddress,
               c.CourseCode, c.CourseTitle, cl.RoomCode,
               stu.MatricNo, stu.FirstName, stu.LastName
        FROM AttendanceRecords r
        JOIN AttendanceSessions s ON r.SessionID = s.SessionID
        JOIN Courses c ON r.CourseID = c.CourseID
        JOIN Students stu ON r.StudentID = stu.StudentID
        JOIN Classrooms cl ON s.ClassroomID = cl.ClassroomID
        ORDER BY r.RecordID DESC
    ")->fetchAll();

    foreach ($recs as $r) {
        fputcsv($output, [
            $r['RecordID'],
            $r['MatricNo'],
            "{$r['FirstName']} {$r['LastName']}",
            $r['CourseCode'],
            $r['CourseTitle'],
            $r['RoomCode'],
            $r['Status'],
            $r['ScanMethod'],
            $r['MarkedAt'],
            $r['IPAddress']
        ]);
    }
    fclose($output);
    exit;
}

die('Invalid export parameters.');
