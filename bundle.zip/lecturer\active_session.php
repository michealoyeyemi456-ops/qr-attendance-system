<?php
/**
 * QR Attendance System Using MS SQL and Apache
 * Lecturer Portal: Live Attendance Session Projector & Monitor
 */

require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/includes/functions.php';
require_once dirname(__DIR__) . '/includes/auth_guard.php';

$user = require_role('Lecturer');
$pdo = Database::getConnection();

$sessionId = isset($_GET['session_id']) ? (int)$_GET['session_id'] : 0;

if ($sessionId <= 0) {
    flash('danger', 'Invalid session ID specified.', 'danger');
    header('Location: ' . BASE_URL . '/lecturer/index.php');
    exit;
}

// Fetch session info
$st = $pdo->prepare("
    SELECT s.SessionID, s.CourseID, s.LecturerID, s.ClassroomID, s.SessionDate, s.StartTime, s.EndTime,
           s.DurationMinutes, s.SessionToken, s.Status, s.CreatedAt, s.ClosedAt,
           c.CourseCode, c.CourseTitle, c.CreditUnits,
           cl.RoomCode, cl.RoomName, cl.Building, cl.Capacity,
           l.Title AS LecTitle, l.FirstName AS LecFirst, l.LastName AS LecLast
    FROM AttendanceSessions s
    JOIN Courses c ON s.CourseID = c.CourseID
    JOIN Classrooms cl ON s.ClassroomID = cl.ClassroomID
    JOIN Lecturers l ON s.LecturerID = l.LecturerID
    WHERE s.SessionID = ?
");
$st->execute([$sessionId]);
$session = $st->fetch();

if (!$session) {
    flash('danger', 'Attendance session not found.', 'danger');
    header('Location: ' . BASE_URL . '/lecturer/index.php');
    exit;
}

// Handle manual "End Session Early"
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'close_session') {
    if (verify_csrf($_POST['csrf_token'] ?? '')) {
        $pdo->prepare("UPDATE AttendanceSessions SET Status = 'Closed', ClosedAt = CURRENT_TIMESTAMP WHERE SessionID = ?")->execute([$sessionId]);
        logAudit($user['user_id'], 'SESSION_CLOSED_MANUALLY', 'SESSION', "Lecturer closed session #{$sessionId} early for {$session['CourseCode']}");
        flash('success', 'Attendance session has been closed successfully. No further scans will be accepted.', 'info');
        header("Location: " . BASE_URL . "/lecturer/active_session.php?session_id={$sessionId}");
        exit;
    }
}

// Fetch current attendees count
$stCount = $pdo->prepare("SELECT COUNT(*) FROM AttendanceRecords WHERE SessionID = ?");
$stCount->execute([$sessionId]);
$currentCount = (int)$stCount->fetchColumn();

// Fetch registered students count for course
$stRegCount = $pdo->prepare("SELECT COUNT(*) FROM CourseRegistrations WHERE CourseID = ?");
$stRegCount->execute([$session['CourseID']]);
$registeredTotal = (int)$stRegCount->fetchColumn();

$pageTitle = "Live Session - " . $session['CourseCode'];
require_once dirname(__DIR__) . '/includes/header.php';
?>

<div class="page-header">
    <div>
        <h1 class="page-title">
            <i class="fas fa-tv text-primary"></i> Live Attendance Projector
        </h1>
        <div class="page-subtitle">
            <?= htmlspecialchars($session['CourseCode']) ?> &bull; <?= htmlspecialchars($session['CourseTitle']) ?> &bull; Room <?= htmlspecialchars($session['RoomCode']) ?>
        </div>
    </div>
    <div class="d-flex gap-2 flex-wrap">
        <button id="btn-fullscreen" class="btn btn-outline" title="Toggle Fullscreen for Projector">
            <i class="fas fa-expand"></i> Fullscreen Projector
        </button>
        <button onclick="window.print()" class="btn btn-outline">
            <i class="fas fa-print"></i> Print Sheet
        </button>
        <a href="<?= BASE_URL ?>/reports/export_csv.php?session_id=<?= $session['SessionID'] ?>" class="btn btn-outline">
            <i class="fas fa-file-csv text-success"></i> Export CSV
        </a>
        <?php if ($session['Status'] === 'Active'): ?>
            <form method="POST" action="<?= BASE_URL ?>/lecturer/active_session.php?session_id=<?= $sessionId ?>" style="display:inline;">
                <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                <input type="hidden" name="action" value="close_session">
                <button type="submit" class="btn btn-danger" data-confirm="Are you sure you want to stop attendance now? Students will no longer be able to scan.">
                    <i class="fas fa-stop-circle"></i> End Session Early
                </button>
            </form>
        <?php endif; ?>
    </div>
</div>

<!-- Dedicated Projector Screen Container -->
<div id="projector-screen" class="projector-container">
    <div class="projector-header">
        <div class="projector-course-code"><?= htmlspecialchars($session['CourseCode']) ?></div>
        <div class="projector-course-title"><?= htmlspecialchars($session['CourseTitle']) ?></div>
        <div style="font-size: 0.95rem; opacity: 0.85; margin-top: 0.25rem;">
            <i class="fas fa-map-marker-alt"></i> <?= htmlspecialchars($session['RoomCode']) ?> (<?= htmlspecialchars($session['RoomName']) ?>) &bull; 
            <i class="fas fa-user-tie"></i> <?= htmlspecialchars($session['LecTitle'] . ' ' . $session['LecFirst'] . ' ' . $session['LecLast']) ?>
        </div>
    </div>

    <!-- Center QR Display -->
    <div class="projector-qr-wrapper">
        <img src="<?= BASE_URL ?>/qr/generate.php?data=<?= urlencode($session['SessionToken']) ?>&size=320" 
             alt="Class Attendance QR Code" 
             id="projector-qr-image">
    </div>

    <div>
        <div class="projector-timer-badge">
            <div class="pulse-indicator"></div>
            <span id="countdown-timer">CALCULATING REMAINING TIME...</span>
        </div>
    </div>

    <!-- Manual Token & Status Banner -->
    <div style="margin-top: 1.5rem; display: flex; justify-content: center; gap: 1rem; flex-wrap: wrap;">
        <div style="background: rgba(255,255,255,0.1); padding: 0.5rem 1.25rem; border-radius: var(--radius-md); border: 1px solid rgba(255,255,255,0.15); font-size: 0.85rem;">
            Manual Session Token: <strong style="color: #fbbf24; letter-spacing: 0.05em;"><?= htmlspecialchars($session['SessionToken']) ?></strong>
            <button class="btn btn-sm btn-outline" style="color:#ffffff; margin-left: 0.5rem; padding: 0.2rem 0.5rem;" onclick="copyToClipboard('<?= htmlspecialchars($session['SessionToken']) ?>', this)">
                <i class="fas fa-copy"></i>
            </button>
        </div>
        <div style="background: rgba(255,255,255,0.1); padding: 0.5rem 1.25rem; border-radius: var(--radius-md); border: 1px solid rgba(255,255,255,0.15); font-size: 0.85rem;">
            Status: <span class="badge <?= ($session['Status'] === 'Active') ? 'badge-success' : 'badge-neutral' ?>"><?= $session['Status'] ?></span>
        </div>
    </div>
</div>

<!-- Live Attendance Monitoring Card -->
<div class="card">
    <div class="card-header">
        <div class="d-flex align-items-center gap-2">
            <h3 class="card-title"><i class="fas fa-users text-primary"></i> Real-Time Attendee Roster</h3>
            <span class="badge badge-success" style="font-size: 0.85rem; padding: 0.35rem 0.75rem;">
                <span id="attendee-count"><?= $currentCount ?></span> / <?= $registeredTotal ?> Students Present
            </span>
        </div>
        <div class="text-muted" style="font-size: 0.8rem;">
            <i class="fas fa-sync-alt fa-spin"></i> Live auto-refreshing every 3.5 seconds
        </div>
    </div>
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th style="width: 50px;">#</th>
                    <th>Matriculation No</th>
                    <th>Student Name</th>
                    <th>Attendance Status</th>
                    <th>Scan Timestamp</th>
                </tr>
            </thead>
            <tbody id="live-attendee-list">
                <tr>
                    <td colspan="5" class="text-center text-muted" style="padding: 2rem;">
                        <i class="fas fa-spinner fa-spin"></i> Synchronizing attendance data...
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<script src="<?= BASE_URL ?>/assets/js/session_live.js"></script>
<script>
document.addEventListener('DOMContentLoaded', () => {
    const monitor = new LiveSessionMonitor({
        sessionId: <?= (int)$session['SessionID'] ?>,
        apiUrl: '<?= BASE_URL ?>/api/session_live.php',
        endTime: '<?= $session['EndTime'] ?>',
        timerElementId: 'countdown-timer',
        counterElementId: 'attendee-count',
        attendeeTableId: 'live-attendee-list',
        pollInterval: 3500
    });
    monitor.init();
});
</script>

<?php require_once dirname(__DIR__) . '/includes/footer.php'; ?>
