/**
 * QR Attendance System Using MS SQL and Apache
 * Live Attendance Session Monitor & Projector Mode Controller
 */

class LiveSessionMonitor {
    constructor(config) {
        this.sessionId = config.sessionId;
        this.apiUrl = config.apiUrl;
        this.endTimeString = config.endTime; // e.g. "14:30:00"
        this.timerElement = document.getElementById(config.timerElementId || 'countdown-timer');
        this.counterElement = document.getElementById(config.counterElementId || 'attendee-count');
        this.attendeeTable = document.getElementById(config.attendeeTableId || 'live-attendee-list');
        this.pollIntervalMs = config.pollInterval || 3500;
        this.timerInterval = null;
        this.pollInterval = null;
    }

    init() {
        this.startCountdown();
        this.startPolling();
        this.setupFullscreen();
    }

    startCountdown() {
        if (!this.timerElement) return;

        const updateTimer = () => {
            const now = new Date();
            // Parse end time on today's date
            const parts = this.endTimeString.split(':');
            const end = new Date();
            end.setHours(parseInt(parts[0], 10), parseInt(parts[1], 10), parseInt(parts[2] || 0, 10), 0);

            const diff = end - now;
            if (diff <= 0) {
                this.timerElement.innerHTML = '<span class="text-danger font-bold"><i class="fas fa-clock"></i> SESSION EXPIRED</span>';
                clearInterval(this.timerInterval);
                return;
            }

            const minutes = Math.floor(diff / 60000);
            const seconds = Math.floor((diff % 60000) / 1000);
            const formatted = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
            this.timerElement.innerHTML = `<i class="fas fa-stopwatch"></i> ${formatted} REMAINING`;
        };

        updateTimer();
        this.timerInterval = setInterval(updateTimer, 1000);
    }

    startPolling() {
        const fetchUpdates = () => {
            fetch(`${this.apiUrl}?session_id=${this.sessionId}`)
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        // Update attendee count
                        if (this.counterElement) {
                            this.counterElement.innerText = data.total_attendees;
                        }

                        // Update attendee list table
                        if (this.attendeeTable && data.attendees) {
                            if (data.attendees.length === 0) {
                                this.attendeeTable.innerHTML = `
                                    <tr>
                                        <td colspan="4" class="text-center text-muted" style="padding: 2rem;">
                                            <i class="fas fa-qrcode fa-2x mb-2" style="display:block; opacity:0.4;"></i>
                                            Waiting for students to scan the QR code...
                                        </td>
                                    </tr>`;
                            } else {
                                let html = '';
                                data.attendees.forEach((att, idx) => {
                                    const badgeClass = att.status === 'Present' ? 'badge-success' : 'badge-warning';
                                    html += `
                                        <tr>
                                            <td><strong>${idx + 1}</strong></td>
                                            <td><strong>${att.matric_no}</strong></td>
                                            <td>${att.student_name}</td>
                                            <td><span class="badge ${badgeClass}">${att.status}</span></td>
                                            <td>${att.marked_at}</td>
                                        </tr>`;
                                });
                                this.attendeeTable.innerHTML = html;
                            }
                        }

                        // If session is closed on server
                        if (data.status === 'Closed') {
                            clearInterval(this.pollInterval);
                            clearInterval(this.timerInterval);
                            if (this.timerElement) {
                                this.timerElement.innerHTML = '<span class="badge badge-neutral"><i class="fas fa-lock"></i> SESSION CLOSED</span>';
                            }
                        }
                    }
                })
                .catch(err => console.error('Live polling error:', err));
        };

        fetchUpdates();
        this.pollInterval = setInterval(fetchUpdates, this.pollIntervalMs);
    }

    setupFullscreen() {
        const fsBtn = document.getElementById('btn-fullscreen');
        const container = document.getElementById('projector-screen');
        if (fsBtn && container) {
            fsBtn.addEventListener('click', () => {
                if (!document.fullscreenElement) {
                    container.requestFullscreen().catch(err => {
                        console.error(`Error attempting to enable fullscreen: ${err.message}`);
                    });
                } else {
                    document.exitFullscreen();
                }
            });
        }
    }
}
