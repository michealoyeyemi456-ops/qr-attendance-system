<?php
/**
 * QR Attendance System Using MS SQL and Apache
 * API Endpoint: Live Attendance Poller for Active Session Monitoring
 */

require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/includes/functions.php';

header('Content-Type: application/json; charset=utf-8');

$sessionId = isset($_GET['session_id']) ? (int)$_GET['session_id'] : 0;

if ($sessionId <= 0) {
    jsonResponse(['success' => false, 'message' => 'Invalid session ID provided.'], 400);
}

try {
    $pdo = Database::getConnection();

    // Fetch session details
    $st = $pdo->prepare("
        SELECT s.SessionID, s.CourseID, s.ClassroomID, s.SessionDate, s.StartTime, s.EndTime, 
               s.DurationMinutes, s.SessionToken, s.Status, c.CourseCode, c.CourseTitle, cl.RoomCode
        FROM AttendanceSessions s
        JOIN Courses c ON s.CourseID = c.CourseID
        JOIN Classrooms cl ON s.ClassroomID = cl.ClassroomID
        WHERE s.SessionID = ?
    ");
    $st->execute([$sessionId]);
    $session = $st->fetch();

    if (!$session) {
        jsonResponse(['success' => false, 'message' => 'Session not found.'], 404);
    }

    // Check if session has naturally expired
    $now = date('H:i:s');
    $today = date('Y-m-d');
    if ($session['Status'] === 'Active' && ($session['SessionDate'] < $today || ($session['SessionDate'] === $today && $now > $session['EndTime']))) {
        $pdo->prepare("UPDATE AttendanceSessions SET Status = 'Closed', ClosedAt = CURRENT_TIMESTAMP WHERE SessionID = ?")->execute([$sessionId]);
        $session['Status'] = 'Closed';
    }

    // Fetch live attendees
    $stAttendees = $pdo->prepare("
        SELECT r.RecordID, r.MarkedAt, r.ScanMethod, r.Status, s.MatricNo, s.FirstName, s.LastName
        FROM AttendanceRecords r
        JOIN Students s ON r.StudentID = s.StudentID
        WHERE r.SessionID = ?
        ORDER BY r.MarkedAt DESC
    ");
    $stAttendees->execute([$sessionId]);
    $records = $stAttendees->fetchAll();

    $attendeeList = [];
    foreach ($records as $rec) {
        $attendeeList[] = [
            'record_id' => $rec['RecordID'],
            'matric_no' => $rec['MatricNo'],
            'student_name' => "{$rec['FirstName']} {$rec['LastName']}",
            'status' => $rec['Status'],
            'scan_method' => $rec['ScanMethod'],
            'marked_at' => date('h:i:s A', strtotime($rec['MarkedAt']))
        ];
    }

    jsonResponse([
        'success' => true,
        'session_id' => $sessionId,
        'status' => $session['Status'],
        'total_attendees' => count($attendeeList),
        'end_time' => $session['EndTime'],
        'attendees' => $attendeeList
    ]);

} catch (Exception $e) {
    jsonResponse(['success' => false, 'message' => 'Database error: ' . $e->getMessage()], 500);
}
