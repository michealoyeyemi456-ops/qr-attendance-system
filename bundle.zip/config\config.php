<?php
/**
 * QR Attendance System Using MS SQL and Apache
 * Core Application Configuration
 */

// Prevent direct script execution if accessed outside root
if (!defined('APP_INIT')) {
    define('APP_INIT', true);
}

// Session Security Configuration
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_only_cookies', 1);
    ini_set('session.cookie_samesite', 'Lax');
    session_start();
}

// Application Constants
define('APP_NAME', 'QR Attendance System');
define('APP_SUBTITLE', 'Using MS SQL and Apache');
define('INSTITUTION_NAME', 'Federal Institute of Technology & Applied Sciences');
define('INSTITUTION_CODE', 'FITAS');
define('APP_VERSION', '1.0.0');

// Base URL detection (Automatic detection for Apache VirtualHost or Subfolder)
$isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
    || (isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == 443)
    || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && strtolower($_SERVER['HTTP_X_FORWARDED_PROTO']) === 'https');
$protocol = $isHttps ? "https://" : "http://";
$host = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : 'localhost';
$scriptDir = isset($_SERVER['SCRIPT_NAME']) ? str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])) : '';

// Find base path up to root directory of project
$basePath = preg_replace('#/(admin|lecturer|student|auth|api|attendance|qr|reports|includes)(/.*)?$#i', '', $scriptDir);
$basePath = rtrim($basePath, '/');
define('BASE_URL', $protocol . $host . $basePath);
define('BASE_PATH', dirname(__DIR__));

// Timezone (Default to West Africa / Nigeria Time / Server Local)
date_default_timezone_set('Africa/Lagos');

// Academic Attendance Policies
define('ATTENDANCE_THRESHOLD_PERCENT', 75); // Standard 75% exam eligibility requirement
define('SESSION_EXPIRY_GRACE_MINUTES', 0);   // Immediate token expiry
define('DEFAULT_SESSION_DURATION', 30);      // Default 30 minutes duration

// Active Academic Session & Semester
define('CURRENT_ACADEMIC_SESSION', '2025/2026');
define('CURRENT_SEMESTER', 'First Semester');

// Error Reporting (Set to false in production)
define('APP_DEBUG', true);
if (APP_DEBUG) {
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', 0);
    error_reporting(0);
}
