<?php
/**
 * QR Attendance System Using MS SQL and Apache
 * Lecturer Portal: Assigned Courses & Enrolled Students
 */

require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/includes/functions.php';
require_once dirname(__DIR__) . '/includes/auth_guard.php';

$user = require_role('Lecturer');
$pdo = Database::getConnection();

// Fetch lecturer ID
$stLec = $pdo->prepare("SELECT LecturerID FROM Lecturers WHERE UserID = ?");
$stLec->execute([$user['user_id']]);
$lecturerId = (int)$stLec->fetchColumn();

// Fetch assigned courses
$stCourses = $pdo->prepare("
    SELECT c.CourseID, c.CourseCode, c.CourseTitle, c.CreditUnits, c.Semester,
           d.DepartmentName, l.LevelCode,
           (SELECT COUNT(*) FROM CourseRegistrations cr WHERE cr.CourseID = c.CourseID) AS EnrolledCount,
           (SELECT COUNT(*) FROM AttendanceSessions s WHERE s.CourseID = c.CourseID AND s.LecturerID = ?) AS SessionsCount
    FROM CourseLecturers cl
    JOIN Courses c ON cl.CourseID = c.CourseID
    JOIN Departments d ON c.DepartmentID = d.DepartmentID
    JOIN Levels l ON c.LevelID = l.LevelID
    WHERE cl.LecturerID = ?
    ORDER BY c.CourseCode ASC
");
$stCourses->execute([$lecturerId, $lecturerId]);
$courses = $stCourses->fetchAll();

// Selected course for enrolled students list view
$selectedCourseId = isset($_GET['view_roster']) ? (int)$_GET['view_roster'] : 0;
$rosterStudents = [];
$selectedCourseInfo = null;

if ($selectedCourseId > 0) {
    // Verify course belongs to lecturer
    $stVer = $pdo->prepare("SELECT c.CourseID, c.CourseCode, c.CourseTitle FROM Courses c JOIN CourseLecturers cl ON c.CourseID = cl.CourseID WHERE c.CourseID = ? AND cl.LecturerID = ?");
    $stVer->execute([$selectedCourseId, $lecturerId]);
    $selectedCourseInfo = $stVer->fetch();

    if ($selectedCourseInfo) {
        $stRoster = $pdo->prepare("
            SELECT s.StudentID, s.MatricNo, s.FirstName, s.LastName, s.Phone,
                   d.DepartmentCode, lev.LevelCode
            FROM CourseRegistrations cr
            JOIN Students s ON cr.StudentID = s.StudentID
            JOIN Departments d ON s.DepartmentID = d.DepartmentID
            JOIN Levels lev ON s.LevelID = lev.LevelID
            WHERE cr.CourseID = ?
            ORDER BY s.MatricNo ASC
        ");
        $stRoster->execute([$selectedCourseId]);
        $rosterStudents = $stRoster->fetchAll();
    }
}

$pageTitle = 'Assigned Teaching Courses';
require_once dirname(__DIR__) . '/includes/header.php';
?>

<div class="page-header">
    <div>
        <h1 class="page-title"><i class="fas fa-chalkboard text-primary"></i> Assigned Courses &amp; Enrolments</h1>
        <div class="page-subtitle">Academic Session: <?= CURRENT_ACADEMIC_SESSION ?> &bull; <?= CURRENT_SEMESTER ?></div>
    </div>
    <div>
        <a href="<?= BASE_URL ?>/lecturer/create_session.php" class="btn btn-primary">
            <i class="fas fa-plus-circle"></i> Launch New Session
        </a>
    </div>
</div>

<!-- Courses Grid / Table -->
<div class="card mb-4">
    <div class="card-header">
        <h3 class="card-title"><i class="fas fa-book-reader text-primary"></i> Allocated Course Catalog (<?= count($courses) ?>)</h3>
        <input type="text" class="form-control" placeholder="Search allocated courses..." style="max-width: 250px;" data-table-filter="#allocated-table">
    </div>
    <div class="table-responsive">
        <table class="table" id="allocated-table">
            <thead>
                <tr>
                    <th>Course Code &amp; Title</th>
                    <th>Level</th>
                    <th>Credits</th>
                    <th>Registered Students</th>
                    <th>Sessions Held</th>
                    <th class="text-right">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($courses)): ?>
                    <tr>
                        <td colspan="6" class="text-center text-muted" style="padding: 2rem;">No courses have been allocated to your account for this semester.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($courses as $c): ?>
                        <tr class="<?= ($selectedCourseId === (int)$c['CourseID']) ? 'style="background-color: #eff6ff;"' : '' ?>">
                            <td>
                                <strong style="font-size: 1rem; color: #1e3a8a;"><?= htmlspecialchars($c['CourseCode']) ?></strong>
                                <div style="font-size: 0.85rem; color: #334155;"><?= htmlspecialchars($c['CourseTitle']) ?></div>
                            </td>
                            <td><span class="badge badge-neutral"><?= htmlspecialchars($c['LevelCode']) ?></span></td>
                            <td><span class="badge badge-neutral"><?= $c['CreditUnits'] ?> Units</span></td>
                            <td>
                                <strong><?= $c['EnrolledCount'] ?></strong> students
                            </td>
                            <td>
                                <strong><?= $c['SessionsCount'] ?></strong> lectures
                            </td>
                            <td class="text-right">
                                <a href="<?= BASE_URL ?>/lecturer/courses.php?view_roster=<?= $c['CourseID'] ?>" class="btn btn-outline btn-sm">
                                    <i class="fas fa-users"></i> Enrolled Roster
                                </a>
                                <a href="<?= BASE_URL ?>/lecturer/create_session.php?course_id=<?= $c['CourseID'] ?>" class="btn btn-primary btn-sm">
                                    <i class="fas fa-play"></i> Start Session
                                </a>
                                <a href="<?= BASE_URL ?>/lecturer/reports.php?course_id=<?= $c['CourseID'] ?>" class="btn btn-outline btn-sm">
                                    <i class="fas fa-chart-line"></i> Analytics
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Enrolled Students Roster (When course clicked) -->
<?php if ($selectedCourseInfo): ?>
    <div class="card" id="roster-view">
        <div class="card-header" style="background-color: #f8fafc;">
            <div>
                <h3 class="card-title">
                    <i class="fas fa-user-graduate text-primary"></i> 
                    Registered Student Roster: <?= htmlspecialchars($selectedCourseInfo['CourseCode']) ?> &mdash; <?= htmlspecialchars($selectedCourseInfo['CourseTitle']) ?>
                </h3>
                <div class="text-muted" style="font-size: 0.825rem;">Total Enrolled: <?= count($rosterStudents) ?> students</div>
            </div>
            <a href="<?= BASE_URL ?>/lecturer/courses.php" class="btn btn-outline btn-sm">Close Roster</a>
        </div>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Matriculation Number</th>
                        <th>Student Full Name</th>
                        <th>Department</th>
                        <th>Level</th>
                        <th>Attendance %</th>
                        <th>Eligibility</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($rosterStudents)): ?>
                        <tr><td colspan="7" class="text-center text-muted" style="padding: 2rem;">No students have registered for this course yet.</td></tr>
                    <?php else: ?>
                        <?php foreach ($rosterStudents as $idx => $stu): 
                            $att = calculateAttendancePercent((int)$stu['StudentID'], (int)$selectedCourseInfo['CourseID']);
                        ?>
                            <tr>
                                <td><strong><?= $idx + 1 ?></strong></td>
                                <td><strong><?= htmlspecialchars($stu['MatricNo']) ?></strong></td>
                                <td><?= htmlspecialchars($stu['FirstName'] . ' ' . $stu['LastName']) ?></td>
                                <td><?= htmlspecialchars($stu['DepartmentCode']) ?></td>
                                <td><span class="badge badge-neutral"><?= htmlspecialchars($stu['LevelCode']) ?></span></td>
                                <td>
                                    <strong><?= $att['percentage'] ?>%</strong> (<?= $att['attended'] ?>/<?= $att['total'] ?>)
                                </td>
                                <td><?= getEligibilityBadge($att['percentage']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php endif; ?>

<?php require_once dirname(__DIR__) . '/includes/footer.php'; ?>
