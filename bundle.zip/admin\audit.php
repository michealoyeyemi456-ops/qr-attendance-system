<?php
/**
 * QR Attendance System Using MS SQL and Apache
 * Administrator Portal: Security Audit Trail & Access Logs
 */

require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/includes/functions.php';
require_once dirname(__DIR__) . '/includes/auth_guard.php';

$user = require_role('Admin');
$pdo = Database::getConnection();

$categoryFilter = trim($_GET['category'] ?? '');
$sql = "
    SELECT a.LogID, a.Action, a.Category, a.Details, a.IPAddress, a.Timestamp,
           u.Username, u.Role, u.Email
    FROM AuditLogs a
    LEFT JOIN Users u ON a.UserID = u.UserID
    WHERE 1=1
";
$params = [];

if (!empty($categoryFilter)) {
    $sql .= " AND a.Category = ?";
    $params[] = $categoryFilter;
}

$sql .= " ORDER BY a.LogID DESC LIMIT 150";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$logs = $stmt->fetchAll();

$categories = ['AUTH', 'ATTENDANCE', 'SESSION', 'ADMIN', 'REGISTRATION'];

$pageTitle = 'Security Audit Trail';
require_once dirname(__DIR__) . '/includes/header.php';
?>

<div class="page-header">
    <div>
        <h1 class="page-title"><i class="fas fa-shield-alt text-primary"></i> Security &amp; Activity Audit Trail</h1>
        <div class="page-subtitle">Immutable chronological log of authentication, QR scans, and system administrative operations</div>
    </div>
</div>

<!-- Filters Bar -->
<div class="card mb-4">
    <div class="card-body" style="padding: 1.25rem;">
        <form method="GET" action="<?= BASE_URL ?>/admin/audit.php" class="d-flex align-items-center gap-3 flex-wrap">
            <div style="flex: 1; min-width: 200px;">
                <label class="form-label" style="font-size: 0.8rem;">Filter by Category</label>
                <select name="category" class="form-select">
                    <option value="">-- All Categories --</option>
                    <?php foreach ($categories as $cat): ?>
                        <option value="<?= $cat ?>" <?= ($categoryFilter === $cat) ? 'selected' : '' ?>><?= $cat ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div style="align-self: flex-end; display: flex; gap: 0.5rem;">
                <button type="submit" class="btn btn-primary"><i class="fas fa-filter"></i> Filter</button>
                <a href="<?= BASE_URL ?>/admin/audit.php" class="btn btn-outline"><i class="fas fa-undo"></i></a>
            </div>
        </form>
    </div>
</div>

<!-- Audit Table -->
<div class="card">
    <div class="card-header">
        <h3 class="card-title"><i class="fas fa-history text-primary"></i> Audit Log Entries (<?= count($logs) ?>)</h3>
        <input type="text" class="form-control" placeholder="Search log text..." style="max-width: 250px;" data-table-filter="#audit-table">
    </div>
    <div class="table-responsive">
        <table class="table" id="audit-table">
            <thead>
                <tr>
                    <th>Log ID</th>
                    <th>Timestamp</th>
                    <th>User &amp; Role</th>
                    <th>Category</th>
                    <th>Action</th>
                    <th>Activity Details</th>
                    <th>IP Address</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($logs)): ?>
                    <tr><td colspan="7" class="text-center text-muted" style="padding: 2.5rem;">No audit records found.</td></tr>
                <?php else: ?>
                    <?php foreach ($logs as $l): ?>
                        <tr>
                            <td><strong>#<?= $l['LogID'] ?></strong></td>
                            <td style="font-size: 0.825rem; white-space: nowrap;"><?= formatDateTime($l['Timestamp']) ?></td>
                            <td>
                                <strong><?= htmlspecialchars($l['Username'] ?? 'Anonymous / System') ?></strong>
                                <?php if (!empty($l['Role'])): ?>
                                    <span class="badge badge-neutral" style="font-size: 0.7rem;"><?= $l['Role'] ?></span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge <?= ($l['Category'] === 'AUTH') ? 'badge-info' : (($l['Category'] === 'ATTENDANCE') ? 'badge-success' : 'badge-neutral') ?>">
                                    <?= htmlspecialchars($l['Category']) ?>
                                </span>
                            </td>
                            <td><strong><?= htmlspecialchars($l['Action']) ?></strong></td>
                            <td style="font-size: 0.85rem; max-width: 380px;">
                                <?= htmlspecialchars($l['Details'] ?? '') ?>
                            </td>
                            <td style="font-size: 0.8rem; color: #64748b;"><?= htmlspecialchars($l['IPAddress'] ?? '127.0.0.1') ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once dirname(__DIR__) . '/includes/footer.php'; ?>
