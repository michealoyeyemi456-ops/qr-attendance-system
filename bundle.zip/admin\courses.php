<?php
/**
 * QR Attendance System Using MS SQL and Apache
 * Administrator Portal: Manage Courses & Lecturer Allocations
 */

require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/includes/functions.php';
require_once dirname(__DIR__) . '/includes/auth_guard.php';

$user = require_role('Admin');
$pdo = Database::getConnection();

$error = null;

// Handle Form Posts
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        $error = 'Session expired. Please try again.';
    } else {
        $act = $_POST['action'];

        if ($act === 'add_course') {
            $code = strtoupper(trim($_POST['course_code'] ?? ''));
            $title = trim($_POST['course_title'] ?? '');
            $credits = (int)($_POST['credit_units'] ?? 3);
            $deptId = (int)($_POST['department_id'] ?? 0);
            $levelId = (int)($_POST['level_id'] ?? 0);
            $semester = trim($_POST['semester'] ?? CURRENT_SEMESTER);

            if (!empty($code) && !empty($title) && $deptId > 0 && $levelId > 0) {
                try {
                    $pdo->prepare("
                        INSERT INTO Courses (DepartmentID, LevelID, CourseCode, CourseTitle, CreditUnits, Semester)
                        VALUES (?, ?, ?, ?, ?, ?)
                    ")->execute([$deptId, $levelId, $code, $title, $credits, $semester]);

                    logAudit($user['user_id'], 'COURSE_CREATED', 'ADMIN', "Created course {$code} ({$title})");
                    flash('success', "Course {$code} created successfully.", 'success');
                    header('Location: ' . BASE_URL . '/admin/courses.php');
                    exit;
                } catch (Exception $e) {
                    $error = 'Error adding course: ' . $e->getMessage();
                }
            }
        } elseif ($act === 'allocate_lecturer') {
            $courseId = (int)($_POST['course_id'] ?? 0);
            $lecturerId = (int)($_POST['lecturer_id'] ?? 0);
            $session = trim($_POST['academic_session'] ?? CURRENT_ACADEMIC_SESSION);
            $semester = trim($_POST['semester'] ?? CURRENT_SEMESTER);

            if ($courseId > 0 && $lecturerId > 0) {
                try {
                    $pdo->prepare("
                        INSERT INTO CourseLecturers (CourseID, LecturerID, AcademicSession, Semester)
                        VALUES (?, ?, ?, ?)
                    ")->execute([$courseId, $lecturerId, $session, $semester]);

                    logAudit($user['user_id'], 'COURSE_ALLOCATED', 'ADMIN', "Allocated Course #{$courseId} to Lecturer #{$lecturerId}");
                    flash('success', "Course assigned to lecturer successfully.", 'success');
                    header('Location: ' . BASE_URL . '/admin/courses.php');
                    exit;
                } catch (Exception $e) {
                    $error = 'Allocation error: ' . $e->getMessage();
                }
            }
        }
    }
}

// Fetch Courses with Allocated Lecturers
$courses = $pdo->query("
    SELECT c.*, d.DepartmentCode, l.LevelCode,
           lec.StaffID, lec.Title, lec.FirstName AS LecFirst, lec.LastName AS LecLast,
           (SELECT COUNT(*) FROM CourseRegistrations cr WHERE cr.CourseID = c.CourseID) AS EnrolledStudents
    FROM Courses c
    JOIN Departments d ON c.DepartmentID = d.DepartmentID
    JOIN Levels l ON c.LevelID = l.LevelID
    LEFT JOIN CourseLecturers cl ON c.CourseID = cl.CourseID
    LEFT JOIN Lecturers lec ON cl.LecturerID = lec.LecturerID
    ORDER BY c.CourseCode ASC
")->fetchAll();

$departments = $pdo->query("SELECT DepartmentID, DepartmentCode, DepartmentName FROM Departments ORDER BY DepartmentName ASC")->fetchAll();
$levels = $pdo->query("SELECT LevelID, LevelCode FROM Levels ORDER BY LevelID ASC")->fetchAll();
$lecturers = $pdo->query("SELECT LecturerID, StaffID, Title, FirstName, LastName FROM Lecturers ORDER BY LastName ASC")->fetchAll();

$pageTitle = 'Courses & Lecturer Allocations';
require_once dirname(__DIR__) . '/includes/header.php';
?>

<div class="page-header">
    <div>
        <h1 class="page-title"><i class="fas fa-book-open text-primary"></i> Courses &amp; Lecturer Allocations</h1>
        <div class="page-subtitle">Curriculum course registry &amp; lecturer teaching assignments</div>
    </div>
</div>

<?php if ($error): ?>
    <div class="alert alert-danger"><i class="fas fa-times-circle"></i> <?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem;" class="mb-4">
    <!-- Add New Course Card -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title"><i class="fas fa-plus-circle text-primary"></i> Register New Course</h3>
        </div>
        <div class="card-body">
            <form action="<?= BASE_URL ?>/admin/courses.php" method="POST">
                <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                <input type="hidden" name="action" value="add_course">

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                    <div class="form-group">
                        <label class="form-label">Course Code *</label>
                        <input type="text" name="course_code" class="form-control" placeholder="e.g. COM 315" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Credit Units *</label>
                        <input type="number" name="credit_units" class="form-control" value="3" min="1" max="6" required>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label">Course Title *</label>
                    <input type="text" name="course_title" class="form-control" placeholder="e.g. Artificial Intelligence & Expert Systems" required>
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                    <div class="form-group">
                        <label class="form-label">Department *</label>
                        <select name="department_id" class="form-select" required>
                            <option value="">-- Select --</option>
                            <?php foreach ($departments as $d): ?>
                                <option value="<?= $d['DepartmentID'] ?>"><?= htmlspecialchars($d['DepartmentCode']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Level *</label>
                        <select name="level_id" class="form-select" required>
                            <option value="">-- Select --</option>
                            <?php foreach ($levels as $l): ?>
                                <option value="<?= $l['LevelID'] ?>"><?= htmlspecialchars($l['LevelCode']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <button type="submit" class="btn btn-primary btn-block"><i class="fas fa-save"></i> Save Course</button>
            </form>
        </div>
    </div>

    <!-- Allocate Lecturer Card -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title"><i class="fas fa-user-check text-primary"></i> Assign Course to Lecturer</h3>
        </div>
        <div class="card-body">
            <form action="<?= BASE_URL ?>/admin/courses.php" method="POST">
                <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                <input type="hidden" name="action" value="allocate_lecturer">

                <div class="form-group">
                    <label class="form-label">Select Course *</label>
                    <select name="course_id" class="form-select" required>
                        <option value="">-- Select Course --</option>
                        <?php foreach ($courses as $c): ?>
                            <option value="<?= $c['CourseID'] ?>"><?= htmlspecialchars($c['CourseCode'] . ' - ' . $c['CourseTitle']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label class="form-label">Select Faculty Lecturer *</label>
                    <select name="lecturer_id" class="form-select" required>
                        <option value="">-- Select Lecturer --</option>
                        <?php foreach ($lecturers as $lec): ?>
                            <option value="<?= $lec['LecturerID'] ?>">
                                <?= htmlspecialchars($lec['StaffID'] . ' - ' . $lec['Title'] . ' ' . $lec['FirstName'] . ' ' . $lec['LastName']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                    <div class="form-group">
                        <label class="form-label">Session</label>
                        <input type="text" name="academic_session" class="form-control" value="<?= CURRENT_ACADEMIC_SESSION ?>" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Semester</label>
                        <input type="text" name="semester" class="form-control" value="<?= CURRENT_SEMESTER ?>" required>
                    </div>
                </div>

                <button type="submit" class="btn btn-accent btn-block"><i class="fas fa-link"></i> Allocate Teaching Assignment</button>
            </form>
        </div>
    </div>
</div>

<!-- Courses Directory -->
<div class="card">
    <div class="card-header">
        <h3 class="card-title"><i class="fas fa-book text-primary"></i> Course Directory &amp; Assigned Faculty (<?= count($courses) ?>)</h3>
        <input type="text" class="form-control" placeholder="Search courses..." style="max-width: 250px;" data-table-filter="#courses-table">
    </div>
    <div class="table-responsive">
        <table class="table" id="courses-table">
            <thead>
                <tr>
                    <th>Course Code</th>
                    <th>Course Title</th>
                    <th>Dept &amp; Level</th>
                    <th>Units</th>
                    <th>Assigned Lecturer</th>
                    <th>Enrolled</th>
                    <th>Semester</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($courses as $c): ?>
                    <tr>
                        <td><strong style="color: #1e3a8a;"><?= htmlspecialchars($c['CourseCode']) ?></strong></td>
                        <td><?= htmlspecialchars($c['CourseTitle']) ?></td>
                        <td><?= htmlspecialchars($c['DepartmentCode']) ?> &bull; <span class="badge badge-neutral"><?= htmlspecialchars($c['LevelCode']) ?></span></td>
                        <td><span class="badge badge-neutral"><?= $c['CreditUnits'] ?> Units</span></td>
                        <td>
                            <?php if (!empty($c['StaffID'])): ?>
                                <strong><?= htmlspecialchars($c['Title'] . ' ' . $c['LecFirst'] . ' ' . $c['LecLast']) ?></strong>
                                <div class="text-muted" style="font-size: 0.75rem;"><?= htmlspecialchars($c['StaffID']) ?></div>
                            <?php else: ?>
                                <span class="badge badge-warning"><i class="fas fa-exclamation-circle"></i> Unallocated</span>
                            <?php endif; ?>
                        </td>
                        <td><strong><?= $c['EnrolledStudents'] ?></strong> students</td>
                        <td><span class="badge badge-info"><?= htmlspecialchars($c['Semester']) ?></span></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once dirname(__DIR__) . '/includes/footer.php'; ?>
