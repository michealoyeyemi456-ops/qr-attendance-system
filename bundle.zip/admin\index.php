<?php
/**
 * QR Attendance System Using MS SQL and Apache
 * Administrator Portal: Executive KPI Dashboard & Operations
 */

require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/includes/functions.php';
require_once dirname(__DIR__) . '/includes/auth_guard.php';

$user = require_role('Admin');
$pdo = Database::getConnection();

// System KPIs
$totalStudents = (int)$pdo->query("SELECT COUNT(*) FROM Students")->fetchColumn();
$totalLecturers = (int)$pdo->query("SELECT COUNT(*) FROM Lecturers")->fetchColumn();
$totalCourses = (int)$pdo->query("SELECT COUNT(*) FROM Courses")->fetchColumn();
$totalSessions = (int)$pdo->query("SELECT COUNT(*) FROM AttendanceSessions")->fetchColumn();
$activeSessionsToday = (int)$pdo->query("SELECT COUNT(*) FROM AttendanceSessions WHERE Status = 'Active' AND SessionDate = CURRENT_DATE")->fetchColumn();
$totalScans = (int)$pdo->query("SELECT COUNT(*) FROM AttendanceRecords")->fetchColumn();

// Recent Audit Activity
$recentAudits = $pdo->query("
    SELECT a.LogID, a.Action, a.Category, a.Details, a.IPAddress, a.Timestamp, u.Username, u.Role
    FROM AuditLogs a
    LEFT JOIN Users u ON a.UserID = u.UserID
    ORDER BY a.LogID DESC
    LIMIT 8
")->fetchAll();

// Active Live Sessions Across Campus Today
$liveSessions = $pdo->query("
    SELECT s.SessionID, s.SessionDate, s.StartTime, s.EndTime, s.DurationMinutes, s.SessionToken,
           c.CourseCode, c.CourseTitle, cl.RoomCode,
           l.Title AS LecTitle, l.LastName AS LecLast,
           (SELECT COUNT(*) FROM AttendanceRecords r WHERE r.SessionID = s.SessionID) AS AttendeeCount
    FROM AttendanceSessions s
    JOIN Courses c ON s.CourseID = c.CourseID
    JOIN Classrooms cl ON s.ClassroomID = cl.ClassroomID
    JOIN Lecturers l ON s.LecturerID = l.LecturerID
    WHERE s.Status = 'Active' AND s.SessionDate = CURRENT_DATE
    ORDER BY s.SessionID DESC
")->fetchAll();

$pageTitle = 'Administrator Dashboard';
require_once dirname(__DIR__) . '/includes/header.php';
?>

<div class="page-header">
    <div>
        <h1 class="page-title"><i class="fas fa-th-large text-primary"></i> Administrator Operations Center</h1>
        <div class="page-subtitle">Central attendance management &amp; institutional monitoring &bull; <?= CURRENT_ACADEMIC_SESSION ?></div>
    </div>
    <div class="d-flex gap-2 flex-wrap">
        <a href="<?= BASE_URL ?>/admin/students.php?action=create" class="btn btn-primary btn-sm">
            <i class="fas fa-user-plus"></i> Add Student
        </a>
        <a href="<?= BASE_URL ?>/admin/lecturers.php?action=create" class="btn btn-primary btn-sm">
            <i class="fas fa-chalkboard-teacher"></i> Add Lecturer
        </a>
        <a href="<?= BASE_URL ?>/admin/records.php" class="btn btn-outline btn-sm">
            <i class="fas fa-clipboard-list"></i> Master Records
        </a>
    </div>
</div>

<!-- Database Engine Status Alert -->
<div class="card mb-4" style="background: #ffffff; border-left: 5px solid #1e3a8a;">
    <div class="card-body" style="padding: 1.25rem 1.5rem; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 1rem;">
        <div>
            <div style="font-size: 0.8rem; text-transform: uppercase; color: #64748b; font-weight: 700;">Database Engine Connected</div>
            <div style="font-size: 1.15rem; font-weight: 800; color: #0f172a;">
                <i class="fas fa-server text-primary"></i> <?= htmlspecialchars(Database::getDriverUsed()) ?>
            </div>
            <div class="text-muted" style="font-size: 0.8rem; margin-top: 0.2rem;">
                Target DBMS: <strong>Microsoft SQL Server</strong> &bull; Apache Host: <strong><?= htmlspecialchars($_SERVER['SERVER_SOFTWARE'] ?? 'Apache / PHP') ?></strong>
            </div>
        </div>
        <div class="d-flex gap-2">
            <span class="badge badge-success" style="padding: 0.5rem 0.85rem; font-size: 0.85rem;">
                <i class="fas fa-check-circle"></i> Service Operational
            </span>
            <a href="<?= BASE_URL ?>/admin/settings.php" class="btn btn-outline btn-sm">
                <i class="fas fa-sliders-h"></i> System Settings
            </a>
        </div>
    </div>
</div>

<!-- KPI Cards -->
<div class="stat-grid">
    <div class="stat-card stat-primary">
        <div class="stat-icon-wrapper"><i class="fas fa-user-graduate"></i></div>
        <div class="stat-content">
            <div class="stat-value"><?= $totalStudents ?></div>
            <div class="stat-label">Total Students</div>
        </div>
    </div>

    <div class="stat-card stat-info">
        <div class="stat-icon-wrapper"><i class="fas fa-chalkboard-teacher"></i></div>
        <div class="stat-content">
            <div class="stat-value"><?= $totalLecturers ?></div>
            <div class="stat-label">Faculty Lecturers</div>
        </div>
    </div>

    <div class="stat-card stat-warning">
        <div class="stat-icon-wrapper"><i class="fas fa-book"></i></div>
        <div class="stat-content">
            <div class="stat-value"><?= $totalCourses ?></div>
            <div class="stat-label">Active Courses</div>
        </div>
    </div>

    <div class="stat-card stat-success">
        <div class="stat-icon-wrapper"><i class="fas fa-qrcode"></i></div>
        <div class="stat-content">
            <div class="stat-value"><?= $totalScans ?></div>
            <div class="stat-label">Total Scans Recorded</div>
        </div>
    </div>
</div>

<!-- Live Campus Sessions Now -->
<?php if (!empty($liveSessions)): ?>
    <div class="card mb-4" style="border: 2px solid #3b82f6;">
        <div class="card-header" style="background-color: #eff6ff;">
            <div class="d-flex align-items-center gap-2">
                <div class="pulse-indicator"></div>
                <h3 class="card-title text-primary"><i class="fas fa-broadcast-tower"></i> Live Classes Happening Right Now Across Campus (<?= count($liveSessions) ?>)</h3>
            </div>
            <a href="<?= BASE_URL ?>/admin/sessions.php" class="btn btn-outline btn-sm">Manage All Sessions</a>
        </div>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Course</th>
                        <th>Lecturer</th>
                        <th>Classroom</th>
                        <th>Time Window</th>
                        <th>Turnout</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($liveSessions as $live): ?>
                        <tr>
                            <td>
                                <strong><?= htmlspecialchars($live['CourseCode']) ?></strong>
                                <div class="text-muted" style="font-size: 0.8rem;"><?= htmlspecialchars($live['CourseTitle']) ?></div>
                            </td>
                            <td><?= htmlspecialchars($live['LecTitle'] . ' ' . $live['LecLast']) ?></td>
                            <td><?= htmlspecialchars($live['RoomCode']) ?></td>
                            <td><?= formatTime($live['StartTime']) ?> - <?= formatTime($live['EndTime']) ?></td>
                            <td><strong class="text-success"><?= $live['AttendeeCount'] ?></strong> students checked in</td>
                            <td>
                                <a href="<?= BASE_URL ?>/lecturer/active_session.php?session_id=<?= $live['SessionID'] ?>" class="btn btn-outline btn-sm" target="_blank">
                                    <i class="fas fa-external-link-alt"></i> Monitor
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php endif; ?>

<!-- Recent Security Audit Trail -->
<div class="card">
    <div class="card-header">
        <h3 class="card-title"><i class="fas fa-shield-alt text-primary"></i> Recent Security Audit Logs</h3>
        <a href="<?= BASE_URL ?>/admin/audit.php" class="btn btn-outline btn-sm">Full Audit Trail</a>
    </div>
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>Timestamp</th>
                    <th>User</th>
                    <th>Category</th>
                    <th>Action</th>
                    <th>Details</th>
                    <th>IP Address</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($recentAudits)): ?>
                    <tr><td colspan="6" class="text-center text-muted" style="padding: 2rem;">No audit logs recorded yet.</td></tr>
                <?php else: ?>
                    <?php foreach ($recentAudits as $log): ?>
                        <tr>
                            <td style="font-size: 0.825rem; white-space: nowrap;"><?= formatDateTime($log['Timestamp']) ?></td>
                            <td>
                                <strong><?= htmlspecialchars($log['Username'] ?? 'System') ?></strong>
                                <?php if (!empty($log['Role'])): ?>
                                    <span class="badge badge-neutral" style="font-size: 0.7rem;"><?= $log['Role'] ?></span>
                                <?php endif; ?>
                            </td>
                            <td><span class="badge badge-info"><?= htmlspecialchars($log['Category']) ?></span></td>
                            <td><strong><?= htmlspecialchars($log['Action']) ?></strong></td>
                            <td style="font-size: 0.85rem; max-width: 320px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
                                <?= htmlspecialchars($log['Details']) ?>
                            </td>
                            <td style="font-size: 0.8rem; color: #64748b;"><?= htmlspecialchars($log['IPAddress']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once dirname(__DIR__) . '/includes/footer.php'; ?>
