﻿-- ============================================================================
-- QR Attendance Management System - MySQL / MariaDB Schema
-- Target: InfinityFree, cPanel phpMyAdmin, AWS RDS, PlanetScale, Railway MySQL
-- ============================================================================

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS `AuditLogs`;
DROP TABLE IF EXISTS `SystemSettings`;
DROP TABLE IF EXISTS `AttendanceRecords`;
DROP TABLE IF EXISTS `AttendanceSessions`;
DROP TABLE IF EXISTS `CourseRegistrations`;
DROP TABLE IF EXISTS `CourseLecturers`;
DROP TABLE IF EXISTS `Courses`;
DROP TABLE IF EXISTS `Students`;
DROP TABLE IF EXISTS `Lecturers`;
DROP TABLE IF EXISTS `Classrooms`;
DROP TABLE IF EXISTS `Levels`;
DROP TABLE IF EXISTS `Programmes`;
DROP TABLE IF EXISTS `Departments`;
DROP TABLE IF EXISTS `Users`;
SET FOREIGN_KEY_CHECKS = 1;

-- 1. USERS TABLE
CREATE TABLE `Users` (
    `UserID` INT AUTO_INCREMENT PRIMARY KEY,
    `Username` VARCHAR(50) NOT NULL UNIQUE,
    `PasswordHash` VARCHAR(255) NOT NULL,
    `Email` VARCHAR(100) NOT NULL UNIQUE,
    `Role` ENUM('Admin', 'Lecturer', 'Student') NOT NULL,
    `Status` ENUM('Active', 'Inactive', 'Suspended') NOT NULL DEFAULT 'Active',
    `CreatedAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `LastLogin` DATETIME NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2. DEPARTMENTS TABLE
CREATE TABLE `Departments` (
    `DepartmentID` INT AUTO_INCREMENT PRIMARY KEY,
    `DepartmentCode` VARCHAR(20) NOT NULL UNIQUE,
    `DepartmentName` VARCHAR(100) NOT NULL,
    `Faculty` VARCHAR(100) NOT NULL DEFAULT 'School of Applied Science & Technology'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. PROGRAMMES TABLE
CREATE TABLE `Programmes` (
    `ProgrammeID` INT AUTO_INCREMENT PRIMARY KEY,
    `DepartmentID` INT NOT NULL,
    `ProgrammeCode` VARCHAR(20) NOT NULL UNIQUE,
    `ProgrammeName` VARCHAR(100) NOT NULL,
    `DurationYears` INT NOT NULL DEFAULT 2,
    FOREIGN KEY (`DepartmentID`) REFERENCES `Departments`(`DepartmentID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 4. LEVELS TABLE
CREATE TABLE `Levels` (
    `LevelID` INT AUTO_INCREMENT PRIMARY KEY,
    `LevelCode` VARCHAR(20) NOT NULL UNIQUE,
    `LevelName` VARCHAR(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 5. CLASSROOMS TABLE
CREATE TABLE `Classrooms` (
    `ClassroomID` INT AUTO_INCREMENT PRIMARY KEY,
    `RoomCode` VARCHAR(50) NOT NULL UNIQUE,
    `RoomName` VARCHAR(100) NOT NULL,
    `Capacity` INT NOT NULL DEFAULT 60,
    `Building` VARCHAR(100) NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 6. LECTURERS TABLE
CREATE TABLE `Lecturers` (
    `LecturerID` INT AUTO_INCREMENT PRIMARY KEY,
    `UserID` INT NOT NULL UNIQUE,
    `DepartmentID` INT NOT NULL,
    `StaffID` VARCHAR(50) NOT NULL UNIQUE,
    `Title` VARCHAR(50) NOT NULL DEFAULT 'Lecturer',
    `FirstName` VARCHAR(50) NOT NULL,
    `LastName` VARCHAR(50) NOT NULL,
    `Phone` VARCHAR(20) NULL,
    `OfficeNumber` VARCHAR(50) NULL,
    FOREIGN KEY (`UserID`) REFERENCES `Users`(`UserID`) ON DELETE CASCADE,
    FOREIGN KEY (`DepartmentID`) REFERENCES `Departments`(`DepartmentID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 7. STUDENTS TABLE
CREATE TABLE `Students` (
    `StudentID` INT AUTO_INCREMENT PRIMARY KEY,
    `UserID` INT NOT NULL UNIQUE,
    `DepartmentID` INT NOT NULL,
    `ProgrammeID` INT NOT NULL,
    `LevelID` INT NOT NULL,
    `MatricNo` VARCHAR(50) NOT NULL UNIQUE,
    `FirstName` VARCHAR(50) NOT NULL,
    `LastName` VARCHAR(50) NOT NULL,
    `Phone` VARCHAR(20) NULL,
    `AcademicSession` VARCHAR(20) NOT NULL DEFAULT '2025/2026',
    FOREIGN KEY (`UserID`) REFERENCES `Users`(`UserID`) ON DELETE CASCADE,
    FOREIGN KEY (`DepartmentID`) REFERENCES `Departments`(`DepartmentID`),
    FOREIGN KEY (`ProgrammeID`) REFERENCES `Programmes`(`ProgrammeID`),
    FOREIGN KEY (`LevelID`) REFERENCES `Levels`(`LevelID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 8. COURSES TABLE
CREATE TABLE `Courses` (
    `CourseID` INT AUTO_INCREMENT PRIMARY KEY,
    `DepartmentID` INT NOT NULL,
    `LevelID` INT NOT NULL,
    `CourseCode` VARCHAR(20) NOT NULL UNIQUE,
    `CourseTitle` VARCHAR(100) NOT NULL,
    `CreditUnits` INT NOT NULL DEFAULT 3,
    `Semester` VARCHAR(20) NOT NULL DEFAULT 'First Semester',
    FOREIGN KEY (`DepartmentID`) REFERENCES `Departments`(`DepartmentID`),
    FOREIGN KEY (`LevelID`) REFERENCES `Levels`(`LevelID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 9. COURSE LECTURERS ALLOCATION TABLE
CREATE TABLE `CourseLecturers` (
    `AllocationID` INT AUTO_INCREMENT PRIMARY KEY,
    `CourseID` INT NOT NULL,
    `LecturerID` INT NOT NULL,
    `AcademicSession` VARCHAR(20) NOT NULL DEFAULT '2025/2026',
    `Semester` VARCHAR(20) NOT NULL DEFAULT 'First Semester',
    UNIQUE KEY `UQ_Course_Lecturer` (`CourseID`, `LecturerID`, `AcademicSession`, `Semester`),
    FOREIGN KEY (`CourseID`) REFERENCES `Courses`(`CourseID`) ON DELETE CASCADE,
    FOREIGN KEY (`LecturerID`) REFERENCES `Lecturers`(`LecturerID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 10. COURSE REGISTRATIONS TABLE
CREATE TABLE `CourseRegistrations` (
    `RegistrationID` INT AUTO_INCREMENT PRIMARY KEY,
    `StudentID` INT NOT NULL,
    `CourseID` INT NOT NULL,
    `AcademicSession` VARCHAR(20) NOT NULL DEFAULT '2025/2026',
    `Semester` VARCHAR(20) NOT NULL DEFAULT 'First Semester',
    `RegisteredAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY `UQ_Student_Course_Session` (`StudentID`, `CourseID`, `AcademicSession`, `Semester`),
    FOREIGN KEY (`StudentID`) REFERENCES `Students`(`StudentID`) ON DELETE CASCADE,
    FOREIGN KEY (`CourseID`) REFERENCES `Courses`(`CourseID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 11. ATTENDANCE SESSIONS TABLE
CREATE TABLE `AttendanceSessions` (
    `SessionID` INT AUTO_INCREMENT PRIMARY KEY,
    `CourseID` INT NOT NULL,
    `LecturerID` INT NOT NULL,
    `ClassroomID` INT NULL,
    `SessionToken` VARCHAR(100) NOT NULL UNIQUE,
    `StartTime` DATETIME NOT NULL,
    `EndTime` DATETIME NOT NULL,
    `DurationMinutes` INT NOT NULL DEFAULT 30,
    `CurrentDynamicToken` VARCHAR(64) NOT NULL,
    `DynamicTokenUpdatedAt` DATETIME NOT NULL,
    `Status` ENUM('Active', 'Expired', 'Cancelled') NOT NULL DEFAULT 'Active',
    `Topic` VARCHAR(255) NULL,
    `Remarks` TEXT NULL,
    `CreatedAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`CourseID`) REFERENCES `Courses`(`CourseID`),
    FOREIGN KEY (`LecturerID`) REFERENCES `Lecturers`(`LecturerID`),
    FOREIGN KEY (`ClassroomID`) REFERENCES `Classrooms`(`ClassroomID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 12. ATTENDANCE RECORDS TABLE
CREATE TABLE `AttendanceRecords` (
    `RecordID` INT AUTO_INCREMENT PRIMARY KEY,
    `SessionID` INT NOT NULL,
    `StudentID` INT NOT NULL,
    `ScanTime` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `ScanMethod` ENUM('QR_Scanner', 'Manual_Lecturer', 'Manual_Admin') NOT NULL DEFAULT 'QR_Scanner',
    `VerificationStatus` ENUM('Present', 'Late', 'Excused', 'Flagged') NOT NULL DEFAULT 'Present',
    `DeviceSignature` VARCHAR(255) NULL,
    `IpAddress` VARCHAR(45) NULL,
    UNIQUE KEY `UQ_Session_Student` (`SessionID`, `StudentID`),
    FOREIGN KEY (`SessionID`) REFERENCES `AttendanceSessions`(`SessionID`) ON DELETE CASCADE,
    FOREIGN KEY (`StudentID`) REFERENCES `Students`(`StudentID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 13. SYSTEM SETTINGS TABLE
CREATE TABLE `SystemSettings` (
    `SettingID` INT AUTO_INCREMENT PRIMARY KEY,
    `SettingKey` VARCHAR(50) NOT NULL UNIQUE,
    `SettingValue` TEXT NOT NULL,
    `Description` VARCHAR(255) NULL,
    `UpdatedAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 14. AUDIT LOGS TABLE
CREATE TABLE `AuditLogs` (
    `LogID` INT AUTO_INCREMENT PRIMARY KEY,
    `UserID` INT NULL,
    `Action` VARCHAR(100) NOT NULL,
    `Details` TEXT NULL,
    `IpAddress` VARCHAR(45) NULL,
    `CreatedAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`UserID`) REFERENCES `Users`(`UserID`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- SEED DATA (Universal Password: Password123!)
-- Hash: $2y$10$eE6v0/237qKqT.Y1rP6d4OC5Qv4k9L5dJb99u1P8zGvY5r1z6x.c.
INSERT INTO `Users` (`UserID`, `Username`, `PasswordHash`, `Email`, `Role`, `Status`) VALUES
(1, 'admin', '$2y$10$wI5f7N3V0j5e4M444L0O7eQn5iEeeM0M8Fq5l.T5y12/zD8Q0zQe.', 'admin@fitas.edu.ng', 'Admin', 'Active'),
(2, 'dr.ibrahim', '$2y$10$wI5f7N3V0j5e4M444L0O7eQn5iEeeM0M8Fq5l.T5y12/zD8Q0zQe.', 'ibrahim@fitas.edu.ng', 'Lecturer', 'Active'),
(3, 'fitas/2024/001', '$2y$10$wI5f7N3V0j5e4M444L0O7eQn5iEeeM0M8Fq5l.T5y12/zD8Q0zQe.', 'adeyemi@student.fitas.edu.ng', 'Student', 'Active');

INSERT INTO `Departments` (`DepartmentID`, `DepartmentCode`, `DepartmentName`, `Faculty`) VALUES
(1, 'CS', 'Computer Science & Information Technology', 'School of Applied Science & Technology'),
(2, 'EE', 'Electrical & Electronic Engineering', 'School of Engineering');

INSERT INTO `Programmes` (`ProgrammeID`, `DepartmentID`, `ProgrammeCode`, `ProgrammeName`, `DurationYears`) VALUES
(1, 1, 'HND-CS', 'Higher National Diploma in Computer Science', 2),
(2, 2, 'HND-EE', 'Higher National Diploma in Electrical Engineering', 2);

INSERT INTO `Levels` (`LevelID`, `LevelCode`, `LevelName`) VALUES
(1, 'HND 1', 'Higher National Diploma Year 1'),
(2, 'HND 2', 'Higher National Diploma Year 2');

INSERT INTO `Classrooms` (`ClassroomID`, `RoomCode`, `RoomName`, `Capacity`, `Building`) VALUES
(1, 'LH-01', 'Lecture Hall 1 (Main Hall)', 120, 'Science Complex'),
(2, 'LAB-3', 'Software Engineering Lab 3', 45, 'ICT Building');

INSERT INTO `Lecturers` (`LecturerID`, `UserID`, `DepartmentID`, `StaffID`, `Title`, `FirstName`, `LastName`, `Phone`, `OfficeNumber`) VALUES
(1, 2, 1, 'STF/CS/001', 'Dr.', 'Ibrahim', 'Musa', '+234 803 123 4567', 'Room 204, ICT Block');

INSERT INTO `Students` (`StudentID`, `UserID`, `DepartmentID`, `ProgrammeID`, `LevelID`, `MatricNo`, `FirstName`, `LastName`, `Phone`, `AcademicSession`) VALUES
(1, 3, 1, 1, 1, 'fitas/2024/001', 'Adeyemi', 'Oluwaseun', '+234 814 555 0101', '2025/2026');

INSERT INTO `Courses` (`CourseID`, `DepartmentID`, `LevelID`, `CourseCode`, `CourseTitle`, `CreditUnits`, `Semester`) VALUES
(1, 1, 1, 'COM 311', 'Operating Systems & Architecture', 3, 'First Semester'),
(2, 1, 1, 'COM 312', 'Database Design & Management', 3, 'First Semester'),
(3, 1, 1, 'COM 313', 'Computer Programming Using C++', 4, 'First Semester');

INSERT INTO `CourseLecturers` (`CourseID`, `LecturerID`, `AcademicSession`, `Semester`) VALUES
(1, 1, '2025/2026', 'First Semester'),
(2, 1, '2025/2026', 'First Semester');

INSERT INTO `CourseRegistrations` (`StudentID`, `CourseID`, `AcademicSession`, `Semester`) VALUES
(1, 1, '2025/2026', 'First Semester'),
(1, 2, '2025/2026', 'First Semester');

INSERT INTO `SystemSettings` (`SettingKey`, `SettingValue`, `Description`) VALUES
('institution_name', 'Federal Institute of Technology & Applied Sciences', 'Official institution title'),
('institution_code', 'FITAS', 'Abbreviation code'),
('attendance_threshold', '75', 'Minimum percentage required to sit for examinations'),
('academic_session', '2025/2026', 'Active academic session'),
('academic_semester', 'First Semester', 'Active semester'),
('token_refresh_seconds', '5', 'Dynamic QR code token refresh interval');
